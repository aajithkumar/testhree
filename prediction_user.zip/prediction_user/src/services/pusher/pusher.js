import Pusher from 'pusher-js';

const pusherKey = process.env.NEXT_PUBLIC_PUSHER_KEY;
const pusherCluster = process.env.NEXT_PUBLIC_CLUSTER;

const pusher = new Pusher(pusherKey, {
    cluster: pusherCluster,
    encrypted: true
});

// Pusher.logToConsole = true;

pusher.connection.bind("connected", () => {
    console.log("Pusher connected");
});
pusher.connection.bind("disconnected", () => {
    console.warn("Pusher disconnected");
});
pusher.connection.bind("error", (err) => {
    console.error("Pusher error", err);
});

export default pusher;