import { NextResponse } from "next/server";

export async function middleware(request) {
    const { pathname } = request.nextUrl;
    const accessToken = request.cookies.get("accessToken")?.value ?? null;
    // const isAuthenticated = request.cookies.get("isAuthenticated")?.value ?? 0;

    if (request.nextUrl.pathname === "/") {
      return NextResponse.next();
    }


    if (accessToken) {

      // const tworfa = request.cookies.get("twofa")?.value;
      // const verifytwofa = request.cookies.get("verifytwofa")?.value;

    
      // if (request.nextUrl.pathname == "/logout") {
      //   return NextResponse.next();
      // }

      // Redirect GOOGLE OTP && EMAIL OTP if 2FA not verified
      // if (
      //   tworfa === "google_otp" &&
      //   verifytwofa === "0" &&
      //   request.nextUrl.pathname !== "/googleverify"
      // ) {
      //   if(request.nextUrl.pathname === "/contactus"){
      //     return NextResponse.next();
      //   }else{
      //     return NextResponse.redirect(new URL("/googleverify", request.url));
      //   }
      // }

      // if (
      //   tworfa === "email_otp" &&
      //   verifytwofa === "0" &&
      //   request.nextUrl.pathname !== "/verify"
      // ) {
      //   if(request.nextUrl.pathname === "/contactus"){
      //     return NextResponse.next();
      //   }else{
      //     return NextResponse.redirect(new URL("/verify", request.url));
      //   }
      // }


      // if (
      //   request.nextUrl.pathname.startsWith("/signin") ||
      //   request.nextUrl.pathname.startsWith("/signup") ||
      //   request.nextUrl.pathname.startsWith("/forgot") ||
      //   request.nextUrl.pathname.startsWith("/reset") ||
      //   request.nextUrl.pathname.startsWith("/resetpassword") ||
      //   request.nextUrl.pathname.startsWith("/emailverify")
      // ) {
      //   // Redirect authenticated users trying to access auth-related routes
      //   return NextResponse.redirect(new URL("/dashboard", request.url));
      // } else {
      //   return NextResponse.next();
      // }

      return NextResponse.next();
      
    } else {
      // const guestAllowedPaths = [
      //   "/signin", "/signup", "/forgot", "/resetpassword", "/emailverify",
      //   "/terms", "/privacy", "/aboutus", "/contactus"
      // ];

      // if (guestAllowedPaths.some((path) => pathname.startsWith(path))) {
      //   return NextResponse.next();
      // }

      // return NextResponse.redirect(new URL("/signin", request.url));

      if (
        request.nextUrl.pathname.startsWith("/profile-preview") ||
        request.nextUrl.pathname.startsWith("/withdraw") ||
        request.nextUrl.pathname.startsWith("/profile-setting")
        // request.nextUrl.pathname.startsWith("/forgot") ||
        // request.nextUrl.pathname.startsWith("/reset") ||
        // request.nextUrl.pathname.startsWith("/resetpassword") ||
        // request.nextUrl.pathname.startsWith("/emailverify") ||
        // request.nextUrl.pathname.startsWith("/terms") ||
        // request.nextUrl.pathname.startsWith("/privacy") ||
        // request.nextUrl.pathname.startsWith("/aboutus") ||
        // request.nextUrl.pathname.startsWith("/contactus") 
      
      ) {
        // Allow unauthenticated users to access auth-related routes
        // 
        return NextResponse.redirect(new URL("/", request.url));

      } else {
        // Redirect unauthenticated users to the sign-in page
        return NextResponse.next();
      }
    }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!assets|_next/static|_next/image|favicon.ico|charting-library|datafeeds).*)",
  ],
};

