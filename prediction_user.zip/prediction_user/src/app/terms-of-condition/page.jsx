"use client"
import React from 'react';
import { Container } from 'react-bootstrap';

const Page = () => {
	return (
		<main className="contentotherpages">
			<section className="innerpagebg">
				<Container>
					<h2 className="heading-title text-center pb-0 mb-0">Terms Of Condition</h2>
				</Container>
			</section>
			<section className="innerpagecontent sectionspace">
				<Container>
					<p className="content">By accessing and using PreditMark, you agree to comply with the terms and conditions of the platform. Users must provide accurate information during registration and are responsible for maintaining the confidentiality of their login credentials. Any activity performed through your account will be considered your responsibility.</p>
					<p className="content">PreditMark allows users to participate in prediction markets based on different events and market conditions. Users should understand that prediction markets involve uncertainty and financial risk. Participation on the platform is voluntary, and users should make decisions responsibly.</p>
					<p className="content">PreditMark reserves the right to modify platform features, suspend accounts, or terminate services if any misuse, violation of rules, or suspicious activity is detected. Continued use of the platform indicates acceptance of these terms and any future updates made by PreditMark.</p>
				</Container>
			</section>
		</main>
	);
}
export default Page;