"use client"
import React from 'react';
import { Container } from 'react-bootstrap';

const Page = () => {
	return (
		<main className="contentotherpages">
			<section className="innerpagebg">
				<Container>
					<h2 className="heading-title text-center pb-0 mb-0">Privacy Policy</h2>
				</Container>
			</section>
			<section className="innerpagecontent sectionspace">
				<Container>
					<p className="content">At PreditMark, we respect your privacy and are committed to protecting your personal information. When users register on our platform, we may collect basic details such as your name, email address, and account information to provide secure access and improve user experience. This information helps us manage accounts and provide our services effectively.</p>
					<p className="content">We may also collect technical information such as IP address, device type, browser details, and usage data. This information helps PreditMark maintain platform security, prevent fraudulent activities, and improve overall performance and functionality of the website.</p>
					<p className="content">PreditMark does not sell or share your personal information with unauthorized third parties. We implement appropriate security measures to protect user data from unauthorized access, misuse, or disclosure. By using our platform, you agree to the data practices described in this Privacy Policy.</p>
				</Container>
			</section>
		</main>
	);
}
export default Page;