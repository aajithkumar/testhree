"use client"
import React, { useEffect, useState } from "react";
import Link from 'next/link';
import { Container, Navbar, Nav, Image, NavDropdown, Modal, ModalBody, ModalHeader, ModalTitle, Form, FormControl, FormLabel, FormGroup, Button, InputGroup, Dropdown, DropdownToggle, DropdownMenu, DropdownItem, Offcanvas, OffcanvasHeader, OffcanvasTitle, OffcanvasBody } from 'react-bootstrap';
import { usePathname } from 'next/navigation'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck, faCaretDown, faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import Signup from "../hooks/useSignup";
import Signin from "../hooks/useSignin";
import Cookies from "js-cookie";
import Deposit from '../hooks/useDeposit';
import useCategory from "../hooks/useCategory";
import UserPortfolio from '../hooks/useUserPortfolio';


const Homeheader = () => {

  const pathname = usePathname();
  const baseURL = process.env.NEXT_PUBLIC_BASE_URL;
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleClose1 = () => setShow1(false);
  const handleShow1 = () => setShow1(true);

  const [isToken, setToken] = useState(false);

  const [canvasShow, setCanvasShow] = useState(false);
  const handleCloseCanvas = () => setCanvasShow(false);
  const handleShowCanvas = () => setCanvasShow(true);

  const { categories } = useCategory();

  const{ userPortfolio } =  UserPortfolio();
  

  // Deposit Modal
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [Depositview, setDepositview] = useState(false);
  const handleCloseDepositModal = () => setShowDepositModal(false);
  const handleShowDepositModal = () => {
    setDepositview(true);
    setShowDepositModal(true)
  };

  // Transfer Modal
  const [showTransferModal, setShowTransferModal] = useState(false);
  const handleCloseTransferModal = () => setShowTransferModal(false);
  const handleShowTransferModal = () => setShowTransferModal(true);

  const [username, setUsername] = useState(null);
  const [profileSrc, setProfileSrc] = useState(null);



  useEffect(() => {
    const checkAuth = () => {
      const token = Cookies.get("accessToken");

      if (token) {
        setToken(true);
        setUsername(Cookies.get("userName"));
        setProfileSrc(Cookies.get("userProfile"));
      } else {
        setToken(false);
        setUsername(null);
        setProfileSrc(null);
      }
    };
    checkAuth();
  }, [pathname]);

  const openSupportChat = () => {
      if (typeof window !== "undefined" && window.Tawk_API) {
          window.Tawk_API.maximize();
      }
  };


  return (
    <div>
      <header className="headermenu homeheader">
        <Navbar expand="lg" data-bs-theme="dark" className="headbg">
          <Container>
            <Navbar.Brand><Link href="/"><Image src="/assets/images/logo.svg" width={100} height={57} className="logo" alt="logo" /></Link></Navbar.Brand>
            <Navbar.Toggle aria-controls="offcanvasNavbar" onClick={handleShowCanvas} />
            <div className="d-lg-flex d-none align-items-center ms-auto">
              <Nav className="navbar-nav port-y">

                {isToken ?
                  // <Nav.Item><Link href="/logout" className="nav-link">Logout</Link></Nav.Item>

                  <>
                    <Nav.Item><Link href="/profile-preview" className="nav-link">Portfolio <h5>${parseFloat(userPortfolio?.open_positions_value_sum || 0).toFixed(2)}</h5> </Link></Nav.Item>
                    <Nav.Item><Link href="/profile-preview" className="nav-link">Cash <h5>${parseFloat(userPortfolio?.wallet_balance || 0).toFixed(2)}</h5></Link></Nav.Item>
                    <Nav.Item><Button id="register" className="nav-link btn sitebtn me-3" onClick={handleShowDepositModal}>Deposit</Button></Nav.Item>
                    <Nav.Item>
                      <Dropdown align="end" className="profile-ddowm">
                        <DropdownToggle id="prodropdown">
                          <Image src={"/assets/images/male.svg"} width={100} height={57} className="logo" alt="logo" />
                        </DropdownToggle>

                        <DropdownMenu>

                          <DropdownItem href="/profile-preview" as={Link} >
                            <div className="profile-info">
                              <Image src={"/assets/images/male.svg"} width={100} height={57} className="profile-info-icon" alt="logo" />
                              <div>
                                <h6 className="mb-0">{username ?? 'User'}</h6>
                              </div>
                            </div>
                          </DropdownItem>

                          <div className="px-3">
                            <hr className="my-1" />
                          </div>

                          {/* <DropdownItem href="/profile-preview" as={Link}>Preview</DropdownItem> */}
                          <DropdownItem href="/profile-setting?tab=profile" as={Link}>Setting</DropdownItem>
                          <DropdownItem href="/withdraw" as={Link}>Withdraw</DropdownItem>
                          <DropdownItem href="/profile-setting?tab=account" as={Link}>Account</DropdownItem>
                          <DropdownItem onClick={openSupportChat}>Support</DropdownItem>
                          <DropdownItem href="/support" as={Link}>Help Desk</DropdownItem>

                          
                          {/* <DropdownItem href="/profile-setting?tab=trading" as={Link}>Trading</DropdownItem>
                            <DropdownItem href="/profile-setting?tab=notifications" as={Link}>Notification</DropdownItem> */}
                          {/* <DropdownItem href="/profile-setting?tab=buildercodes" as={Link}>Builder Codes</DropdownItem>
                            <DropdownItem href="/profile-setting?tab=privatekey" as={Link}>Private Key</DropdownItem>
                            <DropdownItem href="#0">Support</DropdownItem> */}
                          {/* <div className="px-3">
                              <hr className="my-1" />
                            </div> */}

                          <div className="px-3">
                            <hr className="my-1" />
                          </div>
                          <DropdownItem href="/logout" className="offcanvas-lg-link">Sign Out</DropdownItem>
                        </DropdownMenu>
                      </Dropdown>
                    </Nav.Item>
                  </>
                  :
                  <>
                    <Nav.Item><Button id="login" className="nav-link btn borderbtn me-1" onClick={handleShow1}>Sign In</Button></Nav.Item>
                    <Nav.Item><Button id="register" className="nav-link btn sitebtn" onClick={handleShow}>Sign Up</Button></Nav.Item>
                  </>
                }


              </Nav>
            </div>
          </Container>
        </Navbar>
        <Navbar expand="lg" data-bs-theme="dark" className="headbg category-menu">
          <Container className="justify-content-start">
            {/* <Nav className="navbar-nav port-y">
                <Nav.Item><Link href="/" className={`nav-link ${pathname == "/" ? "active": ""}`}>All</Link></Nav.Item>
                <Nav.Item><Link href="/#" className="nav-link">Crypto</Link></Nav.Item>

                <Nav.Item><Link href="/#" className="nav-link">Sports</Link></Nav.Item>

                <Nav.Item><Link href="/#" className="nav-link">Politics</Link></Nav.Item>

                <Nav.Item><Link href="/#" className="nav-link">Finance</Link></Nav.Item>

                <Nav.Item><Link href="/#" className="nav-link">Tech</Link></Nav.Item>
                <Nav.Item><Link href="/#" className="nav-link">Media</Link></Nav.Item>
          </Nav> */}
            <Nav className="navbar-nav port-y">

              {/* All Menu */}
              <Nav.Item>
                <Link
                  href="/"
                  className={`nav-link ${pathname === "/" ? "active" : ""}`}
                >
                  Trending
                </Link>
              </Nav.Item>

              {/* Dynamic Categories */}
              {categories?.map((item) => (
                <Nav.Item key={item.id}>
                  <Link
                    href={`/${item.slug}`}
                    className={`nav-link ${pathname === `/${item.slug}` ? "active" : ""}`}
                  >
                    {item.name.charAt(0).toUpperCase() + item.name.slice(1)}
                  </Link>
                </Nav.Item>

              ))}

            </Nav>
          </Container>
        </Navbar>
      </header>

      <Offcanvas show={canvasShow} id="offcanvasNavbar" onHide={handleCloseCanvas} className="home-offcanvas">
        <OffcanvasHeader closeButton>
          <OffcanvasTitle>
            <Image src="/assets/images/logo.svg" width={100} height={57} className="logo" alt="logo" />
          </OffcanvasTitle>
        </OffcanvasHeader>


        <OffcanvasBody>

        {isToken ? 
          <>
            <Link href="/profile-preview" className="offcanvas-profile-info" style={{ textDecoration: "underline" }}>
              <Image src="assets/images/male.svg" width={100} height={57} className="offcanvas-profile-icon" alt="logo" />
              <div>
                <h6 className="mb-0">{username ?? 'User'}</h6>
              </div>
            </Link>

            <div className="offcanvas-nav-link-align">
                {/* <Link href="/profile-preview" className="offcanvas-link">Preview</Link> */}
                <Link href="/profile-setting?tab=profile" className="offcanvas-link">Setting</Link>
                <Link href="/withdraw" className="offcanvas-link">Withdraw</Link>
                <Link href="/profile-setting?tab=account" className="offcanvas-link">Account</Link>
                <DropdownItem onClick={openSupportChat}>Support</DropdownItem>

              </div>
            <hr />
            <a href="/logout" className="offcanvas-lg-link">Sign Out</a>
            <hr />
          </>
          :
          <>
              <div className="offcanvas-nav-link-align">
                <Link href="" onClick={handleShow1} className="offcanvas-link">Sign In</Link>
                <Link href="" onClick={handleShow} className="offcanvas-link">Sign Up</Link>
              </div>
          </>
        }
        </OffcanvasBody>
      </Offcanvas>


      {/* SignUp Modal */}
      <Signup showSignup={show} handleClose={handleClose} />

      {/* Sign In Modal */}
      <Signin showSignin={show1} handleClose1={handleClose1} />

      {/* Deposit Modal */}
      {isToken && Depositview && (
        <Deposit
          showDepositModal={showDepositModal}
          handleCloseDepositModal={handleCloseDepositModal}
          setShowDepositModal={setShowDepositModal}
          setShowTransferModal={setShowTransferModal}
          showTransferModal={showTransferModal}
          handleCloseTransferModal={handleCloseTransferModal}
        />
      )}



    </div>
  )
}

export default Homeheader