"use client";

import React, { useEffect, useState } from "react";
import {
    Chart as ChartJS,
    LineElement,
    PointElement,
    LinearScale,
    CategoryScale,
    Tooltip,
    Legend
} from "chart.js";
import { Line } from "react-chartjs-2";
import { getHomechartData } from '@/app/api_components/auth';

ChartJS.register(
    LineElement,
    PointElement,
    LinearScale,
    CategoryScale,
    Tooltip,
    Legend
);

const options = {
    responsive: true,
    maintainAspectRatio: false,

    interaction: {
        mode: "index",
        intersect: false
    },

    plugins: {
        legend: {
            display: false
        },
        tooltip: {
            backgroundColor: "#111827",
            borderColor: "#374151",
            borderWidth: 1,
            titleColor: "#fff",
            bodyColor: "#fff",
            callbacks: {
                label: ctx => `${ctx.dataset.label}: ${ctx.raw}%`
            }
        }
    },

    scales: {
        x: {
            grid: { display: false },
            ticks: { color: "#6b7280" }
        },
        y: {
            position: "right",
            min: 0,
            max: 100,
            ticks: {
                stepSize: 20,
                color: "#9ca3af",
                callback: v => v + "%"
            },
            grid: {
                color: "rgba(255,255,255,0.08)",
                borderDash: [4, 4]
            }
        }
    }
};

const HomePredictChart = React.memo(function HomePredictChart({ marketID }) {

    const [chartData, setChartData] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {

        const loadChartData = async () => {
            try {
                const result = await getHomechartData(marketID);

                // ✅ IMPORTANT: replace data (no nested array issue)
                setChartData(prev => ({
                    ...prev,
                    [marketID]: {
                        id: marketID,
                        yes: result?.yes || [],
                        no: result?.no || []
                    }
                }));

            } catch (error) {
                console.error("Chart API Error:", error);
            } finally {
                setLoading(false);
            }
        };

        if (marketID) {
            loadChartData();
        }

    }, [marketID]);

    const formatChartData = () => {

        const marketData = chartData[marketID];

        if (!marketData) {
            return { labels: [], datasets: [] };
        }

        const yesData = marketData.yes || [];
        const noData = marketData.no || [];

        if (!yesData.length) {
            return { labels: [], datasets: [] };
        }

        // Convert timestamp → label
        const labels = yesData.map(item => {
            const date = new Date(item.t * 1000);
            return date.toLocaleDateString("en-US", {
                month: "short",
                day: "numeric"
            });
        });

        return {
            labels,
            datasets: [
                {
                    label: "YES",
                    data: yesData.map(item =>
                        Math.round(Number(item.p) * 100)
                    ),
                    borderColor: "#10B981",
                    borderWidth: 2,
                    tension: 0.35,
                    pointRadius: ctx =>
                        ctx.dataIndex === yesData.length - 1 ? 5 : 0,
                    pointBackgroundColor: "#10B981"
                },
                {
                    label: "NO",
                    data: noData.map(item =>
                        Math.round(Number(item.p) * 100)
                    ),
                    borderColor: "#EF4444",
                    borderWidth: 2,
                    tension: 0.35,
                    pointRadius: ctx =>
                        ctx.dataIndex === noData.length - 1 ? 5 : 0,
                    pointBackgroundColor: "#EF4444"
                }
            ]
        };
    };

    return (
        <div style={{ height: "330px", width: "100%", padding: "10px" }}>
            {loading ? (
                <p style={{ color: "#999" }}>Loading chart...</p>
            ) : (
                <Line data={formatChartData()} options={options} />
            )}
        </div>
    );
});

export default HomePredictChart;