"use client"
import React, { useState, useEffect } from "react";
import Link from 'next/link';
import { Container, Navbar, Nav, Image, Modal, ModalHeader, ModalTitle, ModalBody, Button, FormGroup, FormLabel, FormSelect, FormControl, InputGroup, Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleLeft, faBars } from '@fortawesome/free-solid-svg-icons';
import { CopyCheckIcon, CopyIcon, InfoIcon, SettingsIcon } from '../components/HomeIcons';
import { usePathname } from "next/navigation";
import Deposit from '../hooks/useDeposit';

const UserHeader = () => {

    const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth > 1080) {
                document.getElementById("leftsidemenu")?.classList.remove("active");
                document.getElementById("backgroundoverlay")?.classList.remove("active");
            }
        }
        window.addEventListener('resize', handleResize)
        return () => window.removeEventListener('resize', handleResize)
    }, [])

    useEffect(() => {
        document.body.classList.add('userpanelpage');
        document.body.classList.remove('loginbanner');
        return () => {
            document.body.classList.remove('userpanelpage');
        }
    }, [])
    // Deposit Modal
    const [showDepositModal, setShowDepositModal] = useState(false);
    const handleCloseDepositModal = () => setShowDepositModal(false);
    const handleShowDepositModal = () => setShowDepositModal(true);

    // Transfer Modal
    const [showTransferModal, setShowTransferModal] = useState(false);
    const handleCloseTransferModal = () => setShowTransferModal(false);
    const handleShowTransferModal = () => setShowTransferModal(true);

    const pathname = usePathname();

    return (
        <div>
            <header className="headermenu homeheader">
                <Navbar expand="lg" className="headbg">
                    <Container>
                        <button className={`mobiletogglebtn ${pathname === '/market-trade' ? 'd-none' : ''}`} onClick={() => {
                            document.getElementById("leftsidemenu")?.classList.add("active");
                            document.getElementById("backgroundoverlay")?.classList.add("active");
                        }}>
                            <FontAwesomeIcon icon={faBars} />
                        </button>
                        <Navbar.Brand><Link href="/"><Image src={`${baseURL}/assets/images/logo.svg`} width={100} height={57} className="logo" alt="logo" /></Link></Navbar.Brand>
                        <Navbar.Toggle aria-controls="basic-navbar-nav" />
                        <Navbar.Collapse id="basic-navbar-nav">
                            <Nav className="navbar-nav ms-auto port-y">
                                <Nav.Item><Link href="/#" className="nav-link">Portfolio <h5>$0.00</h5> </Link></Nav.Item>
                                <Nav.Item><Link href="/#" className="nav-link">Cash <h5>$0.00</h5></Link></Nav.Item>
                                <Nav.Item><Button href="#0" id="register" className="nav-link btn sitebtn me-3" onClick={handleShowDepositModal}>Deposit</Button></Nav.Item>
                                <Nav.Item>

                                    <Dropdown align="end" className="profile-ddowm">
                                        <DropdownToggle id="prodropdown">
                                            <Image src={`${baseURL}/assets/images/male.svg`} width={100} height={57} className="logo" alt="logo" />
                                        </DropdownToggle>

                                        <DropdownMenu>

                                            <DropdownItem href="/profile-settings" as={Link}>
                                                <div className="profile-info">
                                                    <Image src={`${baseURL}/assets/images/male.svg`} width={100} height={57} className="profile-info-icon" alt="logo" />
                                                    <div>
                                                        <h6 className="mb-0">John Smith</h6>
                                                    </div>
                                                </div>
                                            </DropdownItem>

                                            <div className="px-3">
                                                <hr className="my-1" />
                                            </div>

                                            <DropdownItem href="/profile-preview" as={Link}>Profile</DropdownItem>

                                            <DropdownItem href="#">Account</DropdownItem>
                                            <DropdownItem href="#">Trading</DropdownItem>
                                            <DropdownItem href="#">Notification</DropdownItem>
                                            <DropdownItem href="#">Builder Codes</DropdownItem>
                                            <DropdownItem href="#">Private Key</DropdownItem>
                                            <DropdownItem href="#">Support</DropdownItem>
                                            <div className="px-3">
                                                <hr className="my-1" />
                                            </div>
                                            <DropdownItem href="/logout" >Log Out</DropdownItem>
                                        </DropdownMenu>
                                    </Dropdown>
                                </Nav.Item>
                            </Nav>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>
            </header>

            {/* Deposit Modal */}
            <Deposit showDepositModal={showDepositModal} handleCloseDepositModal={handleCloseDepositModal} setShowDepositModal={setShowDepositModal} setShowTransferModal={setShowTransferModal} showTransferModal={showTransferModal} handleCloseTransferModal={handleCloseTransferModal} />

        </div>
    )
}

export default UserHeader