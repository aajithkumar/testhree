import React, { useEffect, useState }  from "react";
import Link from 'next/link';
import { Container, Image, Row, Col, Form, InputGroup, Button } from 'react-bootstrap';
import { faSearch, faBook, faIdCard, faBuilding } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Signup from "../hooks/useSignup";
import Signin from "../hooks/useSignin";
import Cookies from "js-cookie";

const Homefooter = () => {

    const [show, setShow] = useState(false);
    const [show1, setShow1] = useState(false);
    
    const handleClose  = ()  => setShow(false);
    const handleShow   = ()   => setShow(true);
    const handleClose1 = () => setShow1(false);
    const handleShow1  = ()  => setShow1(true);

    const [isToken, setToken] = useState(false);


    useEffect(() => {
        const token = Cookies.get('accessToken');
        if (token) {
            setToken(true);
        } else {
            setToken(false);
        }
    }, []);





    return (
        <footer className="homefooter">
            <section className="footer-gray-bg fnt-reg">
                <Container>
                    <Row>
                        <Col lg={4} md={6} sm={12}>
                            <div className="footlogo">
                                <Image src="/assets/images/logo.svg" className="flogo" />
                            </div>
                            <p>Predict real-world outcomes and trade on what you believe will happen.
                                Turn insights into opportunities with transparent, data-driven markets.
                            </p>
                            <p>
                                Copyright © 2026 Predimark. All rights reserved.
                            </p>
                        </Col>
                        <Col lg={3} md={6} sm={12}>
                            <h3 className="h3">Menu</h3>
                            <ul className="foot-list">
                                <li><Link href="">Categories</Link></li>
                                <li><Link href="/">Live</Link></li>
                                <li><Link href="" >Help</Link></li>
                                {/* <li><Link href="/">Sign in</Link></li>
                                <li><Link href="">Sign Up</Link></li> */}
                                {!isToken &&  
                                    <>
                                        <li><Link href="" onClick={handleShow1}>Sign In</Link></li>
                                        <li><Link  href="" onClick={handleShow}>Sign Up</Link></li>
                                    </>
                                }
                            </ul>
                        </Col>
                        <Col lg={3} md={6} sm={12}>
                            <h3 className="h3">Links</h3>
                            <ul className="foot-list">
                                <li><Link href="/aboutus">About</Link></li>
                                <li>
                                <Link 
                                    href="https://mail.google.com/mail/u/0/?fs=1&tf=cm&source=mailto&to=hello@coinsclone.com" 
                                    target="_blank"
                                >
                                    Contact Us
                                </Link>
                                </li>
                                <li><Link href="/terms-of-condition">Terms and conditions</Link></li>
                                <li><Link href="/privacy-policy">Privacy policy</Link></li>
                            </ul>
                        </Col>
                        <Col lg={2} md={6} sm={12}>
                            <h3 className="h3">Follow us on</h3>
                            <ul className="foot-list">
                                <li><Link href="/">X (Twitter)
                                </Link></li>
                                <li><Link href="/">Discord
                                </Link></li>
                                <li><Link href="/">Instagram
                                </Link></li>
                                <li><Link href="/">Reddit
                                </Link></li>
                                <li><Link href="/">TikTok</Link></li>
                            </ul>
                        </Col>
                    </Row>
                </Container>
            </section>

            {/* SignUp Modal */}
            <Signup showSignup={show} handleClose={handleClose} />
    
            {/* Sign In Modal */}
            <Signin showSignin={show1} handleClose1={handleClose1} />
        </footer>
    )
}
export default Homefooter