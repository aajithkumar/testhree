"use client";
import { useEffect } from "react";

export default function TawkChat() {
  useEffect(() => {

    window.Tawk_API = window.Tawk_API || {};
    window.Tawk_LoadStart = new Date();

    // window.Tawk_API.onBeforeLoad = function () {
    //   window.Tawk_API.hideWidget();
    // };

    const script = document.createElement("script");
    script.src = "https://embed.tawk.to/69b3fcc2406cbe1c37cf18a0/1jjjh6nnj";
    script.async = true;
    script.charset = "UTF-8";
    script.setAttribute("crossorigin","*");

    document.body.appendChild(script);

  }, []);

  return null;
}