import Cookies from "js-cookie";
import { useRouter } from 'next/navigation';
import {  earnBalance, getUserProfile } from "./api_components/user";

let csrfPromise = null;
let is_demo = process.env.NEXT_PUBLIC_IS_DEMO === 'true' ? true : false; 
 

// GET CSRT TOKEN
async function ensureCsrfCookie() {
    const currentToken = Cookies.get('XSRF-TOKEN');
    if (currentToken) return currentToken;

    if (!csrfPromise) {
        csrfPromise = (async () => {
            await fetch(`${process.env.NEXT_PUBLIC_BACKEND_BASE_URL}/sanctum/csrf-cookie`, {
                method: 'GET',
                credentials: 'include',
            });

            // wait until cookie is visible (retry up to 10x)
            for (let i = 0; i < 10; i++) {
                const token = Cookies.get('XSRF-TOKEN');
                if (token) return token;
                await new Promise(r => setTimeout(r, 20));
            }

            // return whatever we have (even if null)
            return Cookies.get('XSRF-TOKEN');
        })()
        .finally(() => {
            csrfPromise = null; // allow next attempt in future
        });
    }

    return csrfPromise;
}


/**
 * Handles the success response from an API call.
 * @param result - The result object from the API call.
 * @param toast - The toast object for displaying success messages.
 * @param formik - The formik object for handling form state.
 * @param setErrors - The function for setting form errors.
 */
export const handleSuccess = (result, { toast = null, formik = null, setErrors = null } = {}) => {
    toast?.success?.(result?.message || "Success");

    formik?.resetForm?.({});     // safer than handleReset
    setErrors?.({});
};


// FORMART WITH COMMAS
export const  formatNumberWithCommas = (input)  => {
    const numberStr = String(input); 
    const [integerPart, decimalPart] = numberStr.split('.');
    const formattedInteger = parseInt(integerPart, 10).toLocaleString('en-US');
    return decimalPart !== undefined ? `${formattedInteger}.${decimalPart}` : formattedInteger;
}

// EARN BALANCE CHECK
export const earnBalanceFetch = async () => {
    try {
        const res = await earnBalance();
        if (res.status) {
            return res.data; 
        }
        return null; // If no wallet data
    } catch (error) {
        console.error("Error fetching earn balance:", error);
        return null;
    }
};


export const fetchAffiliateStatus = async () => {
    try {
        const result = await getUserProfile();
        if (result.status === true) {
            return result.data;
        }
        } catch (error) {
            console.error("Error fetching user affiliate status:", error);
            return null;
        }
};


/**
 * Handles the error response from an API call.
 * @param result - The result object from the API call.
 * @param toast - The toast object for displaying error messages.
 * @param setErrors - The function for setting form errors.
 */
export const handleFail = (result, { toast = null, setErrors = null } = {} ) => {
    toast?.error?.(result?.message || "Something went wrong");

    setErrors?.(result?.data || {});
};

/**
 * Retrieves the authentication token from the cookies.
 * @returns The authentication token.
 */
export async function getAuthToken() {
    const accessToken = Cookies.get("accessToken"); 
    return accessToken;
}

function getLanguage() {
    const lang = Cookies.get("lang"); 
    return lang || 'en';
}

/**
 * Performs an AJAX request without including the authentication token.
 * @param url - The URL for the AJAX request.
 * @param values - The request payload.
 * @param setIsLoading - The function for setting the loading state.
 * @param toast - The toast object for displaying error messages.
 * @returns The response from the AJAX request.
 */

// NO TOKENS
export const ajaxNotTkn = async (url, values = '', { setIsLoading, toast } = {}, setJSONData = false) => {
    try {
        if (setIsLoading && toast) {
            setIsLoading(true);
        }

          
        if (is_demo == true) {

            var response = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    "Accept-Language": getLanguage(),
                    'Content-Type': setJSONData ? '' : 'application/json',
                },
                body: setJSONData ? values : JSON.stringify(values),
            });

        } else {

                var xsrftoken = Cookies.get('XSRF-TOKEN');
                if(xsrftoken == '' || xsrftoken == undefined || xsrftoken == null){
                    xsrftoken = await ensureCsrfCookie(); // 🔹 safe, promise-cached, race-proof
                    // xsrftoken = Cookies.get('XSRF-TOKEN');
                }
                let apiUrl = `${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`;

                 response = await fetch(apiUrl, {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': setJSONData ? '' : 'application/json',
                        "Accept-Language": getLanguage(),
                        'X-XSRF-TOKEN': xsrftoken,

                    },
                    body: setJSONData ? values : JSON.stringify(values),
                    credentials: "include",
                });
        }

        if (setIsLoading && toast) {
            setIsLoading(false);
        }

        return await response.json();
    } catch (error) {
        if (error instanceof Error) {
            if (setIsLoading && toast) {
                setIsLoading(false);
                // console.log(error.message);  // Accessing the error message
                toast.error('An unknown error occurred.',error);  // Handle non-Error case
            }
        } else {

            if (setIsLoading && toast) {
                setIsLoading(false);
                toast.error('An unknown error occurred.',error);  // Handle non-Error case
            }
        }
    }
};

// WITH TOKENS

export const ajaxWithTkn = async (url, values = '', { setIsLoading, toast } = {}, setIsFile = false) => {

    try {
        if (setIsLoading && toast) {
            setIsLoading(true);
        } 

          if (is_demo == true) {

            const accessToken = await getAuthToken() || '';
            var response = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`, {
                method: 'POST',
                headers: handleHeaders(setIsFile, accessToken),
                body: values ? handleValues(values, setIsFile) : undefined,
            });

        } else {
        
            var xsrftoken = Cookies.get('XSRF-TOKEN');
            if(xsrftoken == '' || xsrftoken == undefined || xsrftoken == null){
                xsrftoken = await ensureCsrfCookie(); // 🔹 safe, promise-cached, race-proof
            }

            const accessToken = await getAuthToken() || '';

            let apiUrl = `${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`;
            response = await fetch(apiUrl, {
                method: 'POST',
                headers: handleHeaders(setIsFile, xsrftoken),
                body: values ? handleValues(values, setIsFile) : undefined,
                credentials: "include",
            });
        }

        if (setIsLoading && toast) {
            setIsLoading(false);
        }
        const data = await response.json();

        if ( response.status === 401 && response.statusText === 'Unauthorized' ){
            handleLogout();
            window.location.href='/logout' // Redirect to logout page
            return;
        }

     
        return data;
    } catch (error) {
        if (error instanceof Error) {
            
    
            if (setIsLoading && toast) {
                setIsLoading(false);
                console.log(error.message);
                toast.error('An unknown error occurred.');  // Safely access error.message
            }
        } else {
            // console.log('An unknown error occurred.');
    
            if (setIsLoading && toast) {
                setIsLoading(false);
                toast.error('An unknown error occurred.');  // Handle non-Error case
            }
        }
    }
};


// Handles headers for AJAX requests
const handleHeaders = (setIsFile, token='') => {

    if(is_demo == true){

        if (setIsFile) {
            // No Content-Type for file uploads (handled by FormData)
            return {
                'Authorization': `Bearer ${token}`,
                "Accept-Language": getLanguage()
            };
        } else {
            // For JSON requests, set Content-Type
            return {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
                "Accept-Language": getLanguage()
            };
        }

    } else {

        var xsrftoken=Cookies.get('XSRF-TOKEN'); 
        if(token != ''){
            xsrftoken=token;
        }

        if (setIsFile) {
            // No Content-Type for file uploads (handled by FormData)
            return {
                'X-XSRF-TOKEN': xsrftoken,
                "Accept-Language": getLanguage()
            };
        } else {
            // For JSON requests, set Content-Type
            return {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-XSRF-TOKEN': xsrftoken,
                "Accept-Language": getLanguage()
                // 'Authorization': `Bearer ${token}`,
            };
        }
    }


};

// Handles values for AJAX requests
const handleValues = (values, setIsFile) => {
    if (setIsFile) {
        return values;
    } else {
        return JSON.stringify(values);
    }
};

// Function to handle user logout
const handleLogout = () => {
    Cookies.remove("userId");
    Cookies.remove("userName");
    Cookies.remove("userEmail");
    Cookies.remove("twofa");
    Cookies.remove("accessToken");
    Cookies.remove("verifytwofa");
    Cookies.remove("tickerId");
    Cookies.remove("userProfile");
    Cookies.remove("account_verify_email");
};


// Function to handle user logout
export const Sesssion_clearcookies = () => {
    Cookies.remove("userId");
    Cookies.remove("userName");
    Cookies.remove("userEmail");
    Cookies.remove("twofa");
    Cookies.remove("accessToken");
    Cookies.remove("isAuthenticated");
    Cookies.remove("profileimg");
    Cookies.remove("verifytwofa");
    Cookies.remove("tickerId");
    Cookies.remove("userProfile");
    Cookies.remove("XSRF-TOKEN");
};







// DON'T USING PARTS STRATS

export const ajaxNotTknJson = async (url, values = '', { setIsLoading, toast } = {}, setJSONData = false) => {
    try {
        if (setIsLoading && toast) {
            setIsLoading(true);
        }

          if (is_demo == true) {

            var response = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': setJSONData ? '' : 'application/json',
                },
                body: setJSONData ? values : JSON.stringify(values),
            });

        } else {

        var xsrftoken = Cookies.get('XSRF-TOKEN');
        if(xsrftoken == '' || xsrftoken == undefined || xsrftoken == null){
            xsrftoken = await ensureCsrfCookie(); // 🔹 safe, promise-cached, race-proof
        }
          let apiUrl = `${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`;
         response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-XSRF-TOKEN': xsrftoken,
            },
            body: values,
            credentials: "include",
        });
    }

        if (setIsLoading && toast) {
            setIsLoading(false);
        }
        return await response.json();
    } catch (error) {
        if (error instanceof Error) {
            // console.log(error.message);  // Accessing the error message
            if (setIsLoading && toast) {
                setIsLoading(false);
                toast.error(error.message); // Display the error message in a toast
            }
        } else {
            console.log('An unknown error occurred.');
            if (setIsLoading && toast) {
                setIsLoading(false);
            }
        }
    }
};

export const ajaxGetNotTkn = async (url, values = '', { setIsLoading, toast } = {}, setJSONData = false) => {
    try {
        if (setIsLoading && toast) {
            setIsLoading(true);
        }
  if (is_demo == true) {

            var response = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': setJSONData ? '' : 'application/json',
                },
                body: setJSONData ? values : JSON.stringify(values),
            });

        } else {
        var xsrftoken = Cookies.get('XSRF-TOKEN');
        if(xsrftoken == '' || xsrftoken == undefined || xsrftoken == null){
            xsrftoken = await ensureCsrfCookie(); // 🔹 safe, promise-cached, race-proof
        }
         
        let apiUrl = `${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`;
         response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': setJSONData ? '' : 'application/json',
                "Accept-Language": getLanguage(),
                'X-XSRF-TOKEN': xsrftoken,
            },
            credentials: "include",
        });
    }

        if (setIsLoading && toast) {
            setIsLoading(false);
        }

        return await response.json();
    } catch (error) {
        if (error instanceof Error) {
            // console.log(error.message);  // Accessing the error message
            if (setIsLoading && toast) {
                setIsLoading(false);
                toast.error(error.message); // Display the error message in a toast
            }
        } else {
            // console.log('An unknown error occurred.');
            if (setIsLoading && toast) {
                setIsLoading(false);
            }
        }
    }
};

/**
 * Performs an AJAX request including the authentication token.
 * @param url - The URL for the AJAX request.
 * @param values - The request payload.
 * @param setIsLoading - The function for setting the loading state.
 * @param toast - The toast object for displaying error messages.
 * @returns The response from the AJAX request.
 */


export const ajaxGETTkn = async (url, values = '', { setIsLoading, toast } = {}, setIsFile = false) => {
    try {
        if (setIsLoading && toast) {
            setIsLoading(true);
        }

          if (is_demo == true) {

            var response = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`, {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': setJSONData ? '' : 'application/json',
                },
                body: setJSONData ? values : JSON.stringify(values),
            });

        } else {
        const accessToken = await getAuthToken() || '';
        let apiUrl = `${process.env.NEXT_PUBLIC_BACKEND_URL}/${url}`;
         response = await fetch(apiUrl, {
            method: 'GET',
            headers: handleHeaders(setIsFile, accessToken)
        });
    }

        if (setIsLoading && toast) {
            setIsLoading(false);
        }
        const data = await response.json();

        // Check for specific conditions to logout
        if (response.status === 401 && response.statusText === 'Unauthorized') {
            handleLogout();
            window.location.href = '/logout' // Redirect to logout page
            return;
        }

        return data;
    }
    catch (error) {
        if (error instanceof Error) {
            // console.log(error.message);

            if (setIsLoading && toast) {
                setIsLoading(false);
                toast.error(error.message);  // Safely access error.message
            }
        } else {
            // console.log('An unknown error occurred.');

            if (setIsLoading && toast) {
                setIsLoading(false);
                toast.error('An unknown error occurred.');  // Handle non-Error case
            }
        }
    }
};

// DON'T USING PARTS ENDS


// Date formatting
export const formatDate = (dateString) => {
  const date = new Date(dateString)

  return date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  })
};

export const  formatDateTime = (date) => {
  const diff = Math.floor((new Date() - new Date(date)) / 60000);
  if (diff < 60) return `${diff} mins ago`;
  if (diff < 1440) return `${Math.floor(diff / 60)} hours ago`;
  return `${Math.floor(diff / 1440)} days ago`;
};

// Text Capitalize
export const capitalizeFirstLetter = (text) => {
  if (!text) return "";
  return text.charAt(0).toUpperCase() + text.slice(1);
};

// Dollar formatting
export const formatDollarShort = (value) => {
  if (!value) return "$0";

  const num = Number(value);
  if (num >= 1_000_000_000) {
    return `$${(num / 1_000_000_000).toFixed(1).replace(/\.0$/, "")}B`;
  }

  if (num >= 1_000_000) {
    return `$${(num / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`;
  }

  if (num >= 1_000) {
    return `$${(num / 1_000).toFixed(0)}K`;
  }

  return `$${num}`;
};

// Convert to percentage
export const toPercentage = (value) => {
  if (value === null || value === undefined) return "0%";
  const num = Number(value) * 100;
  return `${num}%`;
}
