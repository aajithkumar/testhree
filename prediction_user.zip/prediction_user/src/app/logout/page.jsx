"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import Cookies from "js-cookie";
import { logout } from "../api_components/user";
import { toast } from "react-toastify";

export default function Logout() {
  const router = useRouter();

  useEffect(() => {
    const logoutUser = async () => {
      try {
        await logout();

        // remove cookies
        Cookies.remove("accessToken");
        Cookies.remove("userId");
        Cookies.remove("userName");
        Cookies.remove("userEmail");
        Cookies.remove("userProfile");

        toast.success("Success! Sign Out successfully");

        router.push("/");
        router.refresh();
      } catch (error) {
        console.error(error);
        router.push("/");
      }
    };

    logoutUser();
  }, [router]);

  return (
    <div style={{ textAlign: "center", padding: "40px" }}>
      Logging out...
    </div>
  );
}