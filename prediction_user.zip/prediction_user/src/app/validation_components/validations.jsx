import * as Yup from 'yup';

const expiryDate = new Date().toISOString().split('T')[0];

const passwordValidationSchema = Yup.string()
    .required('Password is required')
    .min(8, 'Minimum 8 characters allowed')
    .max(100, 'Maximum 100 characters allowed')
    .matches(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$/, 'Invalid password');

const oldpasswordValidationSchema = Yup.string()
    .required('Current password is required')
    .min(8, 'Minimum 8 characters allowed')
    .max(100, 'Maximum 100 characters allowed')
    .matches(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$/, 'Invalid Current password');

const newpasswordValidationSchema = Yup.string()
    .required('New password is required')
    .min(8, 'Minimum 8 characters allowed')
    .max(100, 'Maximum 100 characters allowed')
    .matches(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$/, 'Invalid New password');

const socialMediaValidationSchema = Yup.string()
        .max(100, 'Maximum 100 characters allowed');

const validationSchema = (pickArray) => {
    const fields = {
        email: Yup.string()
            .email('Invalid email address')
            .required('Email address is required')
            .max(100, 'Maximum 100 characters allowed')
            // .matches(/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/, 'Invalid email address'),
            .matches(
                /^([a-zA-Z0-9+_\-]+)(\.[a-zA-Z0-9+_\-]+)*@([a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,6}$/,
                'Invalid email address'
            ),
        recaptcha: Yup.string()
            .required('Recaptcha field is required'),
        phone_no: Yup.string()
            .matches(/^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/, 'Phone Number is not valid')
            .min(8, 'Minimum 8 numbers allowed'),
        username: Yup.string()
            .required('User Name field is required')
            .max(30, 'Maximum 30 characters allowed')
            .matches(/^[a-zA-Z\s]+$/, 'Invalid User Name'),
        name: Yup.string()
            .required('Name field is required')
            .max(30, 'Maximum 30 characters allowed')
            .matches(/^[a-zA-Z\s]+$/, 'Invalid Name'),
        fullname: Yup.string()
            .required('Full name is required')
            .max(30, 'Maximum 30 characters allowed')
            .matches(/^[a-zA-Z\s]+$/, 'Invalid Full name'),
        old_password: oldpasswordValidationSchema,
        password: passwordValidationSchema,
        newpassword: newpasswordValidationSchema,
        c_new_password: Yup.string()
            .required('Confirm Password is required')
            .min(8, 'Minimum 8 characters allowed')
            .max(100, 'Maximum 100 characters allowed')
            .matches(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$/, 'Invalid Confirm Password')
            .oneOf([Yup.ref('newpassword'), ''], 'Confirm Password must match'),
        c_password: Yup.string()
            .required('Confirm Password is required')
            .min(8, 'Minimum 8 characters allowed')
            .max(100, 'Maximum 100 characters allowed')
            .matches(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$/, 'Invalid Confirm Password')
            .oneOf([Yup.ref('password')], 'Confirm Password must match'),
        otp: Yup.string()
            .required('Verification code is required')
            .min(6, 'Verification code must be 6 digits')
            .max(6, 'Verification code must be 6 digits'),
        subscribeEmail: Yup.string()
            .email('Invalid subscribe email address')
            .required('The email subscribe field is required.')
            .max(100, 'Maximum 100 characters allowed')
            // .matches(/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/, 'Invalid Email Address'),
            .matches(
                /^([a-zA-Z0-9+_\-]+)(\.[a-zA-Z0-9+_\-]+)*@([a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,6}$/,
                'Invalid email address'
            ),
        title: Yup.string()
            .required('Title field is required')
            .min(2, 'Minimum 2 characters allowed')
            .max(500, 'Maximum 191 characters allowed'),
        message: Yup.string()
            .required('Message field is required')
            .min(2, 'Minimum 2 characters allowed')
            .max(500, 'Maximum 500 characters allowed'),
        subject: Yup.string()
            .required('Subject field is required'),
        ticket_image: Yup.mixed()
            .test(
                'fileSize',
                'File is too large. Max size is 10MB',
                (value) => !value || value.size <= 10 * 1024 * 1024
            )
            .test(
                'fileType',
                'Unsupported file type. Only JPG, PNG are allowed',
                (value) => !value || ['image/jpeg', 'image/png', 'image/jpg'].includes(value.type)
            ),
        code: Yup.string()
            .required('Code is required')
            .min(6, 'Code must be 6 digits')
            .max(6, 'Code must be 6 digits'),
        recoveryKeyCode: Yup.string()
            .required('Recovery key is required')
            .min(2, 'Recovery key must be at least 3 characters')
            .max(20, 'Recovery key may not be greater than 20 characters')
            .matches(/^[a-zA-Z\s]+$/, 'Recovery key must only contain letters'),
        fname: Yup.string()
            .required('First Name is required')
            .max(30, 'Maximum 30 characters allowed')
            .matches(/^[a-zA-Z\s]+$/, 'Invalid First Name'),
        lname: Yup.string()
            .required('Last Name is required')
            .max(30, 'Maximum 30 characters allowed')
            .matches(/^[a-zA-Z\s]+$/, 'Invalid Last Name'),
        country: Yup.string()
                .required('Country is required'),
        id_type: Yup.string()
                .required('Document Type is required'),
        id_number: Yup.string()
                .required('Document Number is required')
                .max(100, 'Maxium 100 characters allowed')
                .matches(/^[A-Za-z0-9]+$/, 'Invalid Document Number'),
        id_exp: Yup.date()
                .required('Expire Date is required')
                .min(expiryDate, 'Expire date must be a future date'),
        anti_phishing_code: Yup.string()
                .required('Anti-Phishing Code is required')
                .min(4, 'Minimum 4 characters allowed')
                .max(30, 'Maximum 30 characters allowed'),
        birth_date: Yup.date()
                .required('Date of birth is required')
                .max(new Date(), 'Future dates are not allowed for Date of birth.'),
        bio: Yup.string()
                .required('Bio is required')
                .max(500, 'Maximum 500 characters allowed'),
        twitter_id: socialMediaValidationSchema,
        instagram_id: socialMediaValidationSchema,
        telegram_id: socialMediaValidationSchema,
        website: socialMediaValidationSchema,
        front_img: Yup.mixed()
            .required('ID Front Document is required')
            .test(
                'fileType',
                'Only JPG, PNG, and JPEG formats are allowed',
                (value) => {
                    if (!value) return false; // Check if the value is present
                    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
                    return value && allowedTypes.includes(value.type);
                }
            )
            .test(
                'fileSize',
                'File size must be less than 10MB',
                (value) => {
                    const fileSizeLimit = 10097152; // 10MB
                    return value && value.size <= fileSizeLimit;
                }
            )
            .test('debug', 'Debug the file object', (value) => {
                // console.log('File Object:', value);
                return true; // Temporary, just for debugging
            }),
        back_img: Yup.mixed()
            .required('ID Back Document is required')
            .test(
                'fileType',
                'Only JPG, PNG, and JPEG formats are allowed',
                (value) => {
                    if (!value) return false; // Check if the value is present
                    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
                    return value && allowedTypes.includes(value.type);
                }
            )
            .test(
                'fileSize',
                'File size must be less than 10MB',
                (value) => {
                    const fileSizeLimit = 10097152; // 10MB
                    return value && value.size <= fileSizeLimit;
                }
            )
            .test('debug', 'Debug the file object', (value) => {
                // console.log('File Object:', value);
                return true; // Temporary, just for debugging
            }),
        profile_image: Yup.mixed()
            .required('Profile image is required')
            .test(
                'fileType',
                'Only JPG, PNG, and JPEG formats are allowed',
                (value) => {
                    if (!value) return false; // Check if the value is present
                    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
                    return value && allowedTypes.includes(value.type);
                }
            )
            .test(
                'fileSize',
                'File size must be less than 10MB',
                (value) => {
                    const fileSizeLimit = 10097152; // 10MB
                    return value && value.size <= fileSizeLimit;
                }
            )
            .test('debug', 'Debug the file object', (value) => {
                // console.log('File Object:', value);
                return true; // Temporary, just for debugging
            }),
        address: Yup.string()
            .required('Address is required')
            .max(100, 'Maximum 100 characters allowed'),
        price: Yup.number()
            .required('Limit Price is required')
            .typeError('Limit Price must be a number')
            .positive('Limit Price must be greater than zero'),
        shares: Yup.number()
            .required('Shares is required')
            .typeError('Shares must be a number')
            .positive('Shares must be greater than zero'),
        buy_price: Yup.number()
            .required('Buy Price is required')
            .typeError('Buy Price must be a number')
            .positive('Buy Price must be greater than zero'),
        buy_volume: Yup.number()
            .required('Buy amount is required')
            .typeError('Buy amount must be a number')
            .positive('Buy Amount must be greater than zero'),
        sell_price: Yup.number()
            .required('Sell price is required')
            .typeError('Sell price must be a number')
            .positive('Sell price must be greater than zero'),
        sell_volume: Yup.number()
            .required('Sell amount is required')
            .typeError('Sell amount must be a number')
            .positive('Sell amount must be greater than zero'),
        market_buy_amount: Yup.number()
            .required('Market buy amount is required')
            .typeError('Market buy amount must be a number')
            .positive('Market buy amount must be greater than zero'),
        market_sell_amount: Yup.number()
            .required('Market sell amount is required')
            .typeError('Market sell amount must be a number')
            .positive('Market sell amount must be greater than zero'),
        amount: Yup.number()
            .required('Withdraw amount is required')
            .typeError('Withdraw amount must be a number')
            .positive('Withdraw amount must be greater than zero'),
        to_address: Yup.string()
            .required('Withdraw address is required'),
        buy_trigger: Yup.number()
            .required('Trigger price is required')
            .typeError('Trigger price must be a number')
            .positive('Trigger price must be greater than zero'),
        sell_trigger: Yup.number()
            .required('Trigger price is required')
            .typeError('Trigger price must be a number')
            .positive('Trigger price must be greater than zero'),
        no_of_coin: Yup.number()
            .required('Subscription amount is required')
            .typeError('Subscription amount must be a number')
            .positive('Subscription amount must be greater than zero'),
        fromConvertprice: Yup.number()
            .required('Convert  amount is required')
            .typeError('Convert amount must be a number')
            .moreThan(0, 'Convert amount is must be greater than zero')
            // .max(50000000, 'Maximum allowed value is 50,000,000')
            .test(
                'max-decimals',
                'Only up to 8 decimal places allowed',
                value => {
                    if (value === undefined || value === null) return true;
                    return Number(value.toFixed(8)) === value;
                }
            ),

        toConvertprice: Yup.number()
            .required('Receive  amount is required')
            .typeError('Receive amount must be a number')
            .moreThan(0, 'Receive amount is must be greater than zero')
            // .max(50000000, 'Maximum allowed value is 50,000,000')
            .test(
                'max-decimals',
                'Only up to 8 decimal places allowed',
                value => {
                    if (value === undefined || value === null) return true;
                    return Number(value.toFixed(8)) === value;
                }
              ),


        nickname: Yup.string()
            .required("Nickname is required")
            .min(3, "Nickname must be minimum 3 characters.")
            .max(50, "Nickname cannot exceed 50 characters."),

        affiliate_type: Yup.string()
            .required("Affiliate type is required"),

        language: Yup.string()
            .required("Language is required"),

        contact_info: Yup.string()
            .required("Contact info is required")
            .min(5, "Contact info must be minimum 5 characters.")
            .max(100, "Contact info cannot exceed 100 characters."),

        region: Yup.string()
            .required("Region is required"),

        promo_platform: Yup.string()
            .required("The Primary Promo Platform field is required"),

        like_to_share: Yup.string()
            .required("This field is required")
            .min(5, "This field must be minimum 5 characters.")
            .max(300, "This field cannot exceed 300 characters."),

        hear_about: Yup.string()
            .required("This field is required"),

        socialMediaPlatforms: Yup.array()
            .required("Please select at least one platform.")
            .min(1, "Please select at least one platform."),

        action: Yup.string()
            .required("Action is required")
            .oneOf(["buy", "sell"], "Invalid action"),

        outcome: Yup.string()
            .required("Outcome is required")
            .oneOf(["yes", "no"], "Invalid outcome"),

        shares: Yup.number()
            .typeError("Shares must be a number")
            .required("Shares is required")
            .min(0.000001, "Minimum shares is 0.000001")
            .max(1000000, "Maximum shares is 1000000"),

        limit_price: Yup.number()
            .typeError("Limit price must be a number")
            .required("Limit price is required")
            .min(0.01, "Minimum price is 0.01")
            .max(0.99, "Maximum price is 0.99"),

    };

    const filteredFields = Object.keys(fields)
        .filter(key => Array.isArray(pickArray) && pickArray.includes(key))
        .reduce((obj, key) => {
            obj[key] = fields[key];
            return obj;
        }, {});

    return Yup.object().shape(filteredFields);
};

export default validationSchema;
