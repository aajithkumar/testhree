"use client"
import React, {  useEffect } from 'react';
import Homeheader from './components/Homeheader';
import Homefooter from './components/Homefooter';
import 'simplebar-react/dist/simplebar.min.css';
import MarketLayout from './hooks/MarketLayout';
import MarketLayoutCarousell from './hooks/MarketLayoutCarousell';



export default function Home() {


  return (
    <main className="contentpagesbg">
        <MarketLayoutCarousell categoryName={'Trending'} />
        <MarketLayout categoryName={'Trending'}/>
      </main>
  );
}