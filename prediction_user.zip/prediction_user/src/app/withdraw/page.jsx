"use client"
import React from 'react'
import { Container, Form, Button } from 'react-bootstrap';
import Withdraw from "../hooks/useWithdraw";

export default function WithdrawPage() {

    const { coinList,setSelectedNetwork,setSelectedCoin,selectedCoin,selectedNetwork,fetchWithdrawDetails,withdrawDetails,formatAmount,formik,isLoadingBut,setErrors,errors } = Withdraw();
    

    return (
        <div className='innerpages '>
            <div className='withdraw-page'>
                <Container >
                    <div className="gridparentbox">
                        <h2 className="inner-heading-title">Withdraw</h2>
                        <div className="withdraw-container">
                            <div className="form-wrapper siteformbg">
                                <form onSubmit={formik.handleSubmit}>
                                {/* Step 1 */}
                                <div className="step-item">
                                    <div className="step-circle active">1</div>
                                    <div className="step-content">
                                        <label>Coin/Token<span>*</span></label>
                                        <Form.Select 
                                            name="symbol"
                                            value={selectedCoin?.id || ""}
                                            onChange={(e) => {
                                                const selectedSymbol = e.target.value;
                                                const coin = coinList.find(
                                                    (item) => item?.id == selectedSymbol
                                                );
                                                // reset dependent fields
                                                setSelectedCoin(coin);
                                                setSelectedNetwork(coin?.network?.[0] || "");
                                                formik.setFieldValue("amount", "");
                                                formik.setFieldValue("to_address", "");
                                                setErrors({});

                                                if (coin) {
                                                    fetchWithdrawDetails(coin?.symbol);
                                                }

                                            }}
                                        >
                                            {/* <option>BTC</option> */}
                                            {coinList
                                                .filter((coin) => coin.symbol !== "USD")
                                                .map((coin) => (
                                                <option key={coin.id} value={coin.id}>
                                                    {coin.symbol}
                                                </option>
                                            ))}
                                        </Form.Select>
                                        {formik.touched.symbol && formik.errors.symbol && (
                                            <small className="text-danger">
                                                {formik.errors.symbol}
                                            </small>
                                        )}
                                        {errors?.symbol && errors?.symbol?.length > 0 && <small className="text-danger">{errors?.symbol}</small>}
                                    </div>
                                </div>

                                {/* Step 2 */}
                                <div className="step-item">
                                    <div className="step-circle active">2</div>
                                    <div className="step-content">
                                        <label>Network<span>*</span></label>
                                        <Form.Select
                                            name="network"
                                            value={selectedNetwork}
                                            onChange={(e) => {
                                                        setSelectedNetwork(e.target.value)

                                                        formik.setFieldValue("amount", "");
                                                        formik.setFieldValue("to_address", "");
                                                        setErrors({});
                                                    }}


                                        >
                                            {/* <option>BTC</option> */}
                                            {selectedCoin?.network?.map((net, index) => (
                                                <option key={index} value={net}>
                                                    {net.toLowerCase() == 'erc20' ? 'Ethereum-ERC20' : net}
                                                </option>
                                            ))}
                                        </Form.Select>
                                        {formik.touched.network && formik.errors.network && (
                                            <small className="text-danger">
                                                {formik.errors.network}
                                            </small>
                                        )}
                                        {errors?.network && errors?.network?.length > 0 && <small className="text-danger">{errors?.network}</small>}
                                    </div>
                                </div>

                                {/* Step 3 */}
                                <div className="step-item">
                                    <div className="step-circle active">3</div>
                                    <div className="step-content">
                                        <label>Withdraw Address<span>*</span></label>
                                        <Form.Control placeholder="Enter the withdraw address" name="to_address" value={formik.values.to_address}
                                        onChange={formik.handleChange}/>
                                        {formik.touched.to_address && formik.errors.to_address && (
                                        <small className="text-danger">
                                            {formik.errors.to_address}
                                        </small>
                                        )}
                                        {errors?.to_address && errors?.to_address?.length > 0 && <small className="text-danger">{errors?.to_address}</small>}
                                        {/* <div className="percentage-buttons">
                                            <button>25%</button>
                                            <button>50%</button>
                                            <button>75%</button>
                                            <button>100%</button>
                                        </div> */}
                                    </div>
                                    
                                </div>
                                

                                {/* Step 4 */}
                                <div className="step-item">
                                    <div className="step-circle">4</div>
                                    <div className="step-content">
                                        <label>Withdraw Amount<span>*</span></label>
                                        <Form.Control placeholder="Enter the withdraw amount" name="amount" value={formik.values.amount} onChange={formik.handleChange}/>
                                        {formik.touched.amount && formik.errors.amount && (
                                            <small className="text-danger">
                                                {formik.errors.amount}
                                            </small>
                                        )}
                                        {errors?.amount && errors?.amount?.length > 0 && <small className="text-danger">{errors?.amount}</small>}
                                        {errors?.error && errors?.error?.length > 0 && <small className="text-danger">{errors?.error}</small>}
                                    </div>
                                </div>

                                <Button type="submit" className="submit-btn" disabled={isLoadingBut}>{isLoadingBut ? ('Loading...') : ('Submit')}</Button>
                                </form>

                                {/* Bottom Card */}
                                <div className="info-card">
                                    <div>
                                        <p>Min Withdraw</p>
                                        <span>
                                            {formatAmount(withdrawDetails?.settings?.[0]?.minimum_withdraw)}{" "}
                                            {withdrawDetails?.symbol}
                                        </span>
                                    </div>
                                    <div>
                                        <p>Max Withdraw</p>
                                        <span>
                                           {formatAmount(withdrawDetails?.settings?.[0]?.maximum_withdraw)}{" "}
                                            {withdrawDetails?.symbol}
                                        </span>
                                    </div>
                                    <div>
                                        <p>Withdraw Fee</p>
                                        <span>
                                            {formatAmount(withdrawDetails?.settings?.[0]?.minimum_withdraw_fee)}{" "}
                                            {withdrawDetails?.symbol}
                                        </span>
                                    </div>
                                    <div>
                                        <p>Available Balance</p>
                                        <span>
                                            {formatAmount(withdrawDetails?.balance)}{" "}
                                            {withdrawDetails?.symbol}
                                        </span>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </Container>
            </div>
        </div>
    )
}
