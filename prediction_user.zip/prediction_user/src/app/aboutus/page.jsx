"use client"
import React from 'react';
import { Container } from 'react-bootstrap';

const Page = () => {
	return (
		<main className="contentotherpages">
			<section className="innerpagebg">
				<Container>
					<h2 className="heading-title text-center pb-0 mb-0">About Us</h2>
				</Container>
			</section>
			<section className="innerpagecontent sectionspace">
				<Container>
					<p className="content">PreditMark is an innovative prediction market platform designed to bring users together to forecast real-world events and market trends. Our goal is to create a simple, secure, and engaging environment where users can participate in predictions and explore new opportunities in the digital market space.</p>
					<p className="content">At PreditMark, we focus on providing a user-friendly platform with transparent systems and reliable technology. Our platform allows users to participate in various prediction markets while enjoying a smooth and secure experience. We continuously work to improve our services and deliver better features for our community.</p>
					<p className="content">Our mission is to build a trusted and modern prediction platform where users can interact, analyze trends, and make informed predictions. PreditMark is committed to innovation, security, and creating a fair ecosystem for everyone who joins our growing platform.</p>
				</Container>
			</section>
		</main>
	);
}
export default Page;