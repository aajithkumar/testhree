"use client"
import React, {useEffect,useState} from 'react';
import Homeheader from '../components/Homeheader'
import { Container, Tabs, Tab, Row, Col, Image, Button, InputGroup, FormControl, Table } from 'react-bootstrap'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBitcoinSign, faThLarge, faFootball, faMicrophone, faChartLine, faBarsProgress, faLaptop, faNewspaper, faSearch } from '@fortawesome/free-solid-svg-icons'
import Homefooter from '../components/Homefooter'
import { BookMarkIcon, CopyIcon, FilterIcon, HandPackageIcon, UploadIcon, BallIcon, BitCoinIcon, FinanceIcon, ListIcon, MediaIcon, MetalsIcon, MicIcon, TechIcon } from '../components/HomeIcons'
import ProfilePreviewChart from './ProfilePreviewChart';
import UserOrderActivity from '../hooks/useUserOrderActivity';
import Link from 'next/link';
import ProfileSetting from '../hooks/useProfileSettings';
import { formatDate } from '../helper';
import Deposit from '../hooks/useDeposit';
import PositionClosed  from '../hooks/PositionClosed';
import useUserPortfolio from '../hooks/useUserPortfolio';
import useHistory from "../hooks/useHistory";
import PaginationTabs from '../hooks/pagination';

export default function ProfilePreview() {

    const { getProfileDetails } = ProfileSetting();

    const{ userPortfolio } =  useUserPortfolio();

    const [activeTab, setActiveTab] = useState("depositHistory");

    const {
        depositHistory,
        withdrawHistory,
        isLoading,
        fetchDepositHistory,
        fetchWithdrawHistory,
        depositPage,
        withdrawPage,
        depositTotalPages,
        withdrawTotalPages
    } = useHistory();

    useEffect(() => {
        if (activeTab === "depositHistory") {
            fetchDepositHistory(1);
        }

        if (activeTab === "withdrawHistory") {
            fetchWithdrawHistory(1);
        }
    }, [activeTab]);

    // Deposit Modal
    const [showDepositModal, setShowDepositModal] = useState(false);
    const [Depositview, setDepositview] = useState(false);
    const handleCloseDepositModal = () => setShowDepositModal(false);
    const handleShowDepositModal = () => {
        setDepositview(true);
        setShowDepositModal(true);
    };

    // Transfer Modal
    const [showTransferModal, setShowTransferModal] = useState(false);
    const handleCloseTransferModal = () => setShowTransferModal(false);
    const handleShowTransferModal = () => setShowTransferModal(true);

    const [positionstatus, setPositionstatus] = useState(0);
    const [activePage, setActivePage] = useState(1);
    const [search, setSearch] = useState("");
    const [searchInput, setSearchInput] = useState("");

    const handleTabChange = (key) => {
        if (key === "activetb") {
            setPositionstatus(0);
        } else if (key === "closedtb") {
            setPositionstatus(1);
        }
        setSearchInput("");
        setSearch("");
        setActivePage(1);
    };

    return (
        <div className='profile-preview-page'>
            <Container>
                <div className='profile-preview-container mt-4'>
                    <Row className='mt-4 row-gap-3'>
                    <Col lg={6} md={6} sm={12}>
                        <div className="panelcontentbox h-100">
                            <div className='pro-preview-panel1'>
                                <div className='panel-heading-align'>
                                    <div>
                                        <div>
                                            {/* <Image src={getProfileDetails?.profile_image ??"/assets/images/world-icon.png"}></Image> */}
                                            <Image src={"/assets/images/world-icon.png"}></Image>

                                        </div>
                                        <div className='d-flex flex-column gap-1'>
                                            <h6 className='subhead mb-0'>{getProfileDetails?.name ?? 'User'}</h6>
                                            <span>Joined {formatDate(getProfileDetails?.created_at)}</span>
                                        </div>
                                    </div>
                                    {/* <div className='d-flex align-items-center gap-2'>
                                        <CopyIcon size={20} color='#74717A' />
                                        <HandPackageIcon size={22} color='#74717A' />
                                        <BookMarkIcon size={24} color='#74717A' />
                                    </div> */}
                                </div>
                                <div className='pro-preview-content-cont'>
                                    <div className='pro-preview-content'>
                                        <div>
                                            <h6 className='subhead'>${parseFloat(userPortfolio?.open_positions_value_sum || 0).toFixed(2)}</h6>
                                            <span>Positions Value</span>
                                        </div>
                                        <div>
                                            <h6 className='subhead'>${parseFloat(userPortfolio?.biggest_win || 0).toFixed(2)}</h6>
                                            <span>Biggest Win</span>
                                        </div>
                                        <div>
                                            <h6 className='subhead'>{userPortfolio?.total}</h6>
                                            <span>Predictions</span>
                                        </div>
                                    </div>
                                    <div className='d-flex align-items-center gap-2'>
                                        <Button className='sitebtn w-100' onClick={handleShowDepositModal}>Deposit</Button>
                                        <Link href="/withdraw" className='sitebtn w-100'>Withdraw</Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col lg={6} md={6} sm={12}>
                        <div className='panelcontentbox'>
                            <ProfilePreviewChart />
                        </div>
                    </Col>
                    </Row>
                    <div className='panelcontentbox preview-panel-tabs my-4'>
                        <Tabs defaultActiveKey={"potns"}>
                            <Tab title={
                                <span>Positions</span>
                            } eventKey={"potns"}>
                                <div className='mt-3'>
                                    <Row className='align-items-center row-gap-3'>
                                        <Col lg={2}>
                                            <Tabs defaultActiveKey={"activetb"} className='preview-sts-tab' onSelect={handleTabChange}>
                                                <Tab title={
                                                    <span>Active</span>
                                                } eventKey={"activetb"}>
                                                </Tab>
                                                <Tab title={
                                                    <span>Closed</span>
                                                } eventKey={"closedtb"}>
                                                </Tab>
                                            </Tabs>
                                        </Col>
                                        <Col lg={9}>
                                            <InputGroup className="siteformbg filter-srch">
                                                <InputGroup.Text id="basic-search" ><FontAwesomeIcon icon={faSearch} color='#74717A' /></InputGroup.Text>
                                                <FormControl
                                                    aria-describedby="basic-search" placeholder='Search Predictions'
                                                    value={searchInput}
                                                    onChange={(e)=> setSearchInput(e.target.value)}
                                                />                                
                                            </InputGroup>
                                        </Col>
                                        <Col lg={1}>
                                            <Button className='filter-btn' 
                                                onClick={()=>{
                                                    setSearch(searchInput);
                                                    setActivePage(1);
                                                }}> Search
                                            </Button>
                                        </Col>
                                        
                                    </Row>

                                    <div className="preview-panel-tb mt-4">
                                        <div className='table-responsive'>
                                        {/* <Table>
                                            <thead>
                                                <tr>
                                                    <th>MARKET</th>
                                                    <th>AVG</th>
                                                    <th>Current</th>
                                                    <th>Value</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <div className="market-cell">
                                                            <Image src="/assets/images/table-icons1.png" alt="icon" className="market-icon" />
                                                            <div>
                                                                <div className="market-title">
                                                                    What is the "Will Russia enter Mykhailivka by April 30?" prediction market?
                                                                </div>

                                                                <div className="market-meta">
                                                                    <span className="yes-badge">Yes 63.7¢</span>
                                                                    <span className="shares">586,905.6 shares</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td className="text-end avg-col">63.7¢</td>
                                                    <td className="text-end current-col">0¢</td>

                                                    <td className="text-end value-col">
                                                        <span>$0.00</span>
                                                        <div className="negative-value">-$379,996.82 (100%)</div>
                                                    </td>

                                                    <td className="text-end">
                                                        <span className="download-icon"><UploadIcon size={15} color='#A4A1AA' /></span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div className="market-cell">
                                                            <Image src="/assets/images/table-icons2.png" alt="icon" className="market-icon" />
                                                            <div>
                                                                <div className="market-title">
                                                                    Will Club Atlético de Madrid win on 2026-02-08?
                                                                </div>

                                                                <div className="market-meta">
                                                                    <span className="yes-badge">Yes 68¢</span>
                                                                    <span className="shares">727,353.3 shares</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>

                                                    <td className="text-end avg-col">68¢</td>
                                                    <td className="text-end current-col">0¢</td>

                                                    <td className="text-end value-col">
                                                        <span>$0.00</span>
                                                        <div className="negative-value">-$494,600.21 (-100%)</div>
                                                    </td>

                                                    <td className="text-end">
                                                        <span className="download-icon">
                                                            <UploadIcon size={15} color='#A4A1AA' />
                                                        </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </Table> */}
                                            <PositionClosed status={positionstatus} activePage={activePage} setActivePage={setActivePage} search={search}/>
                                        </div>
                                    </div>

                                </div>
                            </Tab>
                            <Tab title={
                                <span>Activity</span>
                            } eventKey={"actviy"}>
                                <UserOrderActivity/>
                            </Tab>
                            
                            <Tab title={<span>History</span>} eventKey={"history"}>
                                <div className="preview-panel-tb preview-history-tab mt-3">

                                        {/* 🔥 ADD THIS FILTER ROW */}
                                    <Row className='align-items-center row-gap-3 mb-3'>
                                        <Col lg={2}>
                                            <Tabs
                                                defaultActiveKey={"depositHistory"}
                                                className='preview-sts-tab'
                                                onSelect={(key) => setActiveTab(key)}
                                            >
                                                <Tab title={<span>Deposit</span>} eventKey="depositHistory" />
                                                <Tab title={<span>Withdraw</span>} eventKey="withdrawHistory" />
                                            </Tabs>
                                        </Col>
                                    </Row>

                                    {/* Sub Tabs */}
                                    {/* <Tabs defaultActiveKey="depositHistory" className="preview-sts-tab"> */}
                                    <Tabs activeKey={activeTab} className="preview-sts-tab" onSelect={(key) => setActiveTab(key)}>
                                        
                                        {/* deposit History */}
                                        <Tab eventKey="depositHistory">
                                            <div className="table-responsive mt-3">
                                                <Table>
                                                    <thead>
                                                        <tr>
                                                            <th>Date & Time</th>
                                                            <th>Coin / Token</th>
                                                            <th>Txn Id</th>
                                                            <th>Sender</th>
                                                            <th>Receiver</th>
                                                            <th>Network</th>
                                                            <th>Amount</th>
                                                            <th>Fee</th>
                                                            <th>Total</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    {                                                        
                                                        isLoading ? (
                                                            <tr>
                                                                <td colSpan={10} className="text-center">
                                                                    <img src="/assets/images/loader.svg" alt="Loading..."  />
                                                                </td>
                                                            </tr>
                                                        ) : depositHistory.length > 0 ? (
                                                            <>
                                                                {depositHistory.map((item, index) => (
                                                                    <tr key={index}>
                                                                        <td>{item.created_at}</td>
                                                                        <td>
                                                                            <Image
                                                                            src={item.image_url}
                                                                            width={50}
                                                                            height={50}
                                                                            alt="coin"
                                                                            className="tb-coinicon"
                                                                            />
                                                                            {item.coin}
                                                                        </td>
                                                                        <td>{item.txn_id}</td>
                                                                        <td>{item.sender || "-"}</td>
                                                                        <td>{item.receiver || "-"}</td>
                                                                        <td>{item.network || "-"}</td>
                                                                        <td>{item.amount || "-"}</td>
                                                                        <td>{item.fee || "-"}</td>
                                                                        <td>{item.amount || "-"}</td>

                                                                        <td>
                                                                            <span
                                                                                className={
                                                                                item.status === 1
                                                                                    ? "text-success"
                                                                                    : item.status === 0
                                                                                    ? "text-warning"
                                                                                    : "text-danger"
                                                                                }
                                                                            >
                                                                                {item.status === 1
                                                                                ? "Success"
                                                                                : item.status === 0
                                                                                ? "Pending"
                                                                                : "Rejected"}
                                                                            </span>
                                                                        </td>
                                                                    </tr>
                                                                ))}
                                                            </>
                                                        ) : (
                                                            <tr>
                                                                <td colSpan={10} className="text-center">
                                                                    No Records Found
                                                                </td>
                                                            </tr>
                                                        )
                                                    }
                                                    </tbody>
                                                </Table>
                                                {!isLoading && depositTotalPages > 1 && (
                                                    <PaginationTabs
                                                        totalPages={depositTotalPages}
                                                        activePage={depositPage}
                                                        handlePageClick={(page) => fetchDepositHistory(page)}
                                                    />
                                                )}
                                            </div>
                                        </Tab>

                                        {/* withdraw History */}
                                        <Tab eventKey="withdrawHistory">
                                            <div className="table-responsive mt-3">
                                                <Table>
                                                    <thead>
                                                        <tr>
                                                            <th>Date & Time</th>
                                                            <th>Coin / Token</th>
                                                            <th>Txn Id</th>
                                                            <th>Sender</th>
                                                            <th>Receiver</th>
                                                            <th>Network</th>
                                                            <th>Amount</th>
                                                            <th>Fee</th>
                                                            <th>Total</th>
                                                            <th>Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    {
                                                        isLoading ? (
                                                            <tr>
                                                                <td colSpan={10} className="text-center">
                                                                    <img src="/assets/images/loader.svg" alt="Loading..."  />
                                                                </td>
                                                            </tr>
                                                        ) : withdrawHistory.length > 0 ? (
                                                        withdrawHistory.map((item, index) => (
                                                        <tr key={index}>
                                                            <td>{item.created_at}</td>
                                                            <td>
                                                                <Image
                                                                src={item.image_url}
                                                                width={50}
                                                                height={50}
                                                                alt="coin"
                                                                className="tb-coinicon"
                                                                />
                                                                {item.coin}
                                                            </td>
                                                            <td>{item.txn_id}</td>

                                                            <td>{item.sender || "-"}</td>
                                                            <td>{item.receiver || "-"}</td>
                                                            <td>{item.network || "-"}</td>

                                                            <td>{item.amount || "-"}</td>
                                                            <td>{item.fee || "-"}</td>
                                                            <td>{item.amount || "-"}</td>

                                                            <td>
                                                                <span
                                                                className={
                                                                item.status === 1
                                                                    ? "text-success"
                                                                    : item.status === 0
                                                                    ? "text-warning"
                                                                    : "text-danger"
                                                                }>
                                                                {item.status === 1 ? "Approved"
                                                                : item.status === 0
                                                                ? "Pending"
                                                                : "Rejected"}
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        ))
                                                    ) : (
                                                        <tr>
                                                        <td colSpan={10} className="text-center">
                                                            No Records Found
                                                        </td>
                                                        </tr>
                                                    )}
                                                    </tbody>
                                                </Table>
                                                {!isLoading && withdrawTotalPages > 1 && (
                                                    <PaginationTabs
                                                        totalPages={withdrawTotalPages}
                                                        activePage={withdrawPage}
                                                        handlePageClick={(page) => fetchWithdrawHistory(page)}
                                                    />
                                                )}
                                            </div>
                                        </Tab>
                                    </Tabs>
                                </div>
                            </Tab>
                        </Tabs>
                    </div>
                </div>
            </Container>

            {/* Deposit Modal */}
            { Depositview && (
                <Deposit
                    showDepositModal={showDepositModal}
                    handleCloseDepositModal={handleCloseDepositModal}
                    setShowDepositModal={setShowDepositModal}
                    setShowTransferModal={setShowTransferModal}
                    showTransferModal={showTransferModal}
                    handleCloseTransferModal={handleCloseTransferModal}
                />
            )}
        </div>
    )
}