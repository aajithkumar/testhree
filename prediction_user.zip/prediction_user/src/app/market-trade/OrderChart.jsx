import React, { useState } from 'react'
import { Image } from 'react-bootstrap'
import { BookMarkIcon, LinkIcon } from '../components/HomeIcons';
import CryptoChart from './CryptoChart';

const OrderChart = ({ isLoading, market, intervel, setIntervel, yesData, noData }) => {

    return (
        <>
            <div className='panelcontentbox'>
                <div className='panel-heading-align'>
                    <div>
                        {isLoading ? <Image src="/assets/images/precard-img7.png" alt={process.env.NEXT_PUBLIC_BACKEND_URL_IMAGE_URL + (market?.image || "/assets/images/precard-img7.png")} /> : <Image src={process.env.NEXT_PUBLIC_BACKEND_URL_IMAGE_URL + (market?.image || "/assets/images/precard-img7.png")} alt={process.env.NEXT_PUBLIC_BACKEND_URL_IMAGE_URL + (market?.image || "/assets/images/precard-img7.png")} />}

                        <div className='d-flex flex-column gap-1'>
                            <span>{market.category_name}</span>
                            <h6 className='subhead mb-0'>{market.question}</h6>
                        </div>
                    </div>
                    {/* <div className='d-flex align-items-center gap-2'>
                        <LinkIcon size={24} color='#74717A' />
                        <BookMarkIcon size={24} color='#74717A' />
                    </div> */}
                </div>

                <div className='mt-5'>
                    <CryptoChart intervel={intervel} setIntervel={setIntervel} dataYesPoints={yesData} dataNoPoints={noData} market={market} />
                </div>
            </div>
        </>
    )
}

export default OrderChart;