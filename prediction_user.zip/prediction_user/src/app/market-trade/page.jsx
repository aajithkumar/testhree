"use client"
import React, { useState } from 'react'
// import { BitCoinIcon } from '../components/HomeIcons'
import { Container, Tabs, Tab, TabContainer, TabPane, TabContent, NavLink, NavItem, Nav, Image, Row, Col, Accordion, AccordionItem, AccordionBody, AccordionHeader, Form, FormLabel, FormGroup, FormControl, FormSelect, FormCheck, InputGroup, Button } from 'react-bootstrap'
import Link from 'next/link';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faSearch, faThLarge,
    faBitcoinSign,
    faFootball,
    faMicrophone,
    faChartLine,
    faBarsProgress,
    faLaptop,
    faNewspaper, faCaretDown, faPlus, faMinus
} from '@fortawesome/free-solid-svg-icons';
import { BookMarkIcon, InfoIcon, LinkIcon, MoneyIcon, ShieldIcon } from '../components/HomeIcons';
import CryptoChart from './CryptoChart';
import Homeheader from '../components/Homeheader';

export default function MarketTrade() {

    const [limitTab, setLimitTab] = useState('limit');

    const [count, setCount] = useState(0);

    const handleCount = (e, type) => {
        e.stopPropagation();
        if (type === 'increment') {
            setCount(prev => prev + 1);
        } else if (type === 'decrement' && count > 0) {
            setCount(prev => Math.max(0, prev - 1));
        }
    }

    const handleCountInput = (e) => {
        const val = e.target.value;
        if (val === '' || /^\d+$/.test(val)) {
            setCount(val === '' ? '' : Number(val));
        }
    }

    return (
        <div>
            <section>
                <Container className='market-trade'>
                    <Tabs
                        defaultActiveKey="all"
                        className="category-tabs justify-content-center gap-3 border-0"
                    >
                        <Tab
                            eventKey="all"
                            title={
                                <div className="tab-box">
                                    <FontAwesomeIcon icon={faThLarge} />
                                    <span>All</span>
                                </div>
                            }
                        >

                            <Row>
                                <Col lg={8}>
                                    <div className='panel-flex'>
                                        <div className='panelcontentbox'>
                                            <div className='panel-heading-align'>
                                                <div>
                                                    <Image src="/assets/images/world-icon.png"></Image>
                                                    <div className='d-flex flex-column gap-1'>
                                                        <span>Politics - Ukraine</span>
                                                        <h6 className='subhead mb-0'>Will Russia enter Mykhailivka by April 30?</h6>
                                                    </div>
                                                </div>
                                                <div className='d-flex align-items-center gap-2'>
                                                    <LinkIcon size={24} color='#74717A' />
                                                    <BookMarkIcon size={24} color='#74717A' />
                                                </div>
                                            </div>

                                            <div className='mt-5'>
                                                <CryptoChart />
                                            </div>
                                        </div>


                                        {/* Order Book */}
                                        <Accordion className='order-book-accordion' defaultActiveKey="0">
                                            <AccordionItem eventKey="0">
                                                <AccordionHeader>Order Book</AccordionHeader>
                                                <AccordionBody>
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                                                    minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                                                    aliquip ex ea commodo consequat. Duis aute irure dolor in
                                                    reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                                                    pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                                                    culpa qui officia deserunt mollit anim id est laborum.
                                                </AccordionBody>
                                            </AccordionItem>
                                        </Accordion>

                                        {/* Rules and Market Context */}

                                        <div className='rules-market-wrp panelcontentbox mt-0'>
                                            <Tabs
                                                defaultActiveKey="rules"
                                                className="rules-market-tabs"
                                            >
                                                <Tab
                                                    eventKey="rules"
                                                    title={
                                                        <span>Rules</span>
                                                    }
                                                >
                                                    <p className='mt-4'>This market will resolve to “Yes” if, according to the ISW map, Russia captures any territory of Mykhailivka, Sumy Oblast, (50.797758° N, 35.315210° E) between market creation and the specified date (ET).... Show more</p>

                                                    <hr className='mt-4' />

                                                    <div className='rules-market-tabs-wrp'>
                                                        <Tabs
                                                            defaultActiveKey="comments"
                                                            className="rules-market-tabs"
                                                        >
                                                            <Tab
                                                                eventKey="comments"
                                                                title={
                                                                    <span>Comments</span>
                                                                }
                                                            >

                                                                <div className='siteformbg'>
                                                                    <Form className='mt-4'>
                                                                        <FormControl placeholder='Add a comment' />
                                                                        <Button className='sitebtn mt-2'>Post</Button>
                                                                    </Form>
                                                                </div>

                                                                <hr />

                                                                <div className='rules-filters'>
                                                                    <Form className='filter-form'>
                                                                        <FormSelect>
                                                                            <option>Newest</option>
                                                                            <option>Oldest</option>
                                                                            <option>Most Liked</option>
                                                                            <option>Most Commented</option>
                                                                        </FormSelect>

                                                                        <FormGroup className='d-flex gap-2'>
                                                                            <FormCheck type='checkbox' id='holders' />
                                                                            <FormLabel htmlFor='holders' className='mb-0'>Holders</FormLabel>
                                                                        </FormGroup>
                                                                    </Form>

                                                                    <div>
                                                                        <ShieldIcon size={18} color='#A4A1AA' />
                                                                        <span>Beware of external links.</span>
                                                                    </div>
                                                                </div>

                                                                <div className='no-cmts'>
                                                                    <p>No comments</p>
                                                                </div>

                                                                <hr className='mt-0' />

                                                                <div className='rules-faq-section'>
                                                                    <h6 className='subhead'>Frequently Asked Questions</h6>

                                                                    <Accordion defaultActiveKey="0" className='mt-4'>
                                                                        <AccordionItem eventKey="0">
                                                                            <AccordionHeader>What is the "Will Russia enter Mykhailivka by April 30?" prediction market?</AccordionHeader>
                                                                            <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                                                        </AccordionItem>
                                                                        <AccordionItem eventKey="1">
                                                                            <AccordionHeader>How much trading activity has "Will Russia enter Mykhailivka by April 30?" generated on Polymarket?</AccordionHeader>
                                                                            <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                                                        </AccordionItem>
                                                                        <AccordionItem eventKey="2">
                                                                            <AccordionHeader>How do I trade on "Will Russia enter Mykhailivka by April 30?"?</AccordionHeader>
                                                                            <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                                                        </AccordionItem>
                                                                        <AccordionItem eventKey="3">
                                                                            <AccordionHeader>What are the current odds for "Will Russia enter Mykhailivka by April 30?"?</AccordionHeader>
                                                                            <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                                                        </AccordionItem>
                                                                        <AccordionItem eventKey="4">
                                                                            <AccordionHeader>How will "Will Russia enter Mykhailivka by April 30?" be resolved?</AccordionHeader>
                                                                            <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                                                        </AccordionItem>
                                                                    </Accordion>

                                                                    <div className='d-flex justify-content-center mt-4'>
                                                                        <Button className='faq-btn'>View More</Button>
                                                                    </div>

                                                                </div>

                                                            </Tab>
                                                            <Tab
                                                                eventKey="topholders"
                                                                title={
                                                                    <span>Top Holders</span>
                                                                }
                                                            >


                                                                <div>

                                                                </div>
                                                            </Tab>
                                                            <Tab
                                                                eventKey="positions"
                                                                title={
                                                                    <span>Positions</span>
                                                                }
                                                            >


                                                                <div>

                                                                </div>
                                                            </Tab>
                                                            <Tab
                                                                eventKey="activity"
                                                                title={
                                                                    <span>Activity</span>
                                                                }
                                                            >


                                                                <div>

                                                                </div>
                                                            </Tab>
                                                        </Tabs>
                                                    </div>
                                                </Tab>
                                                <Tab
                                                    eventKey="market-context"
                                                    title={
                                                        <span>Market Context</span>
                                                    }
                                                >
                                                    <p className='mt-4'>This market will resolve to “Yes” if, according to the ISW map, Russia captures any territory of Mykhailivka, Sumy Oblast, (50.797758° N, 35.315210° E) between market creation and the specified date (ET).... Show more</p>

                                                    <hr className='mt-4' />
                                                </Tab>
                                            </Tabs>
                                        </div>
                                    </div>

                                </Col>

                                <Col lg={4}>
                                    <div className='buysell-panel panelcontentbox'>
                                        <div className='buysell-panel-tabs-wrp buysell-panel-tabs'>
                                            <TabContainer
                                                defaultActiveKey="buy"
                                            >
                                                <div className='buy-sell-opt'>
                                                    <Nav variant="tabs" className="mb-1">
                                                        <NavItem>
                                                            <NavLink eventKey="buy">Buy</NavLink>
                                                        </NavItem>
                                                        <NavItem>
                                                            <NavLink eventKey="sell">Sell</NavLink>
                                                        </NavItem>
                                                        <FormSelect
                                                            className='ms-auto'
                                                            value={limitTab}
                                                            onChange={(e) => setLimitTab(e.target.value)}
                                                        >
                                                            <option value="limit">Limit</option>
                                                            <option value="market">Market</option>
                                                        </FormSelect>
                                                    </Nav>

                                                </div>
                                                <TabContent>
                                                    <TabPane eventKey="buy">
                                                        <div className='d-flex gap-2 mt-3'>
                                                            <Button className='yes-btn'>Yes 14.3¢</Button>
                                                            <Button className='no-btn'>No 87¢</Button>
                                                        </div>

                                                        <FormGroup className='counter-wrp'>
                                                            <FormLabel>Limit Price</FormLabel>
                                                            <InputGroup>
                                                                <InputGroup.Text className='count-handler' onClick={(e) => handleCount(e, 'decrement')}>
                                                                    <FontAwesomeIcon icon={faMinus} />
                                                                </InputGroup.Text>
                                                                <FormControl type="text" placeholder="0" value={count} onChange={handleCountInput} />
                                                                <InputGroup.Text className='count-handler' onClick={(e) => handleCount(e, 'increment')}>
                                                                    <FontAwesomeIcon icon={faPlus} />
                                                                </InputGroup.Text>
                                                            </InputGroup>
                                                        </FormGroup>

                                                        <hr />

                                                        {limitTab === 'limit' && (
                                                            <div className='mt-2 limit-wrp-tab'>
                                                                <FormGroup className='shares-wrap'>
                                                                    <FormLabel>Shares</FormLabel>
                                                                    <FormControl placeholder='0' />
                                                                </FormGroup>
                                                                <div className='add-on-wrp'>
                                                                    <Button className='btn-sm'>-100</Button>
                                                                    <Button className='btn-sm'>-50</Button>
                                                                    <Button className='btn-sm'>+10</Button>
                                                                    <Button className='btn-sm'>+100</Button>
                                                                    <Button className='btn-sm'>+20</Button>
                                                                </div>
                                                                <div className='exp-toggle-wrp'>
                                                                    <span>Set Expiration</span>
                                                                    <label className="toggle-switch">
                                                                        <input type="checkbox" id="toggle" />
                                                                        <span className="slider"></span>
                                                                    </label>
                                                                </div>
                                                                <div className='#359A5E total-wrp'>
                                                                    <span>Total</span>
                                                                    <span>$0</span>
                                                                </div>
                                                                <div className='win-wrp'>
                                                                    <span>To Win <InfoIcon size='16' color='#74717A' /></span>
                                                                    <span><MoneyIcon size='20' color='#359A5E' />$0</span>
                                                                </div>
                                                                <Button className='sitebtn'>Trade</Button>
                                                                <p className='mt-2'>By trading, you agree to the <Link href="#0" className='alink'>Terms of Use.</Link></p>
                                                            </div>
                                                        )}

                                                        {limitTab === 'market' && (
                                                            <div className='market-wrp-tab'>
                                                                <FormGroup className='mamount-wrp'>
                                                                    <FormLabel>Amount</FormLabel>
                                                                    <FormControl placeholder='0' type='number' />
                                                                </FormGroup>
                                                                <div className='add-on-wrp'>
                                                                    <Button className='btn-sm'>+100</Button>
                                                                    <Button className='btn-sm'>+5</Button>
                                                                    <Button className='btn-sm'>+10</Button>
                                                                    <Button className='btn-sm'>+100</Button>
                                                                    <Button className='btn-sm'>Max</Button>
                                                                </div>
                                                                <Button className='sitebtn'>Trade</Button>
                                                                <p className='mt-2'>By trading, you agree to the <Link href="#0" className='alink'>Terms of Use.</Link></p>
                                                            </div>
                                                        )}
                                                    </TabPane>
                                                    <TabPane eventKey="sell">
                                                        <div className='d-flex gap-2 mt-3'>
                                                            <Button className='yes-btn'>Yes 14.3¢</Button>
                                                            <Button className='no-btn'>No 87¢</Button>
                                                        </div>

                                                        <FormGroup className='counter-wrp'>
                                                            <FormLabel>Limit Price</FormLabel>
                                                            <InputGroup>
                                                                <InputGroup.Text className='count-handler' onClick={(e) => handleCount(e, 'decrement')}>
                                                                    <FontAwesomeIcon icon={faMinus} />
                                                                </InputGroup.Text>
                                                                <FormControl type="text" placeholder="0" value={count} onChange={handleCountInput} />
                                                                <InputGroup.Text className='count-handler' onClick={(e) => handleCount(e, 'increment')}>
                                                                    <FontAwesomeIcon icon={faPlus} />
                                                                </InputGroup.Text>
                                                            </InputGroup>
                                                        </FormGroup>

                                                        <hr />

                                                        {limitTab === 'limit' && (
                                                            <div className='mt-2 limit-wrp-tab'>
                                                                <FormGroup className='shares-wrap'>
                                                                    <FormLabel>Shares</FormLabel>
                                                                    <FormControl placeholder='0' />
                                                                </FormGroup>
                                                                <div className='add-on-wrp'>
                                                                    <Button className='btn-sm'>-100</Button>
                                                                    <Button className='btn-sm'>-50</Button>
                                                                    <Button className='btn-sm'>+10</Button>
                                                                    <Button className='btn-sm'>+100</Button>
                                                                    <Button className='btn-sm'>+20</Button>
                                                                </div>
                                                                <div className='exp-toggle-wrp'>
                                                                    <span>Set Expiration</span>
                                                                    <label className="toggle-switch">
                                                                        <input type="checkbox" id="toggle" />
                                                                        <span className="slider"></span>
                                                                    </label>
                                                                </div>
                                                                <div className='win-wrp'>
                                                                    <span>You'll receive <InfoIcon size='16' color='#74717A' /></span>
                                                                    <span><MoneyIcon size='20' color='#359A5E' />$0</span>
                                                                </div>
                                                                <Button className='sitebtn'>Trade</Button>
                                                                <p className='mt-2'>By trading, you agree to the <Link href="#0" className='alink'>Terms of Use.</Link></p>
                                                            </div>
                                                        )}

                                                        {limitTab === 'market' && (
                                                            <div className='market-wrp-tab'>
                                                                <FormGroup className='mamount-wrp'>
                                                                    <FormLabel>Shares</FormLabel>
                                                                    <FormControl placeholder='0' type='number' />
                                                                </FormGroup>
                                                                <div className='add-on-wrp'>
                                                                    <Button className='btn-sm'>25%</Button>
                                                                    <Button className='btn-sm'>50%</Button>
                                                                    <Button className='btn-sm'>Max</Button>
                                                                </div>
                                                                <Button className='sitebtn'>Trade</Button>
                                                                <p className='mt-2'>By trading, you agree to the <Link href="#0" className='alink'>Terms of Use.</Link></p>
                                                            </div>
                                                        )}
                                                    </TabPane>
                                                </TabContent>
                                            </TabContainer>

                                        </div>
                                    </div>
                                </Col>

                            </Row>


                        </Tab>

                        <Tab
                            eventKey="crypto"
                            title={
                                <div className="tab-box">
                                    <FontAwesomeIcon icon={faBitcoinSign} />
                                    <span>Crypto</span>
                                </div>
                            }
                        ></Tab>

                        <Tab
                            eventKey="sports"
                            title={
                                <div className="tab-box">
                                    <FontAwesomeIcon icon={faFootball} />
                                    <span>Sports</span>
                                </div>
                            }
                        ></Tab>

                        <Tab
                            eventKey="politics"
                            title={
                                <div className="tab-box">
                                    <FontAwesomeIcon icon={faMicrophone} />
                                    <span>Politics</span>
                                </div>
                            }
                        ></Tab>

                        <Tab
                            eventKey="finance"
                            title={
                                <div className="tab-box">
                                    <FontAwesomeIcon icon={faChartLine} />
                                    <span>Finance</span>
                                </div>
                            }
                        ></Tab>

                        <Tab
                            eventKey="metals"
                            title={
                                <div className="tab-box">
                                    <FontAwesomeIcon icon={faBarsProgress} />
                                    <span>Metals</span>
                                </div>
                            }
                        ></Tab>


                        <Tab
                            eventKey="tech"
                            title={
                                <div className="tab-box">
                                    <FontAwesomeIcon icon={faLaptop} />
                                    <span>Tech</span>
                                </div>
                            }
                        ></Tab>

                        <Tab
                            eventKey="media"
                            title={
                                <div className="tab-box">
                                    <FontAwesomeIcon icon={faNewspaper} />
                                    <span>Media</span>
                                </div>
                            }
                        ></Tab>
                    </Tabs>
                </Container>
            </section>

        </div>
    )
}