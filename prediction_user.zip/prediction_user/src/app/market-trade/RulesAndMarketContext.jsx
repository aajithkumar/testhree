import React, { useState } from 'react'
import { Tabs, Tab, Table, Button } from 'react-bootstrap';

const RulesAndMarketContext = ({ market, openOrders, isLoading, handleCancelOrder, accessToken, handleShow1}) => {

    const [showMoreContext, setShowMoreContext] = useState(false);

    return (
        <>
            {/* Rules and Market Context */}
            <div className='rules-market-wrp panelcontentbox mt-0'>
                <Tabs
                    defaultActiveKey="rules"
                    className="rules-market-tabs"
                >
                    <Tab
                        eventKey="rules"
                        title={
                            <span>Rules</span>
                        }
                    >

                        {/* <p className='mt-4'>{market.rules}</p> */}
                        <p className='mt-4 mb-0'>
                            {!market?.rules
                                ? "Loading rules..."
                                : showMoreContext
                                    ? market.rules
                                    : market.rules.substring(0, 150) + (market.rules.length > 150 ? "..." : "")
                            }
                        </p>



                        {market.rules?.length > 150 && (
                            <span
                                className='show-more-btn'
                                onClick={() => setShowMoreContext(!showMoreContext)}
                            >
                                {showMoreContext ? "Show less" : "Show more"}
                            </span>
                        )}

                        {/* <hr className='mt-4' />

                        <div className='rules-market-tabs-wrp'>
                            <Tabs
                                defaultActiveKey="comments"
                                className="rules-market-tabs"
                            >
                                <Tab
                                    eventKey="comments"
                                    title={
                                        <span>Comments</span>
                                    }
                                >

                                    <div className='siteformbg'>
                                        <Form className='mt-4'>
                                            <FormControl placeholder='Add a comment' />
                                            <Button className='sitebtn mt-2'>Post</Button>
                                        </Form>
                                    </div>

                                    <hr />

                                    <div className='rules-filters'>
                                        <Form className='filter-form'>
                                            <FormSelect>
                                                <option>Newest</option>
                                                <option>Oldest</option>
                                                <option>Most Liked</option>
                                                <option>Most Commented</option>
                                            </FormSelect>

                                            <FormGroup className='d-flex gap-2'>
                                                <FormCheck type='checkbox' id='holders' />
                                                <FormLabel htmlFor='holders' className='mb-0'>Holders</FormLabel>
                                            </FormGroup>
                                        </Form>

                                        <div>
                                            <ShieldIcon size={18} color='#A4A1AA' />
                                            <span>Beware of external links.</span>
                                        </div>
                                    </div>

                                    <div className='no-cmts'>
                                        <p>No comments</p>
                                    </div>

                                    <hr className='mt-0' />

                                    <div className='rules-faq-section'>
                                        <h6 className='subhead'>Frequently Asked Questions</h6>

                                        <Accordion defaultActiveKey="0" className='mt-4'>
                                            <AccordionItem eventKey="0">
                                                <AccordionHeader>What is the "Will Russia enter Mykhailivka by April 30?" prediction market?</AccordionHeader>
                                                <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                            </AccordionItem>
                                            <AccordionItem eventKey="1">
                                                <AccordionHeader>How much trading activity has "Will Russia enter Mykhailivka by April 30?" generated on Polymarket?</AccordionHeader>
                                                <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                            </AccordionItem>
                                            <AccordionItem eventKey="2">
                                                <AccordionHeader>How do I trade on "Will Russia enter Mykhailivka by April 30?"?</AccordionHeader>
                                                <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                            </AccordionItem>
                                            <AccordionItem eventKey="3">
                                                <AccordionHeader>What are the current odds for "Will Russia enter Mykhailivka by April 30?"?</AccordionHeader>
                                                <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                            </AccordionItem>
                                            <AccordionItem eventKey="4">
                                                <AccordionHeader>How will "Will Russia enter Mykhailivka by April 30?" be resolved?</AccordionHeader>
                                                <AccordionBody>Polymarket is a prediction market platform where users can create and trade on market predictions. The "Will Russia enter Mykhailivka by April 30?" prediction market is a market that allows users to bet on whether or not Russia will enter Mykhailivka by April 30.</AccordionBody>
                                            </AccordionItem>
                                        </Accordion>

                                        <div className='d-flex justify-content-center mt-4'>
                                            <Button className='faq-btn'>View More</Button>
                                        </div>

                                    </div>

                                </Tab>
                                <Tab
                                    eventKey="topholders"
                                    title={
                                        <span>Top Holders</span>
                                    }
                                >


                                    <div>

                                    </div>
                                </Tab>
                                <Tab
                                    eventKey="positions"
                                    title={
                                        <span>Positions</span>
                                    }
                                >


                                    <div>

                                    </div>
                                </Tab>
                                <Tab
                                    eventKey="activity"
                                    title={
                                        <span>Activity</span>
                                    }
                                >


                                    <div>

                                    </div>
                                </Tab>
                            </Tabs>
                        </div> */}
                    </Tab>
                    <Tab
                        eventKey="orders"
                        title={
                            <span>Open Orders</span>
                        }
                    >
                        <div className="table-responsive mt-3">
                            <Table className='sitetable'>
                                <thead>
                                    <tr>
                                        <th>Date & Time</th>
                                        <th>Type</th>
                                        <th>Shares</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {accessToken ? (
                                        openOrders?.length > 0 ? (
                                            <>
                                                {openOrders
                                                    ?.sort((a, b) => new Date(b.id) - new Date(a.id))
                                                    .map((item, index) => (
                                                        <tr key={index}>
                                                            <td>{(new Date(item.created_at || item.d)).toLocaleString()}</td>
                                                            <td style={{ textTransform: 'capitalize' }}>
                                                                {item.outcome || item.t}
                                                            </td>
                                                            <td>{item.remaining_shares || item.s}</td>
                                                            <td>{((item.limit_price || item.p) * 100).toFixed(0) || "-"}</td>
                                                            <td>
                                                                {((item.remaining_shares || item.s) * (item.limit_price || item.p)).toFixed(2) || "-"}
                                                            </td>
                                                            <td>
                                                                <Button
                                                                    className="no-btn"
                                                                    onClick={() => handleCancelOrder(item.id)}
                                                                >
                                                                    Cancel
                                                                </Button>
                                                            </td>
                                                        </tr>
                                                    ))}
                                            </>
                                        ) : (
                                            <tr>
                                                <td colSpan={7} className="text-center">
                                                    No Records Found
                                                </td>
                                            </tr>
                                        )
                                    ) : (
                                        <tr>
                                            <td colSpan={7} className="text-center">
                                                <Button className="sitebtn" onClick={handleShow1}>
                                                    Login to Trade
                                                </Button>
                                            </td>
                                        </tr>

                                    )}
                                </tbody>
                            </Table>
                        </div>
                    </Tab>
                    {/* <Tab
                        eventKey="market-context"
                        title={
                            <span>Market Context</span>
                        }
                    >
                        <p className='mt-4'>This market will resolve to “Yes” if, according to the ISW map, Russia captures any territory of Mykhailivka, Sumy Oblast, (50.797758° N, 35.315210° E) between market creation and the specified date (ET).... Show more</p>

                        <hr className='mt-4' />
                    </Tab> */}
                </Tabs>
            </div>
        </>
    )
}

export default RulesAndMarketContext;