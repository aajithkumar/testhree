
import React, { useState } from 'react'
import { TabContainer, TabPane, TabContent, NavLink, NavItem, Nav, Col, FormLabel, FormGroup, FormControl, FormSelect, InputGroup, Button, Form, Dropdown, OverlayTrigger, 
    Tooltip
 } from 'react-bootstrap'
import Link from 'next/link';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus, faMinus, faCheckCircle, faCirclePause } from '@fortawesome/free-solid-svg-icons';
import { InfoIcon, MoneyIcon } from '../components/HomeIcons';

const OrderForm = ({ market, marketStats, accessToken, loading, predict, userPositions, side, limitTab, count, formik, errors, isLoading, router, handleSide, handlePredict, handleLimitTab, handleCount, handleCountInput, handleSharesInput, handleMarketSharesInput, handleSharesChange, handleMarketSellSharesChange, handleShow1 }) => {

    return (
        <>
            <div className='buysell-panel panelcontentbox'>
                {market?.status === 'resolved' || market?.status === 'paused' ? (
                    <div className='stickybox panelcontentbox'>
                        {market?.status === 'resolved' ? (
                            <div className='outcome-div'>
                                <FontAwesomeIcon icon={faCheckCircle} fontSize={60} color='#6300FF' />
                                <h6 className='subhead'>Outcome: {market?.winning_outcome}</h6>
                                <p>Real Betis Balompié</p>
                                <p>By trading, you agree to the <Link href="/terms-of-condition" className='alink'>Terms of Use.</Link></p>
                            </div>
                        ) : (
                            <div className='outcome-div'>
                                <FontAwesomeIcon icon={faCirclePause} fontSize={60} color='#6300FF' />
                                <h6 className='subhead'>Prediction Trade Paused</h6>
                                <p>Real Betis Balompié</p>
                                <p>By trading, you agree to the <Link href="#" className='alink'>Terms of Use.</Link></p>
                            </div>
                        )}
                    </div>
                ) : (
                    <div className='buysell-panel-tabs-wrp buysell-panel-tabs'>
                        <Form onSubmit={formik.handleSubmit}>
                            <TabContainer
                                defaultActiveKey="buy"
                            >
                                <div className='buy-sell-opt'>
                                    <Nav variant="tabs" className="mb-1">
                                        <NavItem>
                                            <NavLink eventKey="buy" onClick={handleSide('buy')}>Buy</NavLink>
                                        </NavItem>
                                        <NavItem>
                                            <NavLink eventKey="sell" onClick={handleSide('sell')}>Sell</NavLink>
                                        </NavItem>
                                        {/* <FormSelect
                                            className='ms-auto'
                                            value={limitTab}
                                            onChange={(e) => handleLimitTab(e.target.value)}
                                        >
                                            <option value="limit">Limit</option>
                                            <option value="market">Market</option>
                                        </FormSelect> */}
                                        <Dropdown align="end" className='ms-auto' onChange={(e) => handleLimitTab(e.target.value)}>
                                            <Dropdown.Toggle className="custom-select-btn">
                                                {limitTab}
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu className="custom-dropdown">
                                                <Dropdown.Item onClick={() => handleLimitTab("Market")}>
                                                    Market
                                                </Dropdown.Item>

                                                <Dropdown.Item onClick={() => handleLimitTab("Limit")}>
                                                    Limit
                                                </Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </Nav>

                                </div>
                                <TabContent>
                                    <TabPane eventKey="buy">
                                        <div className='d-flex gap-2 mt-3'>
                                            <Button className={`yes-btn ${predict === 'yes' ? 'active' : ''}`} onClick={handlePredict('yes')}>Yes {Number(marketStats?.yes_best_ask_cents) || 50}¢</Button>
                                            <Button className={`no-btn ${predict === 'no' ? 'active' : ''}`} onClick={handlePredict('no')}>No {Number(marketStats?.no_best_ask_cents) || 50}¢</Button>
                                        </div>

                                        {limitTab === 'Limit' && (
                                            <div className='mt-2 limit-wrp-tab'>
                                                <FormGroup className='counter-wrp'>
                                                    <FormLabel>Limit Price</FormLabel>
                                                    <InputGroup>
                                                        <InputGroup.Text className='count-handler' onClick={(e) => handleCount(e, 'decrement')}>
                                                            <FontAwesomeIcon icon={faMinus} />
                                                        </InputGroup.Text>
                                                        <FormControl type="text" placeholder="0" value={formik.values?.price || ""} onChange={handleCountInput} />
                                                        <InputGroup.Text className='count-handler' onClick={(e) => handleCount(e, 'increment')}>
                                                            <FontAwesomeIcon icon={faPlus} />
                                                        </InputGroup.Text>
                                                    </InputGroup>
                                                </FormGroup>
                                                {formik.touched.price && formik.errors.price && (
                                                    <small className="text-danger">{formik.errors.price}</small>
                                                )}
                                                {errors?.limit_price && errors?.limit_price?.length > 0 && <small className="text-danger">{errors?.limit_price}</small>}

                                                <hr />
                                                <FormGroup className='shares-wrap'>
                                                    <FormLabel>Shares</FormLabel>
                                                    <FormControl type="number" placeholder="0" value={formik.values?.shares || ""} onChange={handleSharesInput} />
                                                </FormGroup>
                                                {formik.touched.shares && formik.errors.shares && (
                                                    <small className="text-danger">{formik.errors.shares}</small>
                                                )}
                                                {errors?.shares && errors?.shares?.length > 0 && <small className="text-danger">{errors?.shares}</small>}
                                                <div className='add-on-wrp'>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(-100)}>-100</Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(-50)}>-50</Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(10)}>+10</Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(100)}>+100</Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(20)}>+20</Button>
                                                </div>
                                                {/* <div className='exp-toggle-wrp'>
                                                    <span>Set Expiration</span>
                                                    <label className="toggle-switch">
                                                        <input type="checkbox" id="toggle" />
                                                        <span className="slider"></span>
                                                    </label>
                                                </div> */}
                                                <div className='#359A5E total-wrp'>
                                                    <span>Total</span>
                                                    <span>${formik.values?.total || 0}</span>
                                                </div>
                                                <div className='win-wrp'>
                                                    <span>To Win <OverlayTrigger
                                                        placement="top"
                                                        overlay={<Tooltip id="to-win-tooltip">
                                                            <div className='tooltip-wrp'>
                                                                <span>Fee</span>
                                                                <span>$ {(market.trading_fee_percent * (formik.values?.win || 0)) / 100}</span>
                                                            </div>
                                                        </Tooltip>}
                                                    >
                                                        <span>
                                                            <InfoIcon size="16" color="#74717A" />
                                                        </span>
                                                    </OverlayTrigger></span>
                                                    <span><MoneyIcon size='20' color='#359A5E' />${formik.values?.win || 0}</span>
                                                </div>
                                                {accessToken ? (
                                                    <Button type="submit" className="sitebtn" disabled={isLoading}>
                                                        {isLoading ? 'Loading...' : 'Trade'}
                                                    </Button>
                                                ) : (
                                                    <Button className="sitebtn" onClick={handleShow1}>
                                                        Login to Trade
                                                    </Button>
                                                )}
                                                <p className='mt-2'>By trading, you agree to the <Link href="/terms-of-condition" className='alink'>Terms of Use.</Link></p>
                                            </div>
                                        )}

                                        {limitTab === 'Market' && (
                                            <div className='market-wrp-tab'>
                                                <FormGroup className='mamount-wrp'>
                                                    <FormLabel>Amount</FormLabel>
                                                    <FormControl type="number" placeholder="0" value={formik.values?.shares || ""} onChange={handleMarketSharesInput} />
                                                </FormGroup>
                                                {formik.touched.shares && formik.errors.shares && (
                                                    <small className="text-danger">{formik.errors.shares}</small>
                                                )}
                                                {errors?.shares && errors?.shares?.length > 0 && <small className="text-danger">{errors?.shares}</small>}
                                                <div className='add-on-wrp'>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(100)}>
                                                        +100
                                                    </Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(5)}>
                                                        +5
                                                    </Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(10)}>
                                                        +10
                                                    </Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(100)}>
                                                        +100
                                                    </Button>
                                                    {/* <Button className='btn-sm' onClick={() => handleSharesChange(formik.values?.shares || 0)}>
                                                        Max
                                                    </Button> */}
                                                </div>
                                                {accessToken ? (
                                                    <Button type="submit" className="sitebtn" disabled={isLoading}>
                                                        {isLoading ? 'Loading...' : 'Trade'}
                                                    </Button>
                                                ) : (
                                                    <Button className="sitebtn" onClick={handleShow1}>
                                                        Login to Trade
                                                    </Button>
                                                )}
                                                <p className='mt-2'>By trading, you agree to the <Link href="/terms-of-condition" className='alink'>Terms of Use.</Link></p>
                                            </div>
                                        )}
                                    </TabPane>
                                    <TabPane eventKey="sell">
                                        <div className='d-flex gap-2 mt-3'>
                                            <Button className={`yes-btn ${predict === 'yes' ? 'active' : ''}`} onClick={handlePredict('yes')}>Yes {Number(marketStats?.yes_best_bid_cents) || 50}¢</Button>
                                            <Button className={`no-btn ${predict === 'no' ? 'active' : ''}`} onClick={handlePredict('no')}>No {Number(marketStats?.no_best_bid_cents) || 50}¢</Button>
                                        </div>

                                        {limitTab === 'Limit' && (
                                            <div className='mt-2 limit-wrp-tab'>
                                                <FormGroup className='counter-wrp'>
                                                    <FormLabel>Limit Price</FormLabel>
                                                    <InputGroup>
                                                        <InputGroup.Text className='count-handler' onClick={(e) => handleCount(e, 'decrement')}>
                                                            <FontAwesomeIcon icon={faMinus} />
                                                        </InputGroup.Text>
                                                        <FormControl type="text" placeholder="0" value={formik.values?.price || ""} onChange={handleCountInput} />
                                                        <InputGroup.Text className='count-handler' onClick={(e) => handleCount(e, 'increment')}>
                                                            <FontAwesomeIcon icon={faPlus} />
                                                        </InputGroup.Text>
                                                    </InputGroup>
                                                </FormGroup>
                                                {formik.touched.price && formik.errors.price && (
                                                    <small className="text-danger">{formik.errors.price}</small>
                                                )}
                                                {errors?.limit_price && errors?.limit_price?.length > 0 && <small className="text-danger">{errors?.limit_price}</small>}

                                                <hr />

                                                <FormGroup className='shares-wrap'>
                                                    <FormLabel>Shares</FormLabel>
                                                    <FormControl type="number" placeholder="0" value={formik.values?.shares || ""} onChange={handleSharesInput} />
                                                </FormGroup>
                                                {formik.touched.shares && formik.errors.shares && (
                                                    <small className="text-danger">{formik.errors.shares}</small>
                                                )}
                                                {errors?.shares && errors?.shares?.length > 0 && <small className="text-danger">{errors?.shares}</small>}
                                                <div className='add-on-wrp'>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(-100)}>
                                                        -100
                                                    </Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(-50)}>
                                                        -50
                                                    </Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(10)}>
                                                        +10
                                                    </Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(100)}>
                                                        +100
                                                    </Button>
                                                    <Button className='btn-sm' onClick={() => handleSharesChange(20)}>
                                                        +20
                                                    </Button>
                                                </div>
                                                {/* <div className='exp-toggle-wrp'>
                                                    <span>Set Expiration</span>
                                                    <label className="toggle-switch">
                                                        <input type="checkbox" id="toggle" />
                                                        <span className="slider"></span>
                                                    </label>
                                                </div> */}
                                                <div className='win-wrp'>
                                                    <span>You'll receive <OverlayTrigger
                                                        placement="top"
                                                        overlay={<Tooltip id="to-win-tooltip">
                                                            <div className='tooltip-wrp'>
                                                                <span>Fee</span>
                                                                <span>$ {(market.trading_fee_percent * (formik.values?.win || 0)) / 100}</span>
                                                            </div>
                                                        </Tooltip>}
                                                    >
                                                        <span>
                                                            <InfoIcon size="16" color="#74717A" />
                                                        </span>
                                                    </OverlayTrigger></span>
                                                    <span><MoneyIcon size='20' color='#359A5E' />${formik.values?.win || "0.00"}</span>
                                                </div>
                                                {accessToken ? (
                                                    <Button type="submit" className="sitebtn" disabled={isLoading}>
                                                        {isLoading ? 'Loading...' : 'Trade'}
                                                    </Button>
                                                ) : (
                                                    <Button className="sitebtn" onClick={handleShow1}>
                                                        Login to Trade
                                                    </Button>
                                                )}
                                                <p className='mt-2'>By trading, you agree to the <Link href="/terms-of-condition" className='alink'>Terms of Use.</Link></p>
                                            </div>
                                        )}

                                        {limitTab === 'Market' && (
                                            <div className='market-wrp-tab'>
                                                <FormGroup className='mamount-wrp'>
                                                    <FormLabel>Shares</FormLabel>
                                                    <FormControl type="number" placeholder="0" value={formik.values?.shares || ""} onChange={handleMarketSharesInput} />
                                                </FormGroup>
                                                {formik.touched.shares && formik.errors.shares && (
                                                    <small className="text-danger">{formik.errors.shares}</small>
                                                )}
                                                {errors?.shares && errors?.shares?.length > 0 && <small className="text-danger">{errors?.shares}</small>}
                                                <div className='add-on-wrp'>
                                                    <Button className='btn-sm' onClick={() => handleMarketSellSharesChange(25)}>
                                                        25%
                                                    </Button>
                                                    <Button className='btn-sm' onClick={() => handleMarketSellSharesChange(50)}>
                                                        50%
                                                    </Button>
                                                    {/* <Button className='btn-sm' onClick={() => handleSharesChange(formik.values?.shares || 0) * 1}>
                                                        Max
                                                    </Button> */}
                                                </div>
                                                {accessToken ? (
                                                    <Button type="submit" className="sitebtn" disabled={isLoading}>
                                                        {isLoading ? 'Loading...' : 'Trade'}
                                                    </Button>
                                                ) : (
                                                    <Button className="sitebtn" onClick={handleShow1}>
                                                        Login to Trade
                                                    </Button>
                                                )}
                                                <p className='mt-2'>By trading, you agree to the <Link href="/terms-of-condition" className='alink'>Terms of Use.</Link></p>
                                            </div>
                                        )}
                                    </TabPane>
                                </TabContent>
                            </TabContainer>
                        </Form>
                    </div>
                )}
            </div>


        </>
    )
}

export default OrderForm;