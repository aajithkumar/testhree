"use client"

import React, { useState, useEffect } from 'react'
import { Container, Row, Col } from 'react-bootstrap'
import usePredictionTrade from '../../hooks/usePredictionTrade'
import Signin from "../../hooks/useSignin";
import OrderChart from '../OrderChart'
import OrderBook from '../OrderBook'
import RulesAndMarketContext from '../RulesAndMarketContext';
import OrderForm from '../OrderForm'


export default function MarketTrade() {

    const {market,
        marketStats,
        loading,
        side,
        predict,
        limitTab,
        count,
        formik,
        errors,
        isLoading,
        router,
        accessToken,
        handleSide,
        handlePredict,
        handleLimitTab,
        handleCount,
        handleCountInput,
        handleSharesInput,
        handleMarketSharesInput,
        handleSharesChange,
        handleMarketSellSharesChange,
        userPositions,
        intervel,
        setIntervel,
        yesData,
        noData,
        openOrders,
        handleCancelOrder,
        handleShow1,
        show1,
        handleClose1
        } = usePredictionTrade()

    return (
        <div>
            {/* <Homeheader /> */}
            <section>
                <Container className='market-trade'>
                    <Row>
                        <Col lg={8}>
                            <div className='panel-flex'>
                                {/* Order Header and Chart */}
                                <OrderChart isLoading={isLoading} market={market} intervel={intervel} setIntervel={setIntervel} yesData={yesData} noData={noData}/>

                                {/* Order Book */}
                                <OrderBook 
                                    marketStats={marketStats} 
                                    predict={predict} 
                                />

                                {/* Rules and Market Context */}
                                <RulesAndMarketContext market={market} openOrders={openOrders} isLoading={isLoading} handleCancelOrder={handleCancelOrder} accessToken={accessToken} handleShow1={handleShow1} />
                            </div>

                        </Col>

                        <Col lg={4}>
                            <OrderForm 
                                market={market}
                                marketStats={marketStats} 
                                accessToken={accessToken} 
                                loading={loading}
                                predict={predict}
                                userPositions={userPositions}
                                side={side}
                                limitTab={limitTab}
                                count={count}
                                formik={formik}
                                errors={errors}
                                isLoading={isLoading}
                                router={router}
                                handleSide={handleSide}
                                handlePredict={handlePredict}
                                handleLimitTab={handleLimitTab}
                                handleCount={handleCount}
                                handleCountInput={handleCountInput}
                                handleSharesInput={handleSharesInput}
                                handleMarketSharesInput={handleMarketSharesInput}
                                handleSharesChange={handleSharesChange}
                                handleMarketSellSharesChange={handleMarketSellSharesChange}
                                handleShow1={handleShow1}
                            />                           
                        </Col>

                    </Row>


                </Container>
                {/* Sign In Modal */}
                <Signin showSignin={show1} handleClose1={handleClose1} accessPage={`/market-trade/${market?.slug}`} />
            </section>

        </div>
    )
}