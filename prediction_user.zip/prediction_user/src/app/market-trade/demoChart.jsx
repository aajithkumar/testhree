export const generateChartData = () => {
  const raw = [
    { t: 1773057600, p: 0.50 },
    { t: 1773057698, p: 0.48 },
    { t: 1773057732, p: 0.46 },
    { t: 1773057773, p: 0.50 },
    { t: 1773059807, p: 0.54 },
    { t: 1773060171, p: 0.58 },
    { t: 1773060263, p: 0.52 },
    { t: 1773225307, p: 0.50 },
    { t: 1773227003, p: 0.52 },
    { t: 1773227137, p: 0.50 },
    { t: 1773228606, p: 0.52 },
    { t: 1773229941, p: 0.58 },
    { t: 1773382256, p: 0.60 },
    { t: 1773384304, p: 0.64 },
    { t: 1773386567, p: 0.74 },
    { t: 1773394078, p: 0.76 },
    { t: 1773397300, p: 0.80 },
    { t: 1773399838, p: 0.86 },
    { t: 1773400848, p: 0.77 },
    { t: 1773401048, p: 0.65 },
    { t: 1773405048, p: 0.50 },
  ];

  const result = [];

  for (let i = 0; i < raw.length - 1; i++) {
    const start = raw[i];
    const end = raw[i + 1];

    const steps = 10; // more steps = smoother chart
    const dt = (end.t - start.t) / steps;
    const dp = (end.p - start.p) / steps;

    for (let j = 0; j < steps; j++) {
      const noise = (Math.random() - 0.5) * 0.01; // tiny wiggle

      result.push({
        t: Math.floor(start.t + dt * j),
        p: +(start.p + dp * j + noise).toFixed(4),
      });
    }
  }

  // push final point
  result.push(raw[raw.length - 1]);

  return result;
};