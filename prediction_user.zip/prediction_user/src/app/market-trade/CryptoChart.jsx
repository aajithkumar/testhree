"use client";

import React, { useState, useMemo, useRef } from "react";
import {
    Chart as ChartJS,
    LineElement,
    PointElement,
    LinearScale,
    CategoryScale,
    TimeScale,
    Tooltip,
    Filler,
} from "chart.js";
import "chartjs-adapter-date-fns";
import { Line } from "react-chartjs-2";
import { UnionIcon, ScheduleIcon, ShuffleIcon, SettingsIcon } from "../components/HomeIcons";

ChartJS.register(
    LineElement,
    PointElement,
    LinearScale,
    CategoryScale,
    TimeScale,
    Tooltip,
    Filler
);

// ✅ Gradient Plugin
const gradientPlugin = {
    id: "gradientFill",
    beforeDatasetsDraw(chart) {
        const { ctx, chartArea } = chart;
        if (!chartArea) return;

        const dataset = chart.data.datasets[0];

        const gradient = ctx.createLinearGradient(
            0,
            chartArea.top,
            0,
            chartArea.bottom
        );

        const color = dataset.borderColor === "#EF4444"
            ? "239,68,68"
            : "16,185,129";

        gradient.addColorStop(0, `rgba(${color},0.35)`);
        gradient.addColorStop(1, `rgba(${color},0.02)`);

        dataset.backgroundColor = gradient;
    }
};

// ✅ Glow Plugin
const glowPlugin = {
    id: "glowEffect",
    beforeDatasetDraw(chart, args) {
        const { ctx } = chart;
        ctx.save();
        ctx.shadowColor = args.meta.dataset.options.borderColor;
        ctx.shadowBlur = 1;
    },
    afterDatasetDraw(chart) {
        chart.ctx.restore();
    }
};

// ✅ Fill ONLY small gaps
const fillMissingData = (data, intervalMinutes = 1, maxGapMinutes = 10) => {
    if (!data.length) return [];

    const result = [];

    let lastValue = data[0].y;
    let lastTime = data[0].x;

    result.push({ x: lastTime, y: lastValue });

    for (let i = 1; i < data.length; i++) {
        const currentTime = data[i].x;

        const gap = (currentTime - lastTime) / 60000;

        // ✅ fill only small gaps
        if (gap <= maxGapMinutes) {
            while (lastTime + intervalMinutes * 60000 < currentTime) {
                lastTime += intervalMinutes * 60000;

                result.push({
                    x: lastTime,
                    y: lastValue
                });
            }
        }

        // ❗ large gap → don't fill
        result.push({
            x: currentTime,
            y: data[i].y
        });

        lastValue = data[i].y;
        lastTime = currentTime;
    }

    return result;
};

// ✅ Extend ONLY if recent
const extendToNow = (data, maxExtendMinutes = 10) => {
    if (!data.length) return data;

    const last = data[data.length - 1];
    const now = Date.now();

    const gap = (now - last.x) / 60000;

    if (gap <= maxExtendMinutes) {
        return [
            ...data,
            { x: now, y: last.y }
        ];
    }

    return data;
};

export default function CryptoChart({
    market,
    intervel,
    setIntervel,
    dataYesPoints,
    dataNoPoints
}) {

    const [showNo, setShowNo] = useState(false);
    const chartRef = useRef(null);

    // ✅ Format + sort
    const formatData = (data) =>
        data
            ?.map(item => ({
                x: item.t,
                y: Number(item.p * 100)
            }))
            .sort((a, b) => a.x - b.x) || [];

    const activeData = showNo
        ? formatData(dataNoPoints)
        : formatData(dataYesPoints);

    // ✅ Apply smart gap logic
    const processedData = useMemo(() => {
        const filled = fillMissingData(activeData, 1, 10);
        return extendToNow(filled, 10);
    }, [activeData]);

    // ✅ Y axis from processed data
    const yValues = processedData.map(d => d.y);

    const minY = yValues.length
        ? Math.max(0, Math.min(...yValues))
        : 0;

    const maxY = yValues.length
        ? Math.min(100, Math.max(...yValues))
        : 100;

    // ✅ Chart Data
    const chartData = useMemo(() => ({
        datasets: [
            {
                label: showNo ? "No" : "Yes",
                data: processedData,

                borderColor: showNo ? "#EF4444" : "#10B981",
                borderWidth: 2.5,
                tension: 0,
                fill: true,

                pointRadius: (ctx) =>
                    ctx.dataIndex === ctx.dataset.data.length - 1 ? 5 : 0,

                pointHoverRadius: 6,
                pointBackgroundColor: showNo ? "#EF4444" : "#10B981",
                pointBorderWidth: 0
            }
        ]
    }), [processedData, showNo]);

    // ✅ Options
    const options = {
        responsive: true,
        maintainAspectRatio: false,

        plugins: {
            legend: { display: false },
            tooltip: {
                backgroundColor: "#111",
                borderColor: "#222",
                borderWidth: 1,
                titleColor: "#fff",
                bodyColor: "#aaa",
                displayColors: false,
                callbacks: {
                    label: (ctx) => `${ctx.parsed.y.toFixed(2)}%`
                }
            }
        },

        interaction: {
            intersect: false,
            mode: "index"
        },

        scales: {
            x: {
                type: "time",
                time: {
                    unit: intervel === '1H' ? 'minute' : (intervel === 'ALL' ? 'month' : 'day')
                },
                grid: { display: false },
                ticks: {
                    color: "#555",
                    maxTicksLimit: 6
                }
            },

            y: {
                position: "right",
                suggestedMin: minY - 2,
                suggestedMax: maxY + 2,

                grid: {
                    color: "rgba(255,255,255,0.03)",
                    drawBorder: false
                },
                ticks: {
                    color: "#666",
                    callback: (v) => v + "%"
                }
            }
        },

        animation: {
            duration: 300
        }
    };

    return (
        <>
            <div
                style={{
                    background: "#19181B",
                    borderRadius: "12px",
                    width: "100%",
                    height: "270px",
                    padding: "10px"
                }}
            >
                <Line
                    ref={chartRef}
                    data={chartData}
                    options={options}
                    plugins={[gradientPlugin, glowPlugin]}
                />
            </div>

            <div className="crypto-chart-btm">
                <div>
                    <span><UnionIcon color="#BBA6FF" size="14" /> NEW</span>
                    <span>${market?.tot_traded_val} Vol.</span>
                    <span>
                        <ScheduleIcon color="#74717A" size="14" />{" "}
                        {market?.start_time}
                    </span>
                </div>

                <div>
                    {["1H", "6H", "1D", "1W", "1M", "ALL"].map((item) => (
                        <span
                            key={item}
                            style={{
                                cursor: "pointer",
                                color: item === intervel ? "#fff" : "#666",
                                marginRight: "8px"
                            }}
                            onClick={() => setIntervel(item)}
                        >
                            {item}
                        </span>
                    ))}

                    <ShuffleIcon
                        color="#74717A"
                        size="14"
                        onClick={() => setShowNo(prev => !prev)}
                    />
                    <SettingsIcon color="#74717A" size="14" />
                </div>
            </div>
        </>
    );
}