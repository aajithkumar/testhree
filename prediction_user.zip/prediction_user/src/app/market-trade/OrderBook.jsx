import React, { useState } from 'react'
import { Accordion, AccordionItem, AccordionBody, AccordionHeader, Table } from 'react-bootstrap'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCircleInfo } from '@fortawesome/free-solid-svg-icons'


const OrderBook = ({marketStats, predict}) => {

    const handleMultiply = (value) => {
        value = Number(value);
        if (isNaN(value)) return '';
        return (value * 100).toFixed(0);
    }

    const handleYesWidth = (total) => {
        const yesOrders = predict === 'yes' ? marketStats?.yob : marketStats?.nob;
        const askYesOrders = yesOrders?.asks || [];
        const bidYesOrders = yesOrders?.bids || [];
        const allYesTotals = [
            ...askYesOrders.map(o => Number(o.p) * Number(o.sh)),
            ...bidYesOrders.map(o => Number(o.p) * Number(o.sh))
        ];
        const maxYesTotal = Math.max(...allYesTotals, 1);
        if (maxYesTotal === 0) return '0%';
        const width = (total / maxYesTotal) * 100;
        return `${width}%`;
    }

    const handleNoWidth = (total) => {
        const noOrders = predict === 'yes' ? marketStats?.nob : marketStats?.yob;
        const askNoOrders = noOrders?.asks || [];
        const bidNoOrders = noOrders?.bids || [];
        const allNoTotals = [
            ...askNoOrders.map(o => Number(o.p) * Number(o.sh)),
            ...bidNoOrders.map(o => Number(o.p) * Number(o.sh))
        ];
        const maxNoTotal = Math.max(...allNoTotals, 1);
        if (maxNoTotal === 0) return '0%';
        const width = (total / maxNoTotal) * 100;
        return `${width}%`;
    }

    return (
        <>
            {/* Order Book */}
            <Accordion className='order-book-accordion' defaultActiveKey="0">
                <AccordionItem eventKey="0">
                    <AccordionHeader>Order Book <FontAwesomeIcon icon={faCircleInfo} className='ms-1' color='#74717A' /></AccordionHeader>
                    {predict === 'yes' ? (
                        <AccordionBody>
                            <div className='table-responsive'>
                                <Table className='order-book-table m-0 position-relative'>
                                    <thead>
                                        <tr>
                                            <th>Trades Yes</th>
                                            <th>Price</th>
                                            <th>Shares</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {marketStats?.yob?.asks
                                            ?.filter(orderbook => Number(orderbook.sh) > 0)
                                            ?.sort((a, b) => Number(b.p) - Number(a.p)) 
                                            .slice(0, 15)
                                            .map((orderbook, index) => (
                                                <tr key={index}>
                                                    <td>
                                                        <span
                                                            className="ordervolumebg bg-red"
                                                            style={{ width: handleYesWidth(Number(orderbook.p) * Number(orderbook.sh)) }}
                                                        ></span>
                                                    </td>

                                                    <td className="t-red">
                                                        {handleMultiply(orderbook.p)}¢
                                                    </td>

                                                    <td>
                                                        {Number(orderbook.sh)}
                                                    </td>

                                                    <td>
                                                        ${(Number(orderbook.p) * Number(orderbook.sh)).toFixed(2)}
                                                    </td>
                                                </tr>
                                            ))}
                                    </tbody>
                                    <thead>
                                        <tr>
                                            <th>Last: {Number(marketStats?.ylstpc) || 50}¢</th>
                                            <th>Spread: 1¢</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {marketStats?.yob?.bids
                                            ?.filter(orderbook => Number(orderbook.sh) > 0)
                                            ?.sort((a, b) => Number(b.p) - Number(a.p)) 
                                            .slice(0, 15)
                                            .map((orderbook, index) => (
                                                <tr key={index}>
                                                    <td>
                                                        <span className='ordervolumebg bg-green' 
                                                        style={{ width: handleYesWidth(Number(orderbook.p) * Number(orderbook.sh)) }}></span>
                                                    </td>
                                                    <td className='t-green'>{handleMultiply(orderbook.p)}¢</td>
                                                    <td>{Number(orderbook.sh)}</td>
                                                    <td>${(Number(orderbook.p) * Number(orderbook.sh)).toFixed(2)}</td>
                                                </tr>
                                            )
                                            )}
                                    </tbody>
                                </Table>
                            </div>
                        </AccordionBody>
                    ) : (
                        <AccordionBody>
                            <div className='table-responsive'>
                                <Table className='order-book-table m-0 position-relative'>
                                    <thead>
                                        <tr>
                                            <th>Trades Yes</th>
                                            <th>Price</th>
                                            <th>Shares</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {marketStats?.nob?.asks
                                            ?.filter(orderbook => Number(orderbook.sh) > 0)
                                            .slice(0, 15)
                                            .sort((a, b) => Number(b.p) - Number(a.p))
                                            .map((orderbook, index) => (
                                                <tr key={index}>
                                                    <td>
                                                        <span
                                                            className="ordervolumebg bg-red"
                                                            style={{ width: handleNoWidth(Number(orderbook.p) * Number(orderbook.sh)) }}
                                                        ></span>
                                                    </td>

                                                    <td className="t-red">
                                                        {handleMultiply(orderbook.p)}¢
                                                    </td>

                                                    <td>
                                                        {Number(orderbook.sh)}
                                                    </td>

                                                    <td>
                                                        ${(Number(orderbook.p) * Number(orderbook.sh)).toFixed(2)}
                                                    </td>
                                                </tr>
                                            ))}
                                    </tbody>
                                    <thead>
                                        <tr>
                                            <th>Last: {Number(marketStats?.nlstpc) || 50}¢</th>
                                            <th>Spread: 1¢</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {marketStats?.nob?.bids
                                            ?.filter(orderbook => Number(orderbook.sh) > 0)
                                            .slice(0, 15)
                                            .map((orderbook, index) => (
                                                <tr key={index}>
                                                    <td>
                                                        <span className='ordervolumebg bg-green' style={{ width: handleNoWidth(Number(orderbook.p) * Number(orderbook.sh)) }}></span>
                                                    </td>
                                                    <td className='t-green'>{handleMultiply(orderbook.p)}¢</td>
                                                    <td>{Number(orderbook.sh)}</td>
                                                    <td>${(Number(orderbook.p) * Number(orderbook.sh)).toFixed(2)}</td>
                                                </tr>
                                            )
                                            )}
                                    </tbody>
                                </Table>
                            </div>
                        </AccordionBody>
                    )}
                </AccordionItem>
            </Accordion>
        </>
    )
}

export default OrderBook;