"use client"
import React, { useState, useEffect } from 'react'
import { Container, Table, Badge, Button, Modal, ModalBody, ModalHeader, ModalTitle, Form, FormGroup, FormLabel, FormControl, Offcanvas, OffcanvasHeader, OffcanvasTitle, OffcanvasBody } from 'react-bootstrap'
import FileUpload from './FileUpload'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPaperclip } from '@fortawesome/free-solid-svg-icons'
import AttachFileUpload from './AttachFileUpload'
import { useFormik } from "formik";
import addTicketValidation from "../validation_components/validations";
import { toast } from "react-toastify";

import { ticketList, addTicket } from "../api_components/user";

export default function Support() {

    const [showTicketModal, setShowTicketModal] = useState(false);
    const [chatOffCanvas, setChatOffCanvas] = useState(false);
    const [showAttachImage, setShowAttachImage] = useState(false);

    const handleShowTicketModal = () => setShowTicketModal(true);
    const handleCloseTicketModal = () => setShowTicketModal(false);

    const handleShowChatOffCanvas = () => setChatOffCanvas(true);
    const handleCloseChatOffCanvas = () => setChatOffCanvas(false);

    const handleShowAttachImage = () => setShowAttachImage(true);
    const handleCloseAttachImage = () => setShowAttachImage(false);

    const [tickets, setTickets]     = useState([]); 
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrorsResult] = useState({});
    const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

    // Fetch tickets and set initial tickets
    useEffect(() => {
        initializeTickets();
    }, []);

    // Fetch tickets
    const initializeTickets = async () => {
        try {
            const res = await ticketList(); // Replace with your API call
            if (res.success ===  true) {
                if (res.data.length > 0) {
                setTickets(res.data);
                }else{
                    setTickets([]);
                }
            }
        } catch (error) {
            console.error("Failed to fetch tickets", error);
        }
    };

        // Verify Email FORM VALIDATION
    const formik = useFormik({
        initialValues:  {  title: '', message: '',ticket_image: '' },
        validationSchema: addTicketValidation([ 'message','title','ticket_image' ]),
        onSubmit: async (values) => {
            setIsLoading(true);
            const formData = new FormData();            
            formData.append('ticket_img', values.ticket_image);
            formData.append('title', values.title);
            formData.append('message', values.message);
            const result = await addTicket({values:formData, setIsLoading, toast });
            if (result.status === true) {
                handleSuccess(result, { toast, formik, setErrors });
                clearFileInput();
                formik.resetForm();
                handleCloseModal1();
                initializeTickets();
            } else {
                handleFail(result, { toast, formik, setErrors });
                setErrorsResult(result);
                setTimeout(() => {
                    setErrorsResult({});
                }, 10000);
            }
            setIsLoading(false);
        }
    });


    const sendMessageFormik = useFormik({
        initialValues: { message: '' },
        validationSchema: addTicketValidation([ 'message']),
        onSubmit: async (values, { resetForm, setErrors, setSubmitting }) => {
            setIsLoading(true);
            try {
                const response = await sendMessage({
                    values: { ticket_id: ticket.ticket_id, message: values.message },
                    setIsLoading,
                    toast,
                });
                if (response.status === true) {
                    const ticketResponse = await viewTicket({
                        values: { ticket_id: ticket.ticket_id },
                        setIsLoading,
                        toast,
                    });
                    // Update ticket data here if needed
                    toast.success(t('Message sent successfully!'));
                    resetForm(); // Clear the form
                } else {
                    // toast.error(`${response.message}`);
                    setErrors(response.data);
                }
            } catch (error) {
                toast.error('Unexpected error occurred while sending message.');
            } finally {
                setSubmitting(false);
                setIsLoading(false);
            }
        },
    });

    return (
        <>
            <div className='support-page'>
                <Container>
                    <div>
                        <div className='supportpage-head'>
                            <h2 className='subhead'>Support</h2>
                            <Button className='sitebtn btn-sm' onClick={handleShowTicketModal}>Create Ticket</Button>
                        </div>
                        <div className='panelcontentbox'>
                            <Table className="sitetable" id="table1" responsive={true}>
                                <thead>
                                    <tr>
                                        <th>Ticket ID</th>
                                        <th>Subject</th>
                                        <th>Status</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {/* <tr>
                                        <td>TY5632137</td>
                                        <td>How to use KYC process</td>
                                        <td><Badge bg="danger">Closed</Badge></td>
                                        <td>28/12/2025, 13:17:33 </td>
                                        <td><Button className="sitebtn btn-sm" onClick={handleShowChatOffCanvas}>Chat <span className="counticon">5</span></Button></td>
                                    </tr> */}

                                    {tickets && tickets.length > 0 ? (
                                        tickets.map((item,index) => (
                                            <tr key={index}>
                                                <td> {item.ticket_id} </td>
                                                <td> {item.subject} </td>
                                                <td>
                                                {item.status === 0 ? (
                                                    <Badge bg="success">Open</Badge>
                                                ) : (
                                                    <Badge bg="danger">Closed</Badge>
                                                )}
                                                </td>

                                                <td> {item.created_at} </td>

                                                <td>
                                                    <Button className="sitebtn btn-sm" onClick={handleShowChatOffCanvas}>Chat <span className="counticon">5</span></Button>
                                                </td>
                                            </tr>
                                        ))
                                    ):(
                                        <tr>
                                            <td colSpan={10} className="text-center">
                                                No Records Found
                                            </td>
                                        </tr>
                                    )}


                                </tbody>
                            </Table>
                        </div>
                    </div>
                </Container>
            </div>

            <Modal show={showTicketModal} onHide={handleCloseTicketModal}
                aria-labelledby="ticketModal"
                centered
                className='create-ticket-modal authmodal'>
                <ModalHeader closeButton>
                    <ModalTitle id="ticketModal">Create Tickets</ModalTitle>
                </ModalHeader>
                <ModalBody>
                    
                    <Form className='siteformbg' onSubmit={formik.handleSubmit} autoComplete="off">
                        <FormGroup className="mb-3">
                            <FormLabel>Title <span className="t-red">*</span></FormLabel>
                            <Form.Control type="text" id="title" name="title" onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.title}/>
                            {formik.touched.title && formik.errors.title ? (
                                <small className="text-danger">{typeof formik.errors.title === 'string' && t(formik.errors.title)}
                                </small>
                            ) : null}
                            {errors.data?.title?.[0] && (
                                <small className="text-danger">
                                    {errors.data.title[0]}
                                </small>
                            )}
                        </FormGroup>
                        <FormGroup className='mb-3'>
                            <FormLabel>Enter your message <span className="t-red">*</span></FormLabel>
                            <Form.Control
                                as="textarea" rows={3}
                                name="message" id="message" onChange={formik.handleChange} onBlur={formik.handleBlur} value={formik.values.message}/>
                                {formik.touched.message && formik.errors.message ? (
                                    <small className="text-danger">{typeof formik.errors.message === 'string' && t(formik.errors.message)}
                                    </small>
                                ) : null}
                                {errors.data?.message?.[0] && (
                                    <small className="text-danger">
                                        {errors.data.message[0]}
                                    </small>
                                )}
                        </FormGroup>
                        <FormGroup>
                            <FileUpload />
                        </FormGroup>
                        <div className="text-center mt-3">
                            <Button className='sitebtn' type="submit" id="chatsubmit" disabled={isLoading}>{isLoading ? 'Loading...' : 'Submit'}</Button>
                        </div>
                    </Form>
                </ModalBody>
            </Modal>


            <Offcanvas show={chatOffCanvas} onHide={handleCloseChatOffCanvas} placement='end' className="support-chat-offcanvas">
                <OffcanvasHeader closeButton>
                    <OffcanvasTitle>
                        Ticket ID : EX6276648
                    </OffcanvasTitle>
                </OffcanvasHeader>
                <OffcanvasBody className='chat-body'>
                    <div className='chat-message-list'>

                        {/* ADMIN */}
                        <div className="chat-row left">
                            <div className="chat-avatar">
                                <img src="/assets/images/admin-icon.png" alt="admin" />
                            </div>

                            <div className="chat-content">
                                <div className="chat-meta">
                                    <strong>Admin</strong> ( Nov 10, 2025 )
                                </div>

                                <div className="chat-bubble">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                </div>

                                <div className="chat-bubble">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                </div>
                            </div>
                        </div>


                        {/* USER */}
                        <div className="chat-row right">
                            <div className="chat-avatar">
                                <img src="/assets/images/chatprofile.svg" alt="user" />
                            </div>

                            <div className="chat-content">
                                <div className="chat-meta text-end">
                                    <strong>John</strong> ( Nov 10, 2025 )
                                </div>

                                <div className="chat-bubble">
                                    Curabitur bibendum ornare dolor, quis ullamcorper ligula sodales.
                                </div>

                                <div className="chat-bubble">
                                    Curabitur bibendum ornare dolor, quis ullamcorper ligula sodales.
                                </div>
                            </div>
                        </div>

                        {/* ADMIN */}
                        <div className="chat-row left">
                            <div className="chat-avatar">
                                <img src="/assets/images/admin-icon.png" alt="admin" />
                            </div>

                            <div className="chat-content">
                                <div className="chat-meta">
                                    <strong>Admin</strong> ( Nov 10, 2025 )
                                </div>

                                <div className="chat-bubble">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                </div>

                                <div className="chat-bubble">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                </div>
                            </div>
                        </div>

                        {/* USER */}
                        <div className="chat-row right">
                            <div className="chat-avatar">
                                <img src="/assets/images/chatprofile.svg" alt="user" />
                            </div>

                            <div className="chat-content">
                                <div className="chat-meta text-end">
                                    <strong>John</strong> ( Nov 10, 2025 )
                                </div>

                                <div className="chat-bubble">
                                    Curabitur bibendum ornare dolor, quis ullamcorper ligula sodales.
                                </div>

                                <div className="chat-bubble">
                                    Curabitur bibendum ornare dolor, quis ullamcorper ligula sodales.
                                </div>
                            </div>
                        </div>

                    </div>
                    <div className='chat-message-box siteformbg'>
                        <div>
                            <FormLabel>Enter your message</FormLabel>
                            <Button className='sitebtn btn-sm' onClick={handleShowAttachImage}>
                                <FontAwesomeIcon icon={faPaperclip} className='me-1' />
                                Attach Image
                            </Button>
                        </div>
                        <FormControl
                            as="textarea"
                            rows={4}
                            placeholder="Type your message..."
                            className='mt-3'
                        />
                        <div className='d-flex justify-content-center'>
                            <Button className='sitebtn btn-sm mt-3'>Submit</Button>
                        </div>
                    </div>
                </OffcanvasBody>
            </Offcanvas>


            <Modal show={showAttachImage} onHide={handleCloseAttachImage}
                aria-labelledby="attachImageModal"
                centered
                className='create-ticket-modal authmodal'>
                <ModalHeader closeButton>
                    <ModalTitle id="attachImageModal">Image Upload</ModalTitle>
                </ModalHeader>
                <ModalBody>
                    <Form className='siteformbg'>
                        <FormGroup>
                            <AttachFileUpload />
                        </FormGroup>
                        <div className="text-center mt-3">
                            <Button className='sitebtn' id="imagesubmit">Submit</Button>
                        </div>
                    </Form>
                </ModalBody>
            </Modal>

        </>

    )
}