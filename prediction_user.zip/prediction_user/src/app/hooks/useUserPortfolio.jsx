"use client"
import React, { useEffect, useState, useCallback } from 'react';
import { getUserPorfolio } from "../api_components/user";
import { toast } from 'react-toastify';
import Cookies from "js-cookie";


// export default function useUserPortfolio(){

//     const [userPortfolio,setUserPortfolio] = useState([]);
    
//     useEffect(() => {
//         const token = Cookies.get("accessToken");
//         if (!token) return;

//         const fetchUserPortfolio = async () => {
//             try {
//                 const response = await getUserPorfolio();
//                 if (response?.success) {
//                     setUserPortfolio(response?.data);
//                 } else {
//                     setUserPortfolio([]);
//                 }
//             } catch (error) {
//                 console.error("Error fetching user portfolio:", error);
//                 setUserPortfolio([]);
//             }
//         };
//         fetchUserPortfolio();
//     }, []);

//     return {
//         userPortfolio
//     }

// }

export default function useUserPortfolio(){

    const [userPortfolio, setUserPortfolio] = useState([]);

    // 🔁 Fetch function
    const fetchUserPortfolio = useCallback(async () => {
        const token = Cookies.get("accessToken");
        if (!token) return;

        try {
            const response = await getUserPorfolio();
            if (response?.success) {
                setUserPortfolio(response?.data);
            } else {
                setUserPortfolio([]);
            }
        } catch (error) {
            console.error("Error fetching user portfolio:", error);
            setUserPortfolio([]);
        }
    }, []);

    // 🚀 Initial load
    useEffect(() => {
        fetchUserPortfolio();
    }, [fetchUserPortfolio]);

    // 🔥 Listen for global refresh event
    useEffect(() => {
        const handleRefresh = () => {
            fetchUserPortfolio();
        };

        window.addEventListener("portfolioUpdated", handleRefresh);

        return () => {
            window.removeEventListener("portfolioUpdated", handleRefresh);
        };
    }, [fetchUserPortfolio]);

    return {
        userPortfolio,
        refreshPortfolio: fetchUserPortfolio
    };
}