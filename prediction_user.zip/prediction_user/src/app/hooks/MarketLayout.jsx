"use client"
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Container, Row, Col, Button, Image, TabContainer, TabPane, TabContent, Nav, NavItem, NavLink } from 'react-bootstrap';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import AOS from 'aos';
import SemiCircleProgress from '../components/SemiCircleProgress';
import categoryPage from './useCategorySlugDatas';
import { formatDollarShort, formatDate } from '../helper';
import { useRouter } from 'next/navigation'
import Skeleton from '../components/Skeleton';

export default function MarketLayout({ categoryName }) {

    const router = useRouter();

    useEffect(() => {
        AOS.init();
    })

    const { categories, categoryDisplayData, isLoading } = categoryPage({ categoryName });

    return (
        <>
            <section className="markettablebg" id="marketslist">
                <Container>
                    <div className="mt-4 markt-head-wrp">
                        <h5>All Markets</h5>
                        <div className='master-card'>
                            {isLoading ? (
                                categoryDisplayData.map((item, index) => (
                                    <div key={item.id || index} className="mas-card-y">
                                    <div>
                                        <div className="mas-card-head">
                                        <div className="mas-card-icon">
                                            <Skeleton width="100%" height="100%" variant="avatar" style={{ borderRadius: "8px" }} />
                                        </div>

                                        <div className="card-title" style={{ width: "100%" }}>
                                           <Skeleton width="100%" height="30px" variant="text" />
                                        </div>
                                        </div>

                                        <div className="progress-wrap">
                                            <Skeleton width="60px" height="50px" variant="text" />
                                        </div>
                                    </div>

                                    <div>
                                        <div className="d-flex gap-2">
                                            <Skeleton width="100%" height="50px" variant="text" />

                                            <Skeleton width="100%" height="50px" variant="text" />
                                        </div>

                                        <div className="card-footer">
                                            <Skeleton width="90px" height="20px" variant="text" />

                                            <Skeleton width="90px" height="20px" variant="text" />
                                        </div>
                                    </div>
                                    </div>
                                ))
                            ) :  (
                                categories.map((item) => (
                                    <div className="mas-card-y" key={item.id}>
                                        <div>
                                            <div className="mas-card-head">
                                                <Image src={process.env.NEXT_PUBLIC_BACKEND_URL_IMAGE_URL + (item?.image || "/assets/images/no-data-icon.svg")} alt={item?.image || "/assets/images/no-data-icon.svg"} className='mas-card-icon' />

                                                <div
                                                    className="card-title"
                                                    onClick={() => router.push(`/market-trade/${item.slug}`)}
                                                >
                                                    {item.question}
                                                </div>
                                            </div>

                                            <SemiCircleProgress percentage={((Number(item?.last_yes_price) || 0) * 100).toFixed(0)} />
                                        </div>

                                        <div>
                                            <div className="d-flex gap-2">
                                                <Button
                                                    className="yes-btn"
                                                    onClick={() => router.push(`/market-trade/${item.slug}`)}
                                                >
                                                    Yes
                                                </Button>

                                                <Button
                                                    className="no-btn"
                                                    onClick={() => router.push(`/market-trade/${item.slug}`)}
                                                >
                                                    No
                                                </Button>
                                            </div>

                                            <div className="card-footer">
                                                <span>{formatDollarShort(item?.tot_traded_val ?? 0)}</span>
                                                <span>{formatDate(item?.start_time ?? item?.created_at)}</span>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </Container>
            </section>
        </>
    )
}