"use client"

import React, { useState, useEffect, useRef, use } from 'react'

import { useParams, useRouter } from 'next/navigation'
import { getMarketDetails, getMarketStats, getchartData } from '@/app/api_components/auth'
import { toast } from 'react-toastify'
import { handleSuccess, handleFail, ensureCsrfCookie } from '../helper';
import { useFormik } from 'formik';
import updateProdictionValidations from '../validation_components/validations';
import { placeLimitOrder, placeMarketOrder, getUserPosition, getUserOpenOrders, cancelOrder } from '../api_components/user';
import Cookies from "js-cookie";
import { PusherSubscribe, pusherChartSubscribe, pusherOpenOrdersSubscribe } from './pusherSubscribe'


export default function usePredictionTrade() {
    const [accessToken, setAccessToken] = useState(false);
    const [userId, setUserID] = useState(null);
    const [side, setSide] = useState('buy')
    const [predict, setPredict] = useState('yes')
    const [limitTab, setLimitTab] = useState("Limit")
    const [validations, setValidations] = useState(['price', 'shares'])
    const [userPositions, setUserPositions] = useState({});
    const [intervel, setIntervel] = useState('1D');

    const [count, setCount] = useState(0)
    const [loading, setLoading] = useState(true)

    const [market, setMarket] = useState({})
    const [marketStats, setMarketStats] = useState({})
    const [openOrders, setOpenOrders] = useState([])
    const [yesData, setYesData] = useState([])
    const [noData, setNoData] = useState([])

    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState(null);
    const [marketID, setMarketID] = useState(null);

    const router = useRouter()
    const params = useParams()
    const market_id = params?.market_id

    const [show1, setShow1] = useState(false);

    const handleClose1 = () => setShow1(false);
    const handleShow1 = () => setShow1(true);

    useEffect(() => {
        if (!market_id) return

        handleAccessToken()

        const fetchMarket = async () => {

            try {
                const [marketRes, statsRes] = await Promise.all([
                    getMarketDetails(market_id),
                    getMarketStats(market_id)
                ])

                /* MARKET DETAILS */
                if (marketRes?.success && marketRes?.data) {
                    setMarket(marketRes.data)
                    setMarketID(marketRes.data?.id)
                    const category = marketRes.data?.category_name?.toLowerCase()
                    // if (category) {
                    //     setActiveTab(category)
                    // }
                } else {
                    throw new Error("Market not found")
                }

                /* MARKET STATS */
                if (statsRes?.success) {
                    setMarketStats(statsRes.data)
                } else {
                    throw new Error("Market stats not found")
                }

            } catch (error) {
                console.error(error)
                toast.error("Failed to load market")
                setTimeout(() => {
                    router.push("/");
                }, 1000);   // ✅ Redirect after 1 seconds
            } finally {
                setLoading(false)
            }
        }
        fetchMarket()

    }, [market_id])

    const handleAccessToken = async () => {
        if (process.env.NEXT_PUBLIC_IS_DEMO === 'true') {
            const token = Cookies.get("accessToken");
            setAccessToken(token ? true : false);
        } else {
            const token = await ensureCsrfCookie();
            setAccessToken(token ? true : false);
        }
        setUserID(Cookies.get("userId"));
    }

    useEffect(() => {
        const channel = PusherSubscribe(marketID, setMarketStats);
        const chartChannel = pusherChartSubscribe(marketID, setYesData, setNoData);

        if (accessToken && marketID && userId) {
            handleUserPositions(marketID)
            handleUserOrders(marketID)
            pusherOpenOrdersSubscribe(marketID, userId, setOpenOrders)
        }
    }, [accessToken, marketID, userId])

    useEffect(() => {
        const loadChartData = async () => {
            try {
                const result = await getchartData(marketID, intervel);
                setYesData(result?.yes || [])
                setNoData(result?.no || [])
            } catch (error) {
                console.error(error);
            } finally {
                setLoading(false);
            }
        };

        loadChartData();

    }, [marketID, intervel]);

    const handleUserPositions = async (val) => {
        try {
            const data = {
                "market_id": val
            };

            const result = await getUserPosition({ values: data, setIsLoading, toast });

            if (result.success === true) {
                setUserPositions(result?.data.positions[0]);
            } else {
                handleFail(result, { toast, formik, setErrors });
            }
        } catch (error) {
            console.error(error)
            toast.error("Failed to get user positions")
        } finally {
            setLoading(false)
        }
    }

    const handleUserOrders = async (val) => {
        try {
            const data = {
                "market_id": val
            };

            const result = await getUserOpenOrders({ values: data, setIsLoading, toast });

            if (result.success === true) {
                setOpenOrders(result?.data?.orders || []);
            } else {
                handleFail(result, { toast, formik, setErrors });
            }
        } catch (error) {
            console.error(error)
            toast.error("Failed to get user positions")
        } finally {
            setLoading(false)
        }
    }

    const handleLimitTab = (tab) => {
        setLimitTab(tab);
        if (tab === 'Market') {
            setValidations(['shares']);
        } else {
            setValidations(['price', 'shares']);
        }
        formik.setFieldValue("price", '');
        formik.setFieldValue("shares", '');
        formik.setFieldValue("total", '');
        formik.setFieldValue("win", '');
        setCount(0);
    }

    const handleSide = (side) => (e) => {
        e.preventDefault();
        setSide(side);
        setCount(0);
    }

    const handlePredict = (predict) => (e) => {
        e.preventDefault();
        setPredict(predict);
    }

    const handleCount = (e, type) => {
        e.stopPropagation();
        if (type === 'increment') {
            setCount(prev => prev + 1);
            formik.setFieldValue("price", Number(formik.values?.price || 0) + 1);
        } else if (type === 'decrement' && count > 0) {
            setCount(prev => Math.max(0, prev - 1));
            formik.setFieldValue("price", Math.max(0, Number(formik.values?.price || 0) - 1));
        }
    }

    const handleCountInput = (e) => {
        const val = e.target.value;
        if (val === '' || /^\d+$/.test(val) && Number(val) >= 0 && Number(val) <= 99) {
            setCount(val === '' ? '' : Number(val));
            formik.setFieldValue("price", val === '' ? '' : Number(val));
            handleTotal(val === '' ? '' : Number(val), formik.values?.shares);
        }
    }

    const handleTotal = (price, shares) => {
        if (side === 'buy') {
            if (price === '' || shares === '' || isNaN(price) || isNaN(shares)) {
                formik.setFieldValue("total", '');
                formik.setFieldValue("win", '');
            } else {
                formik.setFieldValue("total", (Number(price) * Number(shares) / 100).toFixed(2));
                formik.setFieldValue("win", (Number(shares)).toFixed(2));
            }
        } else {
            if (price === '' || shares === '' || isNaN(price) || isNaN(shares)) {
                formik.setFieldValue("total", '');
                formik.setFieldValue("win", '');
            } else {
                formik.setFieldValue("total", 0.00);
                formik.setFieldValue("win", (Number(price) * Number(shares) / 100).toFixed(2));
            }
        }
    }

    const handleSharesInput = (e) => {
        const val = e.target.value;

        if (val === '' || /^\d*\.?\d{0,2}$/.test(val)) {
            formik.setFieldValue("shares", val === '' ? '' : Number(val));
            handleTotal(formik.values?.price, val === '' ? '' : Number(val));
        }
    }

    const handleMarketSharesInput = (e) => {
        const val = e.target.value;

        if (val === '' || /^\d*\.?\d{0,2}$/.test(val)) {
            formik.setFieldValue("shares", val === '' ? '' : Number(val));
        }
    }

    const handleSharesChange = (change) => {
        const newShares = Number(formik.values?.shares || 0) + change;
        if (newShares >= 0) {
            formik.setFieldValue("shares", newShares);
            handleTotal(formik.values?.price, newShares);
        }
    }

    const handleMarketSellSharesChange = (change) => {
        if (predict === 'yes') {
            const userYesShares = userPositions?.holdings?.yes?.shares || 0;
            const sellableShares = userYesShares > 0 ? Number(userYesShares * change / 100) : 0;
            formik.setFieldValue("shares", sellableShares);
        } else {
            const userNoShares = userPositions?.holdings?.no?.shares || 0;
            const sellableShares = userNoShares > 0 ? Number(userNoShares * change / 100) : 0;
            formik.setFieldValue("shares", sellableShares);
        }
    }

    const handleCancelOrder = async (id) => {
        try {
            const data = {
                "id": id      
            }
            const result = await cancelOrder({ values: data, setIsLoading, toast });
            
            if(result.success === true){
                handleSuccess(result, { toast, formik, setErrors });
                setErrors({});
            }else{
                handleFail(result, { toast, formik, setErrors });
            }
        } catch (error) {
            console.error(error);
        } finally {
            setIsLoading(false);
        }
    }


    // Update Orderbook formik
    const formik = useFormik({
        initialValues: { price: '', shares: '', total: '', win: '' },
        validationSchema: updateProdictionValidations(validations),
        onSubmit: async (values) => {
            setIsLoading(true);

            const data = {
                "limit_price": (Number(values.price) / 100).toFixed(2),
                "shares": values.shares,
                "market_id": marketID,
                "action": side,
                "outcome": predict,
            };

            const api = limitTab === "Market" ? placeMarketOrder : placeLimitOrder;

            const result = await api({ values: data, setIsLoading, toast });

            if (result.success === true) {
                handleSuccess(result, { toast, formik, setErrors });
                setErrors({});
                window.dispatchEvent(new Event("portfolioUpdated"));
                // window.location.reload();
            } else {
                handleFail(result, { toast, formik, setErrors });
                setErrors(result?.data);
                setTimeout(() => {
                    setErrors({});
                }, 10000);
            }
            setIsLoading(false);
        }
    });

    return {
        market,
        marketStats,
        loading,
        side,
        predict,
        limitTab,
        count,
        formik,
        errors,
        isLoading,
        router,
        accessToken,
        handleSide,
        handlePredict,
        handleLimitTab,
        handleCount,
        handleCountInput,
        handleSharesInput,
        handleMarketSharesInput,
        handleSharesChange,
        handleMarketSellSharesChange,
        userPositions,
        intervel,
        setIntervel,
        yesData,
        noData,
        setYesData,
        setNoData,
        openOrders,
        handleCancelOrder,
        handleShow1,
        show1,
        handleClose1
    }
}