'use client';
import React, { useEffect,useState } from 'react';
import {getUserOrderActivity} from '../api_components/user';
import { Image, Table } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBitcoinSign, faThLarge, faFootball, faMicrophone, faChartLine, faBarsProgress, faLaptop, faNewspaper, faSearch } from '@fortawesome/free-solid-svg-icons';
import { toast } from 'react-toastify';
import PaginationTabs from '../hooks/pagination';


export default function useUserOrderActivity() {

    const [activePage, setActivePage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);
    const [isLoading, setIsLoading]   = useState(false);
    const [userOrderActivity,setUserOrderActivity] = useState([]);


    useEffect(() => {
        fetchOrdersActivitys(activePage);
    },[]);

    // Handle Page Click
    const handlePageClick = (page) => {
        fetchOrdersActivitys(page);
        setActivePage(page);
    };

    const limit = 10;

    //Fetch User Orders
    const fetchOrdersActivitys = async (page) => {
      try {
        const values = {
          limit,
          offset: (page - 1) * limit,
        };
        const res = await getUserOrderActivity({values, setIsLoading, toast });
        if (res && res.success === true) {
            setTotalPages(Math.ceil(res.data.total / limit));  
            setUserOrderActivity(res.data.orders);
        }else{
            setTotalPages(0);
            setUserOrderActivity([]);
        }
      } catch (error) {
            console.log('Error processing order:', error);
      } finally {
            setIsLoading(false);
      }
    }

    // Convers Date
    const timeAgo = (dateString) => {
        const now = new Date();
        const past = new Date(dateString);
        const seconds = Math.floor((now - past) / 1000);

        if (seconds < 60) {
            return seconds + " seconds ago";
        }

        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) {
            return minutes + " minutes ago";
        }

        const hours = Math.floor(minutes / 60);
        if (hours < 24) {
            return hours + " hours ago";
        }

        const days = Math.floor(hours / 24);
        if (days < 30) {
            return days + " days ago";
        }

        const months = Math.floor(days / 30);
        if (months < 12) {
            return months + " months ago";
        }

        const years = Math.floor(months / 12);
        return years + " years ago";
    };


    return (
        <div className="preview-panel-tb mt-4">
            <Table>
                <thead>
                    <tr>
                        <th>TYPE</th>
                        <th className='text-start'>MARKET</th>
                        <th>AMOUNT</th>
                    </tr>
                </thead>
                <tbody>
                    {isLoading ?  (
                        <tr>
                            <td colSpan={3} className="text-center">
                                Loading...
                            </td>
                        </tr>
                    ) : 
                    userOrderActivity && userOrderActivity.length > 0 ? (
                        userOrderActivity.map((item,index) => (
                        <tr key={index}>
                            <td className="avg-col">{item?.action?.charAt(0).toUpperCase() + item?.action?.slice(1).toLowerCase()}{" "}</td>
                            <td>
                                <div className="market-cell">                                    
                                    <Image src={process.env.NEXT_PUBLIC_BACKEND_URL_IMAGE_URL + (item?.market?.image || "/assets/images/no-data-icon.svg")} alt="icon" className="market-icon" />
                                    <div>
                                        <div className="market-title">
                                        {item?.market?.question}
                                        </div>

                                        <div className="market-meta">
                                            <span
                                                className={item?.outcome === "yes" ? "yes-badge" : "no-badge"}
                                            >
                                            {item?.outcome?.charAt(0).toUpperCase() + item?.outcome?.slice(1).toLowerCase()}{" "}
                                            {parseFloat(item?.limit_price ?? 0)}
                                            </span>
                                            <span className="shares">{parseFloat(item?.total_shares ?? 0)} shares</span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td className="text-end value-col">
                                <span>
                                    $
                                    {(
                                        parseFloat(item?.limit_price ?? 0) *
                                        parseFloat(item?.total_shares ?? 0)
                                    ).toFixed(2)}
                                </span>
                                <div className="market-title">{timeAgo(item.created_at)}</div>
                            </td>
                        </tr>
                        ))) : (
                        <tr>
                            <td colSpan={3} className="text-center">
                                No Records Found
                            </td>
                        </tr>
                    )}
                </tbody>
            </Table>
            {!isLoading &&  (
                <PaginationTabs  totalPages={totalPages} activePage={activePage} handlePageClick={handlePageClick}/>
            )}
        </div>
    );
}