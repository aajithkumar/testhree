"use client"
import React, {useEffect,useState} from 'react';
import { allcoins,getWithdraw,confirmWithdraw } from "../api_components/user";
import { toast } from 'react-toastify';
import { useFormik } from "formik";
import  withdrawValidations  from "../validation_components/validations"
import { handleSuccess,handleFail } from "../helper";



export default function useWithdraw() {

    const [coinList, setCoinList] = useState([]);
    const [selectedNetwork, setSelectedNetwork] = useState("");
    const [selectedCoin, setSelectedCoin] = useState(null);
    const [withdrawDetails, setWithdrawDetails] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isLoadingBut, setIsLoadingBut] = useState(false);
    const [errors,  setErrors] = useState([]);
    
    
    // Fecth Coins List
    useEffect(() => {
        const fetchCoins = async () => {
            try {
                const response = await allcoins();
                if (response?.success) {
                    const coins = response.data;
                    setCoinList(coins);
                    const defaultCoin = coins.find(
                        (coin) => coin.symbol === "USDT"
                    );
                    if (defaultCoin) {
                        setSelectedCoin(defaultCoin);
                        setSelectedNetwork(defaultCoin.network?.[0] || "");
                        fetchWithdrawDetails(defaultCoin.symbol);
                    }
                } else {
                    setCoinList([]);
                }
            } catch (error) {
                console.error("Error fetching coins:", error);
                setCoinList([]);
            }
        };
        fetchCoins();
    }, []);
    
    // Fetch Withdraw Details
    const fetchWithdrawDetails = async (symbol) => {
        try {
            setIsLoading(true);
            const datas = { symbol };
            const response = await getWithdraw({ values: datas, setIsLoading, toast });
            if (response?.success) {
                setWithdrawDetails(response?.data?.walllet);
            } else {
                setWithdrawDetails(null);
            }

        } catch (error) {
            console.error("Withdraw fetch error:", error);
            setWithdrawDetails(null);
        } finally {
            setIsLoading(false);
        }
    };
    
    // Withdraw Format String
    const formatAmount = (value) => {
        if (!value) return "0";
        return parseFloat(value).toString();
    };

    // Confirm Withdraw
    const formik = useFormik({
	    initialValues:  {  symbol: '', network: '', amount: '', to_address: ''},
		validationSchema: withdrawValidations([ 'symbol','network', 'amount', 'to_address' ]),
        onSubmit: async (values) => {
            setIsLoadingBut(true);
            const data = {
                "symbol": selectedCoin?.symbol,
                "network": selectedNetwork,
                "amount": values.amount,
                "to_address": values.to_address,
            };

            // toast.success('Success! Withdrawal request submitted. Transaction is being processed.');

            // setTimeout(()=>{
            //     formik.resetForm();
            // },4000);
            
            const result = await confirmWithdraw({values:data, setIsLoading, toast });
            if (result.success === true) {
                handleSuccess(result, { toast, formik, setErrors });
                setErrors({});
                formik.resetForm();
                // 🔥 IMPORTANT: Refresh withdraw details
                if (selectedCoin?.symbol) {
                    fetchWithdrawDetails(selectedCoin.symbol);
                }
                window.dispatchEvent(new Event("portfolioUpdated"));
            } else {
                handleFail(result, { toast, formik, setErrors });
                setErrors(result?.data);
                setTimeout(() => {
                    setErrors({});
                }, 10000);
            }
            setIsLoadingBut(false);
        }
    });



    return {
        coinList,
        selectedNetwork,
        setSelectedNetwork,
        selectedCoin,
        setSelectedCoin,
        withdrawDetails,
        fetchWithdrawDetails,
        isLoadingBut,
        formatAmount,
        formik,
        setErrors,
        errors,
    }
}