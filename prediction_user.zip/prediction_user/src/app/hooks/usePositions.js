'use client';
import React, { useEffect,useState } from "react";
import Link from 'next/link';
import { getUserPosition } from "../api_components/user";
import { toast } from 'react-toastify';

export default function usePositions({status,activePage,search}){

    const [ rows , setRows ] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    // const [activePage, setActivePage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);

    // Handle Page Click
    const handlePageClick = (page) => {
        fetchPositionsDetails(page);
        // setActivePage(page);
    };

    const limit = 10;

    const fetchPositionsDetails = async (page) => {
            const datas = {
                status,    
                search,      
                limit,
                offset: (page - 1) * limit,
            }
            const response = await getUserPosition({ values:datas, setIsLoading, toast });
            if (response?.success == true ){
                setTotalPages(Math.ceil(response?.data?.total / limit));
                const positions     = response?.data?.positions || [];
                const formattedRows = positions.flatMap((pos) => {

                    const list = [];

                    const yes = pos?.holdings?.yes;
                    const no = pos?.holdings?.no;

                    // YES row condition
                    if (yes && Number(yes.shares) > 0) {
                        list.push({
                            type: "Yes",
                            question: pos.question,
                            image: pos.image,


                            shares: yes.shares,
                            avg_price: yes.avg_price,
                            avg_price_cents: yes.avg_price_cents,

                            total_cost: yes.total_cost,
                            unrealized_pnl: yes.unrealized_pnl,
                            realized_pnl: yes.realized_pnl,

                            result: yes.result,
                            amountWon: yes.amount_won,
                            current_price: yes.current_price,
                            current_price_cents:yes.current_price_cents,


                            status: yes.status
                        });
                    }

                    // NO row condition
                    if (no && Number(no.shares) > 0) {
                        list.push({
                            type: "No",
                            question: pos.question,
                            image: pos.image,


                            shares: no.shares,
                            avg_price: no.avg_price,
                            avg_price_cents: no.avg_price_cents,

                            total_cost: no.total_cost,
                            unrealized_pnl: no.unrealized_pnl,
                            realized_pnl: no.realized_pnl,

                            result: no.result,
                            amountWon: no.amount_won,
                            current_price: no.current_price,
                            current_price_cents:no.current_price_cents,

                            status: no.status
                        });
                    }

                    return list;
                });
                setRows(formattedRows);

            }else{
                setRows([])
            }
    }
    

    useEffect(() => {
        fetchPositionsDetails(activePage);
    },[status,activePage,search]);

    return {
        rows,
        isLoading,
        handlePageClick,
        totalPages,
        activePage
    }

}