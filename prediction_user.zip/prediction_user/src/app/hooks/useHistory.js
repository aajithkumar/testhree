import { useState } from "react";
import { getdepositHistory, getwithdrawHistory } from "../api_components/user";

const useHistory = () => {
  const [depositHistory, setDepositHistory] = useState([]);
  const [withdrawHistory, setWithdrawHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const [depositPage, setDepositPage] = useState(1);
  const [withdrawPage, setWithdrawPage] = useState(1);

  const [depositTotalPages, setDepositTotalPages] = useState(1);
  const [withdrawTotalPages, setWithdrawTotalPages] = useState(1);


  const fetchDepositHistory = async (page = 1) => {
    try {
      setIsLoading(true);

      const limit = 10;
      const offset = (page - 1) * limit;

      const values = { limit, offset };

      const res = await getdepositHistory({ values });

      if (res && res.success) {
        const history = res.data?.history || [];
        const total = res.data?.count || 0;

        setDepositHistory(history);
        setDepositTotalPages(Math.ceil(total / limit));
        setDepositPage(page);
      } else {
        setDepositHistory([]);
      }
    } catch (err) {
      console.log("Deposit Error:", err);
      setDepositHistory([]);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchWithdrawHistory = async (page = 1) => {
    try {
      setIsLoading(true);

      const limit = 10;
      const offset = (page - 1) * limit;

      const values = { limit, offset };

      const res = await getwithdrawHistory({ values });

      if (res && res.success) {
        const history = res.data?.history || [];
        const total = res.data?.count || 0;

        setWithdrawHistory(history);
        setWithdrawTotalPages(Math.ceil(total / limit));
        setWithdrawPage(page);
      } else {
        setWithdrawHistory([]);
      }
    } catch (err) {
      console.log("Withdraw Error:", err);
      setWithdrawHistory([]);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    depositHistory,
    withdrawHistory,
    isLoading,

    fetchDepositHistory,
    fetchWithdrawHistory,

    depositPage,
    withdrawPage,

    depositTotalPages,
    withdrawTotalPages
  };
};

export default useHistory;