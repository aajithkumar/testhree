"use client";
import { useState,useEffect } from "react";
import { signIn } from "../api_components/auth";
import { useFormik } from "formik";
import { handleSuccess,handleFail } from "../helper";
import { toast } from 'react-toastify';
import  signinValidations  from "../validation_components/validations";
import {  Modal, ModalBody, ModalHeader, ModalTitle, Form, FormControl, FormGroup, Button, InputGroup } from 'react-bootstrap';
import {  faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Cookies from "js-cookie";
import { useRouter } from 'next/navigation'


export default function useSignin({showSignin,handleClose1,accessPage}) {

      const router = useRouter();
      
      const [isLoading, setIsLoading] = useState(false);
      const [errors, setErrors] = useState(null);
      const [showPasswordSignin, setShowPassword]     = useState(false);

      useEffect(() => {
          if (!showSignin) {
              formik.resetForm();
              setErrors(null);
          }
      }, [showSignin]);

      // Toggle  Password
    const togglePasswordVisibilitySignin = () => {
      setShowPassword(!showPasswordSignin);
    };

    // SIGN UP HANDLE 
    const formik = useFormik({
      initialValues:  { email: 'teddycup_prediction@mailinator.com', password: 'User1@123'},
      validationSchema: signinValidations([ 'email', 'password' ]),
      onSubmit: async (values) => {
          setIsLoading(true);
          const data = {
              "username_email": values.email,
              "password": values.password,
              "device_type":  'web',
          };

          const result = await signIn({values:data, setIsLoading, toast });
          if (result.success === true) {
              handleSuccess(result, { toast, formik, setErrors });
              setErrors({});
              formik.resetForm();
              Cookies.set('accessToken',result?.data?.token);
              Cookies.set('userName',result?.data?.user_details?.user_name);
              Cookies.set('userEmail',result?.data?.user_details?.email);
              Cookies.set('userProfile',result?.data?.user_details?.profile_image);
              Cookies.set('userId',result?.data?.user_details?.id);
              setTimeout(()=>{
                  window.location.href= accessPage ? accessPage : "/";
              },500)
              if (handleClose1) {
                  handleClose1(); 
              }
          } else {
              handleFail(result, { toast, formik, setErrors });
              setErrors(result?.data);
              setTimeout(() => {
                  setErrors({});
              }, 10000);
          }
          setIsLoading(false);
      }
    });

  
    return (
        <Modal
        show={showSignin}
        onHide={handleClose1}
        centered
        className="authmodal"
        size="md"
        >
        <ModalHeader closeButton>
          <ModalTitle>Sign In</ModalTitle>
        </ModalHeader>
        <ModalBody>
          <p className="mb-3 text-center mt-0">Welcome back to Predimark</p>
          <Form className="siteformbg" onSubmit={formik.handleSubmit} autoComplete="off">
            <FormGroup className="mb-3">
              <FormControl 
              type="text" 
              placeholder="email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              name="email"
              disabled
               />
              {formik.touched.email && formik.errors.email && (
                  <small className="text-danger">
                    {formik.errors.email}
                  </small>
              )}
              {errors?.email && errors?.email?.length > 0 && <small className="text-danger">{errors?.email}</small>}
            </FormGroup>
            <FormGroup className="mb-3">
              <InputGroup >
                <FormControl
                  placeholder="Password"
                  aria-label="Password"
                  aria-describedby="basic-addon1"
                  name="password"
                  type={showPasswordSignin ? 'text' : 'password'}
                  value={formik.values.password}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  disabled
                />
                <InputGroup.Text id="basic-addon1" onClick={togglePasswordVisibilitySignin}><FontAwesomeIcon icon={showPasswordSignin ? faEye : faEyeSlash } /></InputGroup.Text>
              </InputGroup>
              {formik.touched.password && formik.errors.password && (
                  <small className="text-danger">
                    {formik.errors.password}
                  </small>
              )}
              {errors?.password && errors?.password?.length > 0 && <small className="text-danger">{errors?.password}</small>}
              {errors?.error && errors?.error.length > 0 && <small className="text-danger">{errors?.error}</small>}
            </FormGroup>
            
            <div className="text-center">
              <Button type="submit" className="sitebtn" disabled={isLoading}>{isLoading ? ('Loading...') : ('Sign In')}</Button>
            </div>
            {/* <p className="mb-0">Don’t have an account? <Link href="#" className="alink">Sign Up</Link></p> */}
          </Form>
        </ModalBody>
      </Modal>
    )
}

