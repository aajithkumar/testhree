import pusher from '@/services/pusher/pusher';

// Subscribe to Pusher
export const PusherSubscribe = (marketID, setMarketStats) => {

	const userChannelName = `market.${marketID}`;

	const userChannel = marketID && pusher.subscribe(userChannelName);

	userChannel?.bind("orderbook.updated", (data) => {
		try {

			const parsed =
				typeof data.message === "string"
					? JSON.parse(data.message)
					: data.message;

			if (parsed?.data) {
				const newData = parsed.data;
				setMarketStats(prev => ({
					...prev,
					...newData
				}))
			}

		} catch (err) {
			console.error("❌ Failed to parse orderbook.updated:", err, data);
		}
	});

	return () => {
		userChannel?.unbind_all();
		pusher.unsubscribe(userChannelName);
	};
};

// Subscribe to Chart function Pusher
export const pusherChartSubscribe = (market, setYesData, setNoData) => {

	const userChannelName = `market-chart-data_${market}`;

	const userChannel = market && pusher.subscribe(userChannelName);

	userChannel?.bind("orderbook.updated", (payload) => {
		try {

			let data = payload;

			if (typeof payload === "string") {
				data = JSON.parse(payload);
			}

			if (payload.message) {
				data = JSON.parse(payload.message);
			}

			if (Number(data.mid) !== Number(market)) return;

			const newPoint = {
				t: data.t,
				p: Number(data.p)
			};

			if (data.o === "yes") {
				setYesData(prev => [...prev.slice(-100), newPoint]);
			}

			if (data.o === "no") {
				setNoData(prev => [...prev.slice(-100), newPoint]);
			}


		} catch (err) {
			console.error("❌ Failed to parse orderbook.updated:", err, data);
		}
	});

	return () => {
		userChannel?.unbind_all();
		pusher.unsubscribe(userChannelName);
	};
};


// Subscribe to Open Order Pusher
export const pusherOpenOrdersSubscribe = (market, userId, setOpenOrders) => {

	const userChannelName = `openorder_${market}_${userId}`;

	const userChannel = market && pusher.subscribe(userChannelName);

	userChannel?.bind("orderbook.updated", (payload) => {
		try {

			let data = payload;

			if (typeof payload === "string") {
				data = JSON.parse(payload);
			}

			if (payload.message) {
				data = JSON.parse(payload.message);
			}

			console.log(data);

			setOpenOrders(data)


		} catch (err) {
			console.error("❌ Failed to parse orderbook.updated:", err, data);
		}
	});

	return () => {
		userChannel?.unbind_all();
		pusher.unsubscribe(userChannelName);
	};
};