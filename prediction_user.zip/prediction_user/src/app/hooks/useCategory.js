"use client"
import React, {useEffect,useState} from 'react';
import { getMarketCategories } from '@/app/api_components/auth';
import { toast } from 'react-toastify';



export default function useCategory() {

    const [categories, setCategories] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    
    // Fetch Category
    useEffect( () => {
        const fetchCategories = async () => {
            try {
                const response = await getMarketCategories();
                if (response.success === true) {
                    setCategories(response.data);
                } else {
                    setCategories([]);

                }
            } catch (error) {
                console.log("Failed to load categories. Try again! "+error);
                toast.error("Failed to load categories. Try again!");
            }
        };

        fetchCategories();
    },[]);


    return {
        categories,
        isLoading
    }
}