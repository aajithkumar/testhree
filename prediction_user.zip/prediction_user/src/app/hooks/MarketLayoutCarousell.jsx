
"use client"
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Container, Row, Col, Button, Image, TabContainer, TabPane, TabContent, Nav, NavItem, NavLink } from 'react-bootstrap';
import { BookMarkIcon, LinkIcon, BallIcon, BitCoinIcon, FinanceIcon, ListIcon, MediaIcon, MetalsIcon, MicIcon, TechIcon } from '../components/HomeIcons';
import Slider from "react-slick";
import 'aos/dist/aos.css';
import AOS from 'aos';
import HomePredictChart from '../components/HomePredictChart';
import categoryPage from './useCategorySlugDatas';
import { useRouter } from 'next/navigation';
import { formatDollarShort, formatDateTime } from '../helper';
import Skeleton from '../components/Skeleton';
import { isInteger } from 'formik';


export default function MarketLayoutCarousell({ categoryName }) {

    const router = useRouter();

    const MemoChart = React.memo(HomePredictChart);

    useEffect(() => {
        AOS.init();
    })

    var settings = {
        arrows: false,
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
    };

    const { isLoading, categoriesBreaking, displayData, breakingDisplayData, topicsDisplayData } = categoryPage({ categoryName });


    return (
        <>
            <section>
                <Container className='banner-cont'>
                    <Row>
                        <Col lg={9}>
                            <div>
                                <Slider {...settings} className='slider-container'>

                                    {displayData.map((item, index) => (
                                        <div key={item?.id || index}>
                                            <div className="chartbox">
                                                <div className="panelcontentbox">
                                                    <div className="chartbox-tabs">

                                                        <div className="chartbox-panel">
                                                            <div>

                                                                {isLoading ? (
                                                                    <Skeleton width="60px" height="60px" variant="avatar" />
                                                                ) : (
                                                                    <img src={process.env.NEXT_PUBLIC_BACKEND_URL_IMAGE_URL + (item?.image || "/assets/images/no-data-icon.svg")} alt={item?.image || "/assets/images/no-data-icon.svg"} />
                                                                )}

                                                                <div className="d-flex flex-column gap-1">
                                                                    {isLoading ? (
                                                                        <Skeleton width="280px" height="18px" variant="title" />
                                                                    ) : (
                                                                        <h6
                                                                            className="subhead mb-0"
                                                                            onClick={() => router.push(`/market-trade/${item?.slug}`)}
                                                                        >
                                                                            {item?.question}
                                                                        </h6>
                                                                    )}
                                                                </div>

                                                            </div>
                                                        </div>

                                                        <Row>
                                                            <Col lg={4}>
                                                                <div className="d-flex gap-2">

                                                                    {isLoading ? (
                                                                        <>
                                                                            <Skeleton width="100%" height="40px" />
                                                                            <Skeleton width="100%" height="40px" />
                                                                        </>
                                                                    ) : (
                                                                        <>
                                                                            <Button className="yes-btn">
                                                                                Yes - ({((Number(item?.last_yes_price) || 0) * 100).toFixed(0)}%)
                                                                            </Button>

                                                                            <Button className="no-btn">
                                                                                No - ({((Number(item?.last_no_price) || 0) * 100).toFixed(0)}%)
                                                                            </Button>
                                                                        </>
                                                                    )}

                                                                </div>

                                                                {isLoading ? (
                                                                    <Skeleton width="100%" height="260px" variant="text" className='mt-3' />
                                                                ) :
                                                                    <>
                                                                        <div className="marquee-container">
                                                                            <div className="chart-newsbox marquee-content">
                                                                                {categoriesBreaking?.breaking?.map((item, index) => (
                                                                                    <div className='newsbox-cont' key={index}>
                                                                                        <div className='newsbox-head'>
                                                                                            <img src="/assets/images/news-icon.svg" alt="icon" />
                                                                                            <span>{formatDateTime(item?.created_at)}</span>
                                                                                        </div>
                                                                                        <p>{item?.question}</p>
                                                                                    </div>
                                                                                ))}
                                                                            </div>
                                                                        </div>
                                                                    </>
                                                                }
                                                            </Col>

                                                            <Col lg={8}>
                                                                {isLoading ? (
                                                                    <Skeleton height="300px" width='100%' />
                                                                ) : (
                                                                    <MemoChart marketID={item?.id} />
                                                                )}
                                                            </Col>
                                                        </Row>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </Slider>
                            </div>
                        </Col>
                        <Col lg={3}>
                            <div className='banner-box'>
                                <div className='panelcontentbox'>
                                    <div className='banner-box-title'>
                                        <h6 className='mb-0'>Breaking News</h6>
                                        {/* <Link href="#0">View All</Link> */}
                                    </div>
                                    {breakingDisplayData.slice(0, 3).map((item, index) => (
                                        <div key={index} className='banner-box-content'>
                                            {isLoading ? (
                                                <Skeleton width="100%" height="30px" variant="text" />
                                            ) : (
                                                <div>
                                                    <p className="mb-0" style={{ cursor: "pointer" }} onClick={() => router.push(`/market-trade/${item?.slug}`)}>{item?.question}</p>

                                                    <div className='d-flex flex-column'>
                                                        <span>{((Number(item?.last_yes_price) || 0) * 100).toFixed(0)}%</span>
                                                        <span>{((Number(item?.last_no_price) || 0) * 100).toFixed(0)}%</span>
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                                <div className='panelcontentbox'>
                                    <div className='banner-box-title'>
                                        <h6 className='mb-0'>Hot Topics</h6>
                                        {/* <Link href="">View All</Link> */}
                                    </div>

                                    {topicsDisplayData.map((item, index) => (
                                        <div key={index} className='banner-box-content2'>
                                            {isLoading ? (
                                                <Skeleton width="100%" height="30px" variant="text" />
                                            ) : (
                                                <div>
                                                    <p style={{ cursor: "pointer" }} onClick={() => router.push(`/${item?.slug}`)}>{item?.name?.charAt(0).toUpperCase() + item?.name?.slice(1)}</p>

                                                    <div>
                                                        <span>{formatDollarShort(item?.value) || 0}</span>
                                                        <Image src="/assets/images/fire.svg" alt="fire" />
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    ))}



                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
        </>
    )

}