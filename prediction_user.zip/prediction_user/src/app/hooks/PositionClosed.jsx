"use client"
import React, {useEffect,useState} from 'react';
import { toast } from 'react-toastify';
import 'simplebar-react/dist/simplebar.min.css';
import { Button, Container,Row,Badge,Table,Image } from 'react-bootstrap';
import { BookMarkIcon, CopyIcon, FilterIcon, HandPackageIcon, UploadIcon, BallIcon, BitCoinIcon, FinanceIcon, ListIcon, MediaIcon, MetalsIcon, MicIcon, TechIcon } from '../components/HomeIcons';
import usePositions from '../hooks/usePositions';
import PaginationTabs from '../hooks/pagination';


export default function PositionClosed({status,activePage, setActivePage, search}) {

    const { rows,isLoading,handlePageClick,totalPages } = usePositions({status,activePage, search});

    return (
        <>
            <Table>
                <thead>
                    <tr>
                        {status == 0 ? 
                            <>
                            <th>MARKET</th>
                            <th>AVG</th>
                            <th>CURRENT</th>
                            <th>VALUE</th>
                            </>
                        :
                            <>
                                <th>RESULT</th>
                                <th className='text-start'>MARKET</th>
                                <th>TOTAL TRADED</th>
                                <th>AMOUNT WON</th>
                            </>
                        }
                        
                    </tr>
                </thead>
                <tbody>
                    {isLoading ?  (
                        <tr>
                            <td colSpan={5} className="text-center">
                                <img src="/assets/images/loader.svg" alt="Loading..."  />
                            </td>
                        </tr>
                    ) 
                    :
                    rows?.length ? (
                        rows.map((row, index) => {

                            const isClosed = status == 1;
                            const pnl = isClosed ? row?.realized_pnl : row?.unrealized_pnl;
                            // const costValue = isClosed ? row?.total_cost : row?.amountWon;
                            const costValue = isClosed ? row?.total_cost : (parseFloat(row?.shares || 0) * parseFloat(row?.current_price || 0)).toFixed(2);

                            return (
                                <tr key={index}>

                                    {isClosed && (
                                        <td>
                                            <span className={row?.result === "Win" ? "yes-badge" : "no-badge"}>
                                            {row?.result}
                                            </span>
                                        </td>
                                    )}

                                    <td>
                                    <div className="market-cell">
                                        <Image
                                            src={process.env.NEXT_PUBLIC_BACKEND_URL_IMAGE_URL + (row?.image || "/assets/images/no-data-icon.svg")}
                                            alt="icon"
                                            className="market-icon"
                                        />

                                        <div>
                                        <div className="market-title">
                                            {row?.question}
                                        </div>

                                        <div className="market-meta">
                                            <span className={row?.type === "Yes" ? "yes-badge" : "no-badge"}>
                                            {row?.type} {row?.avg_price_cents}
                                            </span>

                                            <span className="shares">
                                            {parseFloat(row?.shares ?? 0)} shares
                                            </span>
                                        </div>
                                        </div>
                                    </div>
                                    </td>

                                    {isClosed ? (
                                    <td className="text-end avg-col">{row?.total_cost}</td>
                                    ) : (
                                    <>
                                        <td className="text-end avg-col">{row?.avg_price_cents}</td>
                                        <td className="text-end current-col">{row?.current_price_cents}</td>
                                    </>
                                    )}

                                    <td className="text-end value-col">
                                    <span>${costValue}</span>

                                    <div className={Number(pnl) < 0 ? "negative-value" : "positive-value"}>
                                        ${pnl} (100%)
                                    </div>
                                    </td>
                                </tr>
                            );
                        })
                        ) : (
                        <tr>
                            <td colSpan={5} className="text-center">
                                No Records Found
                            </td>
                        </tr>
                    )}
                </tbody>
            </Table>
            {!isLoading &&  (
                <PaginationTabs  totalPages={totalPages} activePage={activePage} handlePageClick={setActivePage}/>
            )}
        </>
    )

}