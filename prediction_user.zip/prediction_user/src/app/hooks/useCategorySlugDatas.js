"use client"
import React, {useEffect,useState} from 'react';
import { getPredicitonMarkets,getPredicitonMarketsBreaking } from '@/app/api_components/auth';
import { toast } from 'react-toastify';


export default function useCategory({categoryName}) {

    const [categories, setCategories] = useState([]);
    const [categoriesBreaking, setCategoriesBreaking] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [markets, setMarkets] = useState([]);

    const limit = 12

    // Fetch Category
    useEffect( () => {
        
        const fetchCategories = async () => {
            setIsLoading(true); 
            const datas = {
                limit: limit,
                offset: 0,
                category_name: categoryName,
                status: "open"
            };
            try {
                const response = await getPredicitonMarkets({ values: datas, toast });
                if (response?.success) {
                    setCategories(response.data || []);
                } else {
                    setCategories([]);
                }
            } catch (error) {
                console.log("Failed to load categories:", error);
                toast.error("Failed to load categories. Try again!");
                setCategories([]);
            } finally {
                setIsLoading(false);  // stop loader
            }
        };

        const fetchMarketBreaking = async () => {
            setIsLoading(true); 
            const datas = {
                limit: limit,
                offset: 0,
                category_name: categoryName
            };
            try {
                const response = await getPredicitonMarketsBreaking({ values: datas, toast });
                if (response?.success) {
                    setCategoriesBreaking(response.data || []);
                } else {
                    setCategoriesBreaking([]);
                }
            } catch (error) {
                console.log("Failed to load categories:", error);
                toast.error("Failed to load categories. Try again!");
                setCategoriesBreaking([]);
            } finally {
                setIsLoading(false);  // stop loader
            }
        };


        fetchCategories();
        fetchMarketBreaking();
    },[categoryName]);

    const displayData = isLoading ? Array(3).fill({}) : categories.slice(0, 3);
    const breakingDisplayData = isLoading
                                ? Array(4).fill({})
                                : categoriesBreaking?.breaking || [];

    const topicsDisplayData = isLoading
                                ? Array(4).fill({})
                                : categoriesBreaking?.topics || [];
    const categoryDisplayData = isLoading ? Array(3).fill({}) : categories;


    return {
        categories,
        isLoading,
        markets,
        categoriesBreaking,
        displayData,
        breakingDisplayData,
        topicsDisplayData,
        categoryDisplayData
    }
}