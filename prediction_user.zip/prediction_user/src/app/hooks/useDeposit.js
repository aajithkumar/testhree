'use client';
import React, { useEffect,useState } from "react";
import Link from 'next/link';
import { Container, Navbar, Nav, Image, Modal, ModalHeader, ModalTitle, ModalBody, Button, FormGroup, FormLabel, FormSelect, FormControl, InputGroup } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { CopyIcon, InfoIcon, CopyCheckIcon } from '../components/HomeIcons';
import { faAngleLeft } from '@fortawesome/free-solid-svg-icons';
import {allcoins,getDepositDetails} from "../api_components/user";
import { toast } from 'react-toastify';



export default function useDeposit({showDepositModal,handleCloseDepositModal , setShowDepositModal ,setShowTransferModal,showTransferModal,handleCloseTransferModal}) {

    const [coinList, setCoinList] = useState([]);
    const [selectedCoin, setSelectedCoin] = useState(null);
    const [selectedNetwork, setSelectedNetwork] = useState("");
    const [depositDetails, setDepositDetails] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [copied, setCopied] = useState(false);

    const selectedAddress = depositDetails?.address?.find(
        (a) => a.network?.toLowerCase() === selectedNetwork?.toLowerCase()
    );

    const networkLabel = (net) => {
        const map = {
        erc20: "Ethereum-ERC20",
        trc20: "Tron-TRC20",
        bep20: "BSC-BEP20"
        };
        return map[net?.toLowerCase()] || net;
    };

    // Handle Copy Address
    const handleCopyAddress = async () => {
        if (!selectedAddress?.address) return;
        try {
            if (navigator?.clipboard?.writeText) {
                await navigator.clipboard.writeText(selectedAddress.address);
            } else {
                // fallback for unsupported browsers
                const textarea = document.createElement("textarea");
                textarea.value = selectedAddress.address;
                textarea.style.position = "fixed";
                textarea.style.opacity = "0";

                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand("copy");
                document.body.removeChild(textarea);
            }
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (error) {
            console.log("Failed to copy text", error);
            toast.error("Failed to copy text");
        }
    };


    // Fecth Coins List
    useEffect(() => {
        const fetchCoins = async () => {
        try {
            const res = await allcoins();
            if (!res?.success) return;
            const coins = res.data;
            setCoinList(coins);
            const defaultCoin = coins.find((c) => c.symbol === "USDT");
            if (defaultCoin) {
                setSelectedCoin(defaultCoin);
                setSelectedNetwork(defaultCoin?.network?.[0] || "");
                fetchDepositDetails(defaultCoin.symbol);
            }
        } catch (err) {
            console.log("Coin fetch error", err);
            toast.error('Coin Fetch Error');
        }
        };

        fetchCoins();
    }, []);


    // Fetch Deposit Details
    const fetchDepositDetails = async (symbol) => {
        try {
        const res = await getDepositDetails({values: { symbol },toast});
        if (res?.success) {
            setDepositDetails(res.data.wallet);
        }
        } catch (err) {
            console.log("Deposit fetch error", err);
            toast.error('Deposit fetch error');
        }
    };

    return (
        <>
            {/* Deposit Modal */}
            <Modal
                show={showDepositModal} onHide={handleCloseDepositModal}
                centered
                className="authmodal depositmodal"
                size="md"
            >
            <ModalHeader closeButton>
                <ModalTitle>Deposit</ModalTitle>
            </ModalHeader>
            <ModalBody>
                {/* <p className="mb-3 text-center mt-0">Balance : $0</p> */}
                <hr />
                <Button className='transfer-div bg-transparent border-0' onClick={() => { setShowDepositModal(false); setShowTransferModal(true); }}>
                    <div>
                        <Image src="/assets/images/transfer-icon.svg" alt="transfer-icon" />
                        <div>
                            <h6 className='subhead mb-0'>Transfer Crypto</h6>
                            <p className='m-0'>No limit • Instant</p>
                        </div>
                    </div>
                    <div>
                        <Image src="/assets/images/coins-icon.svg" alt="coins-icon" />
                    </div>
                </Button>
            </ModalBody>
            </Modal>

            {/* Transfer Modal */}
            <Modal
                show={showTransferModal}
                onHide={handleCloseTransferModal}
                centered
                className="authmodal transfermodal"
                size="md"
            >
                <ModalHeader closeButton>
                    <Button onClick={() => { setShowTransferModal(false); setShowDepositModal(true); }} className='bg-transparent border-0'><FontAwesomeIcon icon={faAngleLeft} /></Button>
                    <ModalTitle>Transfer Crypto</ModalTitle>
                </ModalHeader>
                <ModalBody className='siteformbg'>
                    <p className="mb-3 text-center mt-0">Predimark Balance : {parseFloat(depositDetails?.balance) || "0"}</p>
                    <hr />
                    <div className='select-token'>
                        <FormGroup>
                            <FormLabel>Supported token</FormLabel>
                            <FormSelect
                                value={selectedCoin?.id || ""}
                                onChange={(e) => {
                                    const coin = coinList.find(
                                        (item) => item.id === Number(e.target.value)
                                    );
                                    setSelectedCoin(coin);
                                    setSelectedNetwork(coin?.network?.[0] || "");
                                    if (coin?.symbol) {
                                        fetchDepositDetails(coin.symbol);
                                    }
                                }}
                            >
                                {coinList
                                    .filter((coin) => coin.symbol !== "USD")
                                    .map((coin) => (
                                    <option key={coin.id} value={coin.id}>
                                            {coin.symbol}
                                    </option>
                                ))}
                            </FormSelect>
                        </FormGroup>
                        <FormGroup>
                            {/* {depositDetails?.settings?.[0]?.minimum_deposit || "0"} */}
                            <FormLabel className='w-100'>Supported chain <span className='me-auto'>Min {parseFloat(depositDetails?.settings?.[0]?.minimum_deposit) || "0"}<InfoIcon size={13} color='#A4A1AA' className="ms-1" /></span></FormLabel>
                            <FormSelect 
                                value={selectedNetwork}
                                onChange={(e) => setSelectedNetwork(e.target.value)}
                            >
                                {/* <option>Ethereum</option> */}
                                {selectedCoin?.network?.map((net, index) => (
                                    <option key={index} value={net}>
                                        {networkLabel(net)}
                                    </option>
                                ))}
                            </FormSelect>
                        </FormGroup>
                    </div>
                    <div className='transfer-qr'>
                        {depositDetails?.address?.find(
                        (addr) => addr.network?.toLowerCase() == selectedNetwork?.toLowerCase()
                        )?.qrcode && (
                            <Image
                                src={
                                    depositDetails.address.find(
                                        (addr) => addr.network?.toLowerCase() == selectedNetwork?.toLowerCase()
                                    ).qrcode
                                }
                                alt="qr-code"
                            />
                        )}
                    </div>
                    <div className='d-flex justify-content-between align-items-center deposit-add mt-3'>
                        <span>Your deposit address <InfoIcon size={15} color='#A4A1AA' /></span>
                        {/* <Link href="#">Terms apply</Link> */}
                    </div>
                    <InputGroup className="mt-3">
                        <FormControl  
                            value={
                                depositDetails?.address?.find(
                                (addr) => addr.network?.toLowerCase() === selectedNetwork?.toLowerCase()
                                )?.address || ""
                            }
                            readOnly  
                        />
                        <InputGroup.Text>
                        <div onClick={handleCopyAddress}>
                            {copied ? (
                                <CopyCheckIcon size={18} color='#A4A1AA' />
                            ) : (
                                <CopyIcon size={15} color='#A4A1AA'  style={{ cursor: "pointer" }}/>
                            )}
                        </div>
                        </InputGroup.Text>
                    </InputGroup>
                    {/* <FormSelect className='mt-3'>
                        <option value="">Price Impact :0.00%</option>
                    </FormSelect> */}
                </ModalBody>
            </Modal>
        </>
            
    );
}
