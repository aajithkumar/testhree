import React from "react";
import Link from 'next/link';
import { Pagination } from 'react-bootstrap';

const Paginationcom = ({ totalPages, activePage, handlePageClick}) => {


    const getPaginationRange = () => {
        const maxVisiblePages = 5; // Number of visible pages
        let startPage = Math.max(1, activePage - Math.floor(maxVisiblePages / 2));
        let endPage = startPage + maxVisiblePages - 1;
        // Adjust if endPage exceeds totalPages
        if (endPage > totalPages) {
            endPage = totalPages;
            startPage = Math.max(1, endPage - maxVisiblePages + 1);
        }
        return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i);
    };

    return (
        <>
        {/* PAGEINATION START  */}
            {totalPages > 1 && (
                <Pagination>
                    {/* <Pagination.Prev /> */}
                    <Pagination.Prev
                        onClick={() => handlePageClick(Math.max(activePage - 1, 1))}
                        disabled={activePage === 1}
                    />
                    {/* <Pagination.Ellipsis /> */}

                    {activePage > 5 && (
                        <>
                            <Pagination.Item onClick={() => handlePageClick(1)}>1</Pagination.Item>
                            <Pagination.Ellipsis />
                        </>
                    )}

                    {/* <Pagination.Item active={activePage === 3} onClick={() => handlePageClick(3)} >
                    {1}
                    </Pagination.Item> */}

                    {getPaginationRange().map((page) => (
                        <Pagination.Item
                            key={page}
                            active={activePage === page}
                            onClick={() => handlePageClick(page)}
                        >
                            {page}
                        </Pagination.Item>
                    ))}

                    {/* <Pagination.Ellipsis /> */}

                    {activePage < totalPages - 4 && (
                        <>
                            <Pagination.Ellipsis />
                            <Pagination.Item onClick={() => handlePageClick(totalPages)}>
                                {totalPages}
                            </Pagination.Item>
                        </>
                    )}

                    <Pagination.Next
                        onClick={() => handlePageClick(Math.min(activePage + 1, totalPages))}
                        disabled={activePage === totalPages}
                    />
                    {/* <Pagination.Next /> */}
                </Pagination>
            )}
        {/* PAGEINATION END */}
        </>
    )

}

export default Paginationcom