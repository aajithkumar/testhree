"use client";
import { useState,useEffect } from "react";
import { signup } from "../api_components/auth";
import { useFormik } from "formik";
import { handleSuccess,handleFail } from "../helper";
import { toast } from 'react-toastify';
import  signupValidations  from "../validation_components/validations"
import {Modal, ModalBody, ModalHeader, ModalTitle, Form, FormControl,  FormGroup, Button, InputGroup } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {  faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';


export default function useSignup({showSignup,handleClose}) {

    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState(null);
    const [showPassword, setShowPassword]     = useState(false);
	  const [showC_Password, setShowC_Password] = useState(false);
    
    useEffect(() => {
        if (!showSignup) {
            formik.resetForm();
            setErrors(null);
        }
    }, [showSignup]);
    

    // Toggle  Password
    const togglePasswordVisibility = () => {
      setShowPassword(!showPassword);
    };

    // Toggle Confirm Password
    const toggleC_PasswordVisibility = () => {
      setShowC_Password(!showC_Password);
    };

    // SIGN UP HANDLE 
    const formik = useFormik({
    	initialValues:  {  username: '', email: '', password: '', c_password: ''},
		  validationSchema: signupValidations([ 'username','email', 'password', 'c_password' ]),
      onSubmit: async (values) => {
              setIsLoading(true);
              const data = {
                  "username": values.username,
                  "email": values.email,
                  "password": values.password,
                  "confirm_password": values.c_password,
                  "device_type":  'web',
              };

              const result = await signup({values:data, setIsLoading, toast });
              if (result.success === true) {
                  handleSuccess(result, { toast, formik, setErrors });
                  setErrors({});
                  formik.resetForm();
                  if (handleClose) {
                      handleClose();   //  Close modal after success
                  }
              } else {
                  handleFail(result, { toast, formik, setErrors });
                  setErrors(result?.data);
                  setTimeout(() => {
                      setErrors({});
                  }, 10000);
              }
              setIsLoading(false);
      }
    });

    return (
      <Modal
        show={showSignup}
        onHide={handleClose}
        centered
        className="authmodal"
        size="md"
      >
        <ModalHeader closeButton>
          <ModalTitle>Sign Up</ModalTitle>
        </ModalHeader>
        <ModalBody>
          <p className="mb-3 text-center mt-0">Welcome to Predimark</p>
          <Form className="siteformbg" onSubmit={formik.handleSubmit} autoComplete="off">
            <FormGroup className="mb-3">
              <FormControl 
                type="text" 
                placeholder="Username" 
                name="username" 
                value={formik.values.username}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.username && formik.errors.username && (
                <small className="text-danger">
                  {formik.errors.username}
                </small>
              )}
              {errors?.username && errors?.username?.length > 0 && <small className="text-danger">{errors?.username}</small>}
            </FormGroup>
            <FormGroup className="mb-3">
              <FormControl 
                type="text" 
                placeholder="Email Address" 
                name="email" 
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.email && formik.errors.email && (
                <small className="text-danger">
                  {formik.errors.email}
                </small>
              )}
              {errors?.email && errors?.email?.length > 0 && <small className="text-danger">{errors?.email}</small>}
            </FormGroup>
            <FormGroup className="mb-3">
              <InputGroup>
              <FormControl
                placeholder="Password"
                aria-label="Password"
                aria-describedby="basic-addon1"
                type={showPassword ? 'text' : 'password'}
                name="password"
                value={formik.values.password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              <InputGroup.Text id="basic-addon1" onClick={togglePasswordVisibility}><FontAwesomeIcon icon={showPassword ? faEye : faEyeSlash } /></InputGroup.Text>
              </InputGroup>
              {formik.touched.password && formik.errors.password && (
                  <small className="text-danger">
                    {formik.errors.password}
                  </small>
              )}
              {errors?.password && errors?.password?.length > 0 && <small className="text-danger">{errors?.password}</small>}
            </FormGroup>
            
            <FormGroup className="mb-3">
              <InputGroup>
              <FormControl
                placeholder="Password"
                aria-label="Password"
                aria-describedby="basic-addon2"
                type={showC_Password ? 'text' : 'password'}
                name='c_password'
                value={formik.values.c_password}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              <InputGroup.Text id="basic-addon2" onClick={toggleC_PasswordVisibility}><FontAwesomeIcon icon={showC_Password ? faEye : faEyeSlash } /></InputGroup.Text>
            </InputGroup>
            {formik.touched.c_password && formik.errors.c_password && (
              <small className="text-danger">
                {formik.errors.c_password}
              </small>
            )}
            {errors?.c_password && errors?.c_password?.length > 0 && <small className="text-danger">{errors?.c_password}</small>}
            </FormGroup>
            
            <div className="text-center">
              <Button type="submit" className="sitebtn"  disabled={isLoading}>{isLoading ? ('Loading...') : ('Sign Up')}</Button>
            </div>

            {/* <p className="mb-0">Already have an account? <Link href="#" className="alink">Sign in</Link></p> */}
          </Form>
        </ModalBody>
      </Modal>
    );

}

