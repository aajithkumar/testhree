'use client';
import React, { useEffect,useState } from 'react'
import {getUserProfile,updateProfile} from '../api_components/user';
import { useFormik } from 'formik';
import updateProfileValidations from '../../app/validation_components/validations';
import { toast } from 'react-toastify';
import { handleSuccess,handleFail } from "../helper";
import Cookies from "js-cookie";

export default function useProfileSettings(){

    const [getProfileDetails, setGetProfileDetails] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [errors, setErrors] = useState(null);

    // Fetch Profile Details
    useEffect(() => {
      fetchgetProfile();
    },[]);

    const fetchgetProfile = async () => {
        try {
            const response = await getUserProfile();
            if(response.success){
                setGetProfileDetails(response.data);
                Cookies.set('userName',response?.data?.name);
                Cookies.set('userProfile',response?.data?.profile_image); 
            }
        } catch (error) {
            console.error("Profile fetch error:", error);
            setGetProfileDetails([]);
        }
    };

    //update Profile Details
    const formik = useFormik({
        initialValues:  { username: '', address: ''},
        validationSchema: updateProfileValidations([ 'username', 'address']),
        onSubmit: async (values) => {
            toast.success('Success! Profile settings update successfully.')
            // setIsLoading(true);
            // const formData = new FormData();
            // formData.append('user_name', values.username);
            // formData.append('address', values.address);
            // if (values.profile_image && values.profile_image instanceof File) {
            //     formData.append('profile_image', values.profile_image);
            // }
            // const result = await updateProfile({values:formData, setIsLoading, toast });
            // if (result.success === true) {
            //     handleSuccess(result, { toast, formik, setErrors });
            //     setErrors({});
            //     fetchgetProfile();
            // } else {
            //     handleFail(result, { toast, formik, setErrors });
            //     setErrors(result?.data);
            //     setTimeout(() => {
            //         setErrors({});
            //     }, 10000);
            // }
            // setIsLoading(false);
        }
    });


    return { 
        getProfileDetails,
        formik,
        isLoading,
        errors
    };
}
