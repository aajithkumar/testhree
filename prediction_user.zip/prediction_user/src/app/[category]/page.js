"use client"
import React from 'react';
import { useParams, useRouter } from 'next/navigation';
import MarketLayout from '../hooks/MarketLayout';


export default  function CategoryPage() {

    const params = useParams()
    const categoryName = params?.category;   
 
    return (
        <main className="contentpagesbg">
            <MarketLayout categoryName={categoryName}/>
        </main>
    );
}