import Cookies from "js-cookie";
import { ajaxWithTkn } from "../helper";

// Get User CheckAuth Function
export const CheckAuth = async () => {
  return ajaxWithTkn("user_auth");
};


// Get User Profile Function
export const getUserProfile = async () => {
	return ajaxWithTkn("get-user-details");
};

// GET SECURITY DETAILS
export const getSecurityDetails = async () => {
	return ajaxWithTkn("get-security-details");
};


// Update profile image
export const update_profile_pic = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("update_profile_image",values,{ setIsLoading, toast },true);
};

// Update profile
export const updateProfile = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("update-profile", values, { setIsLoading, toast },true);
};

// Recent Transation
export const recentTrans = async () => {
	return ajaxWithTkn("recent_transaction");
};

// Balance Board
export const balanceBoard = async () => {
	return ajaxWithTkn("balanceboard");
};

// Change Password Function
export const changePassword = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("update_password", values, { setIsLoading, toast });
};

// verifyLoginOTP
export const verify2faOTP = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("verifyotp", values, { setIsLoading, toast });
};

// verifyEmailOTP
export const verifyLoginEmailOTP = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("verifyotp", values, { setIsLoading, toast });
};

// resendLoginOTP
export const resend2faOTP = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("resendmail", values, { setIsLoading, toast });
};

// List Activity
export const activitylist = async () => {
	return ajaxWithTkn("list_activity");
};

// List Device
export const devicelist = async () => {
	return ajaxWithTkn("list_devices");
};

// List Device
export const devicelistPage = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("list_devices_page", values, { setIsLoading, toast });
};


//  SendMail Function
export const sendMail = async () => {
	return ajaxWithTkn("enable_sendemail2factor");
};


//  enableSendMail Function
export const enableSendMail = async () => {
	return ajaxWithTkn("enable-email-2fa");
};

//  enableVerifyMail Function
export const enableVerifyMail = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("enable_email2factor", values, { setIsLoading, toast });
};

//  disableVerifyMail Function
export const disableVerifyMail = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("disable_2factor", values, { setIsLoading, toast });
};

// getGoogle Secrect
export const getGoogleSecrect = async () => {
	return ajaxWithTkn("get_google_secret");
};

// enableGoogle 2fa
export const enableVerifyGoogle = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("enable_google2factor", values, { setIsLoading, toast });
};

// Security Status
export const getSecurityStatus = async () => {
	return ajaxWithTkn("get_security_status");
};

// Get User Country
export const getUserCountry = async () => {
	return ajaxWithTkn("get_countires");
};

// create & update AntiPhisingCode
export const setAntiphishing = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("update_antiphishing", values, { setIsLoading, toast });
};

// Generate Passphrase
export const generatePassphrase = async () => {
	return ajaxWithTkn("generate_passphrase");
};

// Enable Passphrase
export const enablePassphrase = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("save_passphrase", values, { setIsLoading, toast });
};

// Disable Passphrase
export const disablePassphrase = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("disable_passphrase", values, { setIsLoading, toast });
};

// Account Freeze User
export const freezeAccount = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("freeze_user", values, { setIsLoading, toast });
};

// Account Delete User
export const deleteAccount = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("delete_user", values, { setIsLoading, toast });
};

// Update Personal KYC Update
export const kyc_personal_update = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn(
		"kyc_personal_update",
		values,
		{ setIsLoading, toast },
		true
	);
};

// Get Personal KYC Details
export const kycPersonalDetails = async () => {
	return ajaxWithTkn("kyc_detail");
};

export const advkycPersonalDetails = async () => {
	return ajaxWithTkn("kyc_adv_detail");
};


// Update Advance KYC Update
export const kycAdvancedUpdate = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("kyc_adv_update", values, { setIsLoading, toast }, true);
};

// support ticket lists
export const ticketList = async () => {
	return ajaxWithTkn("ticket-list");
};

// Add support ticket
export const addTicket = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("add-ticket", values, { setIsLoading, toast }, true);
};

// view support ticket
export const viewTicket = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("view-ticket", values, { setIsLoading, toast });
};

// send message
export const sendMessage = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("send-message", values, { setIsLoading, toast });
};

// view notifications
export const getNotify = async () => {
	return ajaxWithTkn("getnotify");
};

// list notifications
export const listNotify = async () => {
	return ajaxWithTkn("listnotify");
};

// MARKET OVERVIEW
export const marketoverview = async () => {
	return ajaxWithTkn('markets/overview');
};

// Logout
export const logout = async () => {
	return ajaxWithTkn('logout');
};


// Get Wallet data
export const getWallet = async () => {
	return ajaxWithTkn('get_wallet_transaction');
};

// Get Wallet data
export const getCombineWallet = async () => {
	return ajaxWithTkn('get_combine_wallet_transaction');
};

// Get Maker/Taker data
export const getMakerTakerFeeDetails = async () => {
	return ajaxWithTkn('fees/maker-taker');
};


// Coin List 
export const allcoins = async () => {
	return ajaxWithTkn('coin-list');
}

// Deposit Detail
export const getDepositDetails = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("deposit-detail", values, { setIsLoading, toast });
};


// Wallet List 
export const walletList = async () => {
	return ajaxWithTkn('wallet');
}

// Address get 
export const getAddress = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('get_deposit_address', values, { setIsLoading, toast }, false);
};

// Withdraw Detail
export const getWithdraw = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('withdraw-detail', values, { setIsLoading, toast }, false);
};

// Verify Withdraw 
export const verifyWithdraw = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('coin_verify_withdraw', values, { setIsLoading, toast }, false);
};

// Confirm Withdraw 
export const confirmWithdraw = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('confirm-withdraw', values, { setIsLoading, toast }, false);
};

// RESEND WITHDRAW EMAIL
export const resendWithdrawemail = async () => {
	return ajaxWithTkn('withdraw-email');
};

// TRADE HISTORY
export const tradehistory = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('order/history', values, { setIsLoading, toast }, false);
};

//  CANCEL ORDER
export const cancelOrder = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('prediction/order/cancel', (values), { setIsLoading, toast }, false);
};

// TRADE VOLUME CALCULATION
export const volumeCalculate = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('trade/volume', values, { setIsLoading, toast }, false);
};

// ORDER CREATE 
export const OrderCreate = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('order/create', values, { setIsLoading, toast }, false);
};

// MARKET DEPTH CHART
export const marketDepthChart = async (setpairId) => {
	return ajaxWithTkn(`normal_marketdepthchart/${setpairId}`);
};

//Deposit History
export const deposit_history = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('deposit_history', values, { setIsLoading, toast }, false);
};

//Getaddress Crypto
export const generateAddress = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('generate-address', values, { setIsLoading, toast }, false);
};

//Withdraw History
export const withdraw_history = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('withdraw_history', values, { setIsLoading, toast }, false);
};

// get spot-wallet balance
export const getWalletBalance = async () => {
	return ajaxWithTkn('get-wallet');
};

// CRYPTO WITHDRAW 
export const verifyCryptoWithdraw = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('coin_verify_withdraw', values, { setIsLoading, toast }, true);
};

export const confirmCryptoWithdraw = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('coin_confirm_withdraw', values, { setIsLoading, toast }, true);
};

// CANCEL WITHDRAW
export const cancelWithdraw = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('cancel_crypto_withdraw', values, { setIsLoading, toast }, false);
};

// REFERAL
export const referalUsers = async () => {
	return ajaxWithTkn('referral');
};

// AFFILIATE
export const affiliateUsers = async () => {
	return ajaxWithTkn('affiliate');
};

// Get Active Trade Pairs Function
export const getTradePairs = async () => {
    return ajaxWithTkn("trade_pairs");
};


// Get First Active Trade Pair 
export const getFirstTradePair = async () => {
	return ajaxWithTkn("trade_pairs/first");
};

// Get stake all products details
export const getStakePlansDetails = async () => {
    return ajaxWithTkn("stakingproduct");
  };

// Get submit stake products 
export const stakesubmit = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('stakesubmit', values, { setIsLoading, toast }, false);
};

//savings history
export const stakeSavingsHistory = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('stakinghistory', values, { setIsLoading, toast }, false);
};

// Get stake product details
export const getProductDetails = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('productdetails', values, { setIsLoading, toast }, false);
};

//interest History
export const stakeInterestHistory = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('stakinginteresthistory', values, { setIsLoading, toast }, false);
};

//interest Release
export const releaseStaking = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('releasestaking', values, { setIsLoading, toast }, false);
};


//Historical holding
export const historicalHoldings = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('historical_holding', values, { setIsLoading, toast }, false);
};


// CONVERSION FETCH
export const getConversion = async () => {
	return ajaxWithTkn("conversion/fetch");
};

// CONVERT PRICE
export const getConvertPrice = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("convertprice", values, { setIsLoading, toast }, false);
};

// CONFIRM CONVERT 
export const confirmConvert = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("confirm/convert", values, { setIsLoading, toast }, false);
};

//  CONVERT HISTORY
export const conversionHistoryUsers = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("conversion/history", values, { setIsLoading, toast }, false);
};

//  REFERRAL HISTORY
export const referralHistoryUsers = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("referral_history", values, { setIsLoading, toast }, false);
};

//  AFFILIATE HISTORY
export const affiliateHistoryUsers = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("affiliate_history", values, { setIsLoading, toast }, false);
};

// EARN BALANCE
export const earnBalance = async () => {
	return ajaxWithTkn("earnbalance");
};

// get PnL
export const showPnL = async () => {
	return ajaxWithTkn("get_pnl");
};

// GET TODAY PNL
export const getTodayPnL = async () => {
	return ajaxWithTkn("get_todaypnl");
};

// PnL chart data
export const pnlchartData = async () => {
	return ajaxWithTkn("pnl_chartData");
};

// Language Update
export const updateLanguage = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("update_language", values, { setIsLoading, toast }, false);
};

// affiliate program apply
export const affiliateProgram = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn("store_inquiry", values, { setIsLoading, toast }, false);
};

// affiliate status check
export const affiliateInquiryStatus = async () => {
	return ajaxWithTkn("inquiry_status");
};

export const getUserOrderActivity = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('prediction/order/activity', values, { setIsLoading, toast }, false);
};

export const getUserPorfolio = async () => {
	return ajaxWithTkn('prediction/user/portfolio');
};


/*** Place Buy LIMIT Order */
export const placeLimitOrder = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('prediction/order/limit', values, { setIsLoading, toast }, false);
};

/*** Place Buy MARKET Order */
export const placeMarketOrder = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('prediction/order/market', values, { setIsLoading, toast }, false);
};

/** User Position */
export const getUserPosition = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('prediction/user/positions', values, { setIsLoading, toast }, false);
};

/** deposit history */
export const getdepositHistory = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('deposit-history', values, { setIsLoading, toast }, false);
};

/** withdraw history */
export const getwithdrawHistory = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('withdraw-history', values, { setIsLoading, toast }, false);
};

/** Open Order History */
export const getUserOpenOrders = async ({ values, setIsLoading, toast }) => {
	return ajaxWithTkn('prediction/user/open-orders', values, { setIsLoading, toast }, false);
};