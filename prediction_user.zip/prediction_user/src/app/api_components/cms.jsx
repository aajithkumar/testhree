import { ajaxNotTkn } from "../helper";

// get cms-privacy
export const getCmsindex = async () => {
  return ajaxNotTkn('cms-index');
};

// get cms-deposit-faq
export const getCmsDepositFaq = async () => {
  return ajaxNotTkn('cms-deposit-faq');
};

// get cms-withdraw-faq
export const getCmsWithdrawFaq = async () => {
  return ajaxNotTkn('cms-withdraw-faq');
};


// get cms-privacy
export const getCmsPrivacy = async () => {
    return ajaxNotTkn('cms-privacy');
};
  
// get cms-privacy
export const getCmsTerms = async () => {
  return ajaxNotTkn('cms-terms');
};

// get cms-Social-Media
export const getSocialMedia = async () => {
  return ajaxNotTkn('cms-socialMedia');
};
