import { faL } from "@fortawesome/free-solid-svg-icons";
import { ajaxNotTkn } from "../helper";

export const authchecking = async () => {
    return ajaxNotTkn('user_auth');
};

// Signup Form Submit Function
export const signup = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('register', values, { setIsLoading, toast });
};

// Check Referral  Function
export const checkReferral = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('checkReferral', values, { setIsLoading, toast });
};


// Resend Email Verificaiton
export const resendMail = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('resendmail', values, { setIsLoading, toast });
};

// Email Verify 
export const emailVerify = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('email_verify', values, { setIsLoading, toast });
};

// Sign In 
export const signIn = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('login', values, { setIsLoading, toast });
};

// Forgot
export const forgotPass = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('forget_password', values, { setIsLoading, toast });
};

// ResetPassword
export const resetPass = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('reset_password', values, { setIsLoading, toast });
};


// Subscribe 
export const subscribeEmail = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('subscribe', values, { setIsLoading, toast });
};

// Contactus 
export const contactUs = async ({ values, setIsLoading, toast }) => {
    return ajaxNotTkn('contactus', values, { setIsLoading, toast });
};

// MARKET DEPTH CHART
export const marketDepthChart = async (setpairId) => {
    return ajaxNotTkn(`normal_marketdepthchart/${setpairId}`);
};

// ORDER BOOK
export const tradeOrderbook = async ({values, setIsLoading, toast }) => {
    return ajaxNotTkn(`orderbook`,values, { setIsLoading, toast });
};

// Prediciton Markets
export const getPredicitonMarkets = async ({values, setIsLoading, toast }) => {
    return ajaxNotTkn(`prediction-markets/get/market`,values, { setIsLoading, toast });
};

//getPredictionBreakingMarkets
export const getPredicitonMarketsBreaking = async ({values, setIsLoading, toast }) => {
    return ajaxNotTkn(`prediction-markets/get/market/breaking`,values, { setIsLoading, toast });
};

// Get Active Trade Pairs Function
export const getTradePairs = async () => {
    return ajaxNotTkn("trade/pairs");
  };

// Get prediction market list
export const getMarketList = async () => {
    return ajaxNotTkn('prediction-markets');
};

// Get prediction market categories
export const getMarketCategories = async () => {
    return ajaxNotTkn('get_market_categories');
};

// Get prediction market details
export const getMarketDetails = async (market_id) => {
    return ajaxNotTkn(`prediction-markets/${market_id}`);
};

// Get prediction market state
export const getMarketStats = async (market_id) => {
    return ajaxNotTkn(`prediction/market/${market_id}`);
};

// Get prediction chart data
export const getchartData = async (market_id, interval) => {
    if (interval) {
        return ajaxNotTkn(`prices-history?market=${market_id}&interval=${interval}`);
    } else {
        return ajaxNotTkn(`prices-history?market=${market_id}`);
    }
};

export const getHomechartData = async (market_id, interval) => {
    if (interval) {
        return ajaxNotTkn(`home-prices-history?market=${market_id}&interval=${interval}`);
    } else {
        return ajaxNotTkn(`home-prices-history?market=${market_id}`);
    }
};