#!/bin/bash

echo "Starting deployment..."

# Always run from project directory
cd "$(dirname "$0")" || exit

PROJECT_NAME="demo9_prediction"
PORT=8142

echo "Project: $PROJECT_NAME"

# -----------------------------
# 1. Pull latest code
# -----------------------------
echo "Pulling latest code..."
git pull origin main || { echo "Git pull failed"; exit 1; }

# -----------------------------
# 2. Clean old files
# -----------------------------
echo "Cleaning old build..."

rm -rf node_modules
rm -rf .next
rm -f package-lock.json

# -----------------------------
# 3. Install dependencies
# -----------------------------
echo "Installing dependencies..."
npm install || { echo "npm install failed"; exit 1; }

# -----------------------------
# 4. Build project
# -----------------------------
echo "Building Next.js app..."
npm run build || { echo "Build failed"; exit 1; }

# -----------------------------
# 5. PM2 Process Handling
# -----------------------------
echo "🔍 Checking PM2 process..."

if pm2 describe "$PROJECT_NAME" > /dev/null 2>&1; then
    echo "PM2 process exists. Restarting..."
    pm2 restart "$PROJECT_NAME"
else
    echo "PM2 process not found. Starting new one..."
    pm2 start npm --name "$PROJECT_NAME" -- start -- -p $PORT
fi

# -----------------------------
# 6. Save PM2 state
# -----------------------------
pm2 save

echo "Deployment completed successfully!"
